package com.farhad.modem.core

/** One row of the modem's "cell information" (serving cell, secondary cell or neighbor). */
data class CellRow(
    val kind: String,        // "4G", "5G", "4G neighbor", "5G neighbor"
    val type: String,        // PCC / SCC / ""
    val earfcn: Int?,
    val band: String,        // "B3", "N78" or ""
    val bandwidth: String,
    val pci: Int?,
    val rsrp: Double?,
    val rsrq: Double?,
    val rssi: Double?,
    val sinr: Double?
) {
    val bandNumber: Int? get() = band.filter { it.isDigit() }.toIntOrNull()
}

object CellInfoParser {
    /** Endpoints tried (GET only) when the app has not learned the real one yet. */
    val CANDIDATES = listOf(
        "/api/device/cell-info", "/api/net/cell-info", "/api/net/cellinfo", "/api/device/cellinfo",
        "/api/net/neighbor-cell-info", "/api/net/neighbour-cell-info", "/api/device/neighbor-cell",
        "/api/net/neighbor-cells", "/api/net/nei-cell", "/api/net/lte-cell-info", "/api/net/nr-cell-info",
        "/api/net/network-cell-info", "/api/device/signal-info", "/api/device/cell"
    )

    private val pciTag = Regex("<\\w*pci\\w*>", RegexOption.IGNORE_CASE)
    private val blockRe = Regex("<(\\w+)>((?:(?!</\\1>)[\\s\\S])*)</\\1>")
    private val leafRe = Regex("<(\\w+)>([^<]*)</\\1>")

    private fun insideTag(text: String, start: Int, nameRe: Regex): Boolean {
        for (m in Regex("<(\\w+)>").findAll(text.substring(0, start))) {
            val name = m.groupValues[1]
            if (!nameRe.containsMatchIn(name)) continue
            val close = text.indexOf("</$name>", m.range.last)
            if (close > start) return true
        }
        return false
    }

    /** Finds every element that contains exactly one PCI field and reads its fields. Format-tolerant on purpose. */
    fun parse(x: String): List<CellRow> {
        data class Cand(val start: Int, val end: Int, val body: String)
        val cands = ArrayList<Cand>()
        var pos = 0
        while (pos < x.length) {
            val m = blockRe.find(x, pos) ?: break
            val body = m.groupValues[2]
            if (pciTag.findAll(body).count() == 1 && leafRe.findAll(body).count() >= 2) cands.add(Cand(m.range.first, m.range.last, body))
            pos = m.range.first + 1   // also look inside this element (nested blocks)
        }
        // keep only the innermost candidates
        val inner = cands.filter { c -> cands.none { o -> o !== c && o.start >= c.start && o.end <= c.end && (o.start != c.start || o.end != c.end) } }
        val neighRe = Regex("neigh|nei", RegexOption.IGNORE_CASE)
        val out = ArrayList<CellRow>()
        for (c in inner) {
            val f = HashMap<String, String>()
            for (l in leafRe.findAll(c.body)) f[l.groupValues[1].lowercase()] = l.groupValues[2].trim()
            fun find(vararg parts: String): String? = f.entries.firstOrNull { e -> parts.any { e.key.contains(it) } }?.value
            val pci = find("pci")?.let { Xml.num(it)?.toInt() }
            val earfcn = f.entries.firstOrNull { it.key.contains("earfcn") || it.key.contains("arfcn") || it.key == "freq" || it.key == "frequency" }?.value?.let { Xml.num(it)?.toInt() }
            val rawBand = find("band") ?: ""
            val nr = f.keys.any { it.startsWith("nr") } || rawBand.trim().uppercase().startsWith("N")
            val bandNum = Xml.num(rawBand)?.toInt()
            val band = if (bandNum == null) rawBand else (if (nr) "N" else "B") + bandNum
            val neighbor = insideTag(x, c.start, neighRe)
            val kind = (if (nr) "5G" else "4G") + (if (neighbor) " neighbor" else "")
            out.add(
                CellRow(
                    kind, find("celltype", "cell_type", "type") ?: "", earfcn, band,
                    find("bandwidth", "bw") ?: "", pci,
                    find("rsrp")?.let { Xml.num(it) }, find("rsrq")?.let { Xml.num(it) },
                    find("rssi")?.let { Xml.num(it) }, find("sinr")?.let { Xml.num(it) }
                )
            )
        }
        return out.sortedWith(compareBy({ it.kind.contains("neighbor") }, { it.kind }, { -(it.rsrp ?: -999.0) }))
    }
}

/** Reads the cell list from the learned endpoint (if any) and then from the candidate endpoints. Returns (path, rows). */
fun ModemClient.cellInfo(learned: String): Pair<String, List<CellRow>> {
    var bestPath = ""
    var best: List<CellRow> = emptyList()
    val paths = (if (learned.isNotEmpty()) listOf(learned) else emptyList()) + CellInfoParser.CANDIDATES
    for (p in paths) {
        val rows = try { CellInfoParser.parse(get(p)) } catch (e: Exception) { emptyList() }
        if (rows.size > best.size) { best = rows; bestPath = p }
        if (p == learned && rows.isNotEmpty()) break
    }
    return Pair(bestPath, best)
}

/** Turns a URL seen by the modem page ("../api/net/cell-info?x=1") into "/api/net/cell-info". */
fun normalizeApiPath(u: String): String {
    val i = u.indexOf("api/")
    if (i < 0) return ""
    return "/" + u.substring(i).substringBefore('?')
}
