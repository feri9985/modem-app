package com.farhad.modem.core

/** Reads many possible modem API paths (GET only) and reports the ones that answer, to find where 5G / cell data lives. */
data class ProbeHit(val path: String, val pciCount: Int, val snippet: String)

object Probe {
    val PATHS = listOf(
        "/api/device/information", "/api/device/basic_information", "/api/device/antenna_status", "/api/device/antenna_type",
        "/api/device/modem-info", "/api/device/nr-info", "/api/device/nrinfo", "/api/device/5g-info", "/api/device/cell-list",
        "/api/device/neighbor-cell-info", "/api/device/cell-status", "/api/device/network-info", "/api/device/lte-info",
        "/api/net/current-plmn", "/api/net/nr-cell-info", "/api/net/nrcellinfo", "/api/net/5g-cell-info", "/api/net/nr-neighbor",
        "/api/net/neighbor", "/api/net/nei-cell-info", "/api/net/cell-list", "/api/net/celllist", "/api/net/cell-scan",
        "/api/net/scan-cell", "/api/net/nsa-info", "/api/net/sa-info", "/api/net/nr-band-info", "/api/net/nrband",
        "/api/net/nr-lock-freq", "/api/net/lte-cell-info", "/api/net/cell-info", "/api/net/cellinfo", "/api/net/network-info",
        "/api/ntwk/celllock", "/api/ntwk/cell-info", "/api/ntwk/neighbor-cell", "/api/ntwk/nrcell", "/api/ntwk/network-info",
        "/api/ntwk/status", "/api/ntwk/nr-info", "/api/ntwk/lte-info", "/api/ntwk/cell-list",
        "/api/monitoring/status", "/api/monitoring/converged-status", "/api/monitoring/nr-status", "/api/monitoring/cell-info",
        "/api/cell/info", "/api/cell/neighbor", "/api/cell/list", "/api/cell/status", "/api/nr/info", "/api/nr/cell",
        "/api/nr/status", "/api/nr/neighbor", "/api/lte/info", "/api/lte/cell", "/api/lte/neighbor",
        "/api/diagnosis/cell-info", "/api/diagnosis/nr-info", "/api/diagnosis/radio-info", "/api/diagnose/cell-info",
        "/api/engineering/cell-info", "/api/engineering/nr-info", "/api/system/cell-info", "/api/system/nr-info",
        "/api/net/engineer-mode", "/api/device/engineer-mode", "/api/net/radio-info", "/api/device/radio-info",
        "/api/net/net-feature-switch", "/api/device/signal-detail", "/api/net/signal-detail", "/api/net/signal-info",
        "/api/net/nr-signal", "/api/net/5g-signal", "/api/device/nr-signal", "/api/device/5g-signal",
        "/api/net/plmn-list", "/api/net/register", "/api/net/net-mode-list", "/api/net/pci-info", "/api/net/ltepci",
        "/api/net/nrpci", "/api/device/pci", "/api/net/cell-id", "/api/net/serving-cell", "/api/net/servingcell",
        "/api/net/ca-info", "/api/net/carrier-aggregation", "/api/device/ca-info", "/api/net/ltecainfo"
    )

    fun count(x: String): Int = Regex("pci", RegexOption.IGNORE_CASE).findAll(x).count()

    fun looksUseful(x: String): Boolean = x.contains("<response") && !x.contains("<error>")

    fun snippet(x: String): String =
        Regex("<(\\w+)>([^<]*)</\\1>").findAll(x).take(14).joinToString("  ") { it.groupValues[1] + "=" + it.groupValues[2].trim().take(30) }
}

fun ModemClient.probe(progress: (Int, Int) -> Unit = { _, _ -> }): List<ProbeHit> {
    val out = ArrayList<ProbeHit>()
    Probe.PATHS.forEachIndexed { i, p ->
        progress(i + 1, Probe.PATHS.size)
        try {
            val x = get(p)
            if (Probe.looksUseful(x)) out.add(ProbeHit(p, Probe.count(x), Probe.snippet(x)))
        } catch (e: Exception) {
        }
    }
    return out.sortedByDescending { it.pciCount }
}
