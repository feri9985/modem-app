package com.farhad.modem.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Store
import com.farhad.modem.core.Bars
import com.farhad.modem.core.Brand
import com.farhad.modem.core.Operators
import kotlinx.coroutines.delay

/** Colored badge with the operator's name (not an official logo). */
@Composable
fun OperatorBadge(b: Brand, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(8.dp)).background(Color(b.color)).padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(b.short, color = if (b.darkText) Color(0xFF1B1B1B) else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Phone-style antenna: five bars that grow in height. */
@Composable
fun Antenna(level: Int, on: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom, modifier = Modifier.height(16.dp)) {
        for (i in 1..5) {
            Box(
                Modifier.width(4.dp).height((4 + i * 2).dp).clip(RoundedCornerShape(1.dp))
                    .background(if (i <= level) on else Color.White.copy(alpha = 0.25f))
            )
        }
    }
}

/** Under the title: operator badge, network type, 5G and 4G antenna bars (updated with every poll). */
@Composable
fun StatusBar() {
    val snap by Store.snapshot.collectAsState()
    val opr by Store.operator.collectAsState()
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    val s = snap
    val brand = Operators.brand(opr?.plmn ?: "", opr?.name ?: "")
    val age = if (s == null) -1L else (now - s.t) / 1000
    Row(
        Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.30f)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OperatorBadge(brand)
        Text(opr?.netType ?: "", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
        if (age > 6) Text("⚠ " + age + " s old", color = C.yellow, fontSize = 11.sp)
        if (s?.nrRsrp != null) {
            Text("5G", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Antenna(Bars.fromRsrp(s.nrRsrp), Color(0xFFE060D0))
        }
        if (s?.rsrp != null) {
            Text("4G", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Antenna(Bars.fromRsrp(s.rsrp), C.green)
        }
    }
}
