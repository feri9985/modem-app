package com.farhad.modem.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Act
import com.farhad.modem.Store
import com.farhad.modem.core.Bands
import com.farhad.modem.core.Metrics
import com.farhad.modem.core.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun mbText(v: Double?): String = if (v == null) "-" else String.format(java.util.Locale.US, "%.1f", v)

@Composable
fun HomeScreen() {
    val snap by Store.snapshot.collectAsState()
    val traffic by Store.traffic.collectAsState()
    val opr by Store.operator.collectAsState()
    val binfo by Store.bandInfo.collectAsState()
    val profiles by Store.profiles.collectAsState()
    val auto by Store.auto.collectAsState()
    val autoMsg by Store.autoMsg.collectAsState()
    val monitoring by Store.monitoring.collectAsState()
    val scope = rememberCoroutineScope()

    val selL = Store.selL
    val selN = Store.selN
    var option by Store.option
    var en5 by Store.en5
    var pname by remember { mutableStateOf("") }
    var armed by remember { mutableStateOf("") }

    // اگه باندها هنوز خونده نشدن بخون
    LaunchedEffect(Unit) {
        if (Store.bandInfo.value == null) launch(Dispatchers.IO) { Act.refreshBands() }
    }
    // وقتی وضعیت باندهای مودم عوض شد، انتخاب‌ها رو با وضعیت واقعی مودم یکی کن
    LaunchedEffect(binfo) {
        val b = binfo
        if (b != null && b !== Store.selFor) {
            Store.selFor = b
            selL.clear()
            selL.addAll(Bands.bitsOf(b.lteCur, 64).filter { b.lteSup.contains(it) })
            selN.clear()
            selN.addAll(Bands.bitsOf(b.nrCur, 128).filter { b.nrSup.contains(it) })
        }
    }
    // دکمه‌ی حذف پروفایل: بار اول «؟» می‌شه، تا ۲.۵ ثانیه فرصت تأیید داری
    LaunchedEffect(armed) {
        if (armed.isNotEmpty()) {
            delay(2500)
            armed = ""
        }
    }

    fun saveProfile() {
        val l = Bands.mask(selL.toList())
        val n = Bands.mask(selN.toList())
        val name = pname.trim()
        if (l.signum() == 0 && n.signum() == 0) {
            Store.toast("اول باندها رو انتخاب کن")
        } else if (name.isEmpty()) {
            Store.toast("یه اسم برای پروفایل بنویس")
        } else {
            val np = Profile(name, Bands.hex(l), Bands.hex(n), option, en5)
            Store.saveProfiles(Store.profiles.value.filter { it.name != name } + np)
            pname = ""
            Store.toast("پروفایل ذخیره شد ✓")
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(8.dp)) {
            if (!monitoring) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(C.dangerBtn).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("پایش متوقف است", color = C.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Btn("شروع", Modifier.width(90.dp)) { Act.startMonitor() }
                }
                Gap(8)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    opr?.let { it.name + " " + it.plmn } ?: "...",
                    color = C.gold, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Tag(opr?.netType ?: "-")
            }
            Gap(6)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(C.dlBg).padding(8.dp), contentAlignment = Alignment.Center) {
                    Text("↓ " + mbText(traffic?.downMbps) + " Mbps", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = C.text)
                }
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(C.ulBg).padding(8.dp), contentAlignment = Alignment.Center) {
                    Text("↑ " + mbText(traffic?.upMbps) + " Mbps", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = C.text)
                }
            }
            Gap(6)
            val s = snap
            val tags = mutableListOf<String>()
            if (s != null) {
                s.band?.let { tags.add("Band: B$it") }
                s.pci?.let { tags.add("PCI: $it") }
                if (s.cellId.isNotEmpty()) tags.add("Cell: " + s.cellId)
                if (s.tac.isNotEmpty()) tags.add("TAC: " + s.tac)
                if (s.dlBw.isNotEmpty()) tags.add("4G BW: " + s.dlBw)
                if (s.nrBw.isNotEmpty()) tags.add("5G BW: " + s.nrBw)
            }
            TagRows(tags)
            SignalBar("4G RSRP", s?.rsrp, Metrics.RSRP)
            SignalBar("4G RSRQ", s?.rsrq, Metrics.RSRQ)
            SignalBar("4G SINR", s?.sinr, Metrics.SINR)
            SignalBar("4G RSSI", s?.rssi, Metrics.RSSI)
            SignalBar("5G RSRP", s?.nrRsrp, Metrics.RSRP)
            SignalBar("5G RSRQ", s?.nrRsrq, Metrics.RSRQ)
            SignalBar("5G SINR", s?.nrSinr, Metrics.SINR)

            Sec("حالت شبکه")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    Pair("Auto", "00"), Pair("5G فقط", "08"), Pair("4G", "03"), Pair("3G", "02"), Pair("2G", "01")
                ).forEach { q ->
                    Btn(q.first, Modifier.weight(1f)) {
                        val opt = option
                        scope.launch(Dispatchers.IO) { Act.quick(q.first, q.second, opt) }
                    }
                }
            }

            // ---------- پروفایل‌ها ----------
            Sec("پروفایل‌ها (یک‌ضربه = اعمال)")
            if (profiles.isEmpty()) Tag("هنوز پروفایلی ذخیره نشده")
            profiles.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn(p.name + "  (" + p.describe() + ")", Modifier.weight(1f)) {
                        scope.launch(Dispatchers.IO) { Act.applyProfile(p, false) }
                    }
                    Btn(if (armed == p.name) "؟" else "✕", Modifier.width(52.dp), kind = 3) {
                        if (armed == p.name) {
                            Store.saveProfiles(Store.profiles.value.filter { it.name != p.name })
                            armed = ""
                        } else {
                            armed = p.name
                        }
                    }
                }
            }
            Sec("سوییچ خودکار: اگه میانگین SINR (اولی) تو این مدت (دومی) زیر حد بمونه، پروفایل بعدی امتحان می‌شه. حداقل ۲ پروفایل لازمه")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = auto.on, onCheckedChange = { Store.setAutoOn(it) })
                Text("فعال", color = C.text, fontSize = 15.sp)
                Drop(
                    listOf(0, 3, 5, 8, 10).map { Pair(it.toString(), "$it dB") }, auto.thr.toString(), Modifier.weight(1f)
                ) { Store.saveAuto(Store.auto.value.copy(thr = it.toInt())) }
                Drop(
                    listOf(2, 3, 5, 10).map { Pair(it.toString(), "$it دقیقه") }, auto.mins.toString(), Modifier.weight(1f)
                ) { Store.saveAuto(Store.auto.value.copy(mins = it.toInt())) }
            }
            Gap(4)
            Tag(if (!auto.on) "خاموش" else autoMsg.ifEmpty { "فعال" })

            // ---------- قفل باند ----------
            Sec("قفل باند: باندها رو انتخاب کن، بعد Apply")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Drop(
                    listOf(Pair("", "5G: بدون تغییر"), Pair("0", "5G NSA"), Pair("1", "5G SA"), Pair("2", "5G SA+NSA")),
                    option, Modifier.weight(1f)
                ) { option = it }
                Checkbox(checked = en5, onCheckedChange = { en5 = it })
                Text("4G+5G", color = C.text, fontSize = 15.sp)
            }
            Gap(6)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("همه باندها", Modifier.weight(1f)) {
                    selL.clear()
                    selL.addAll(binfo?.lteSup ?: emptyList())
                }
                Btn("پاک کردن", Modifier.weight(1f)) { selL.clear() }
            }
            Sec("باندهای 4G")
            BandGrid(binfo?.lteSup ?: emptyList(), selL, "B", Bands.LTE_FREQ, false)
            Sec("باندهای 5G (قفل باند 5G فقط وقتی کار می‌کنه که مودم تگ NRBand بده؛ وگرنه از دکمه‌ی «5G فقط» استفاده کن)")
            BandGrid(binfo?.nrSup ?: listOf(78, 48), selN, "n", Bands.NR_FREQ, true)

            Sec("ذخیره‌ی انتخاب فعلی باندها به‌عنوان پروفایل")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = pname, onValueChange = { pname = it },
                    placeholder = { Text("اسم پروفایل (مثلاً n78 شب)") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Btn("ذخیره", Modifier.width(90.dp)) { saveProfile() }
            }
            Gap(12)
        }
        Box(Modifier.fillMaxWidth().background(C.panel).padding(8.dp)) {
            Btn("Apply", Modifier.fillMaxWidth(), kind = 1) {
                val l = Bands.mask(selL.toList())
                val n = Bands.mask(selN.toList())
                val opt = option
                val e5 = en5
                scope.launch(Dispatchers.IO) { Act.applyBands(l, n, opt, e5, "", false) }
            }
        }
    }
}

@Composable
fun BandGrid(bands: List<Int>, sel: MutableList<Int>, prefix: String, freq: Map<Int, Int>, nr: Boolean) {
    bands.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            row.forEach { b ->
                val on = sel.contains(b)
                Chip(prefix + b, freq[b]?.toString() ?: "", on, nr, Modifier.weight(1f)) {
                    if (on) sel.remove(b) else sel.add(b)
                }
            }
            for (i in row.size until 3) Spacer(Modifier.weight(1f))
        }
    }
}
