package com.farhad.modem

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/** بیپ کوتاه با فرکانس دلخواه (برای جهت‌یابی آنتن). */
class Beeper {
    private val rate = 22050
    private val handler = Handler(Looper.getMainLooper())

    fun beep(freq: Double) {
        try {
            val n = (rate * 0.09).toInt()
            val fade = rate * 0.01
            val data = ShortArray(n) { i ->
                val env = min(1.0, min(i.toDouble(), (n - i).toDouble()) / fade)
                (sin(2.0 * PI * freq * i / rate) * env * 0.5 * Short.MAX_VALUE).toInt().toShort()
            }
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(data, 0, n)
            track.play()
            handler.postDelayed({ track.release() }, 500)
        } catch (e: Exception) {
            Store.log("beep ERR $e")
        }
    }
}
