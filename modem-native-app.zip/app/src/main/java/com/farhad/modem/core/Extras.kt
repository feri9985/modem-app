package com.farhad.modem.core

/** Extra modem features: reboot, data usage, SMS, DNS, Wi-Fi name, MAC filter (block devices). Pure Kotlin. */

// ---------- helpers ----------
fun unescapeXml(s: String): String {
    var r = Regex("&#x([0-9a-fA-F]+);").replace(s) { m -> m.groupValues[1].toInt(16).toChar().toString() }
    r = Regex("&#(\\d+);").replace(r) { m -> m.groupValues[1].toInt().toChar().toString() }
    return r.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
}

/** Sets <tag>value</tag> inside xml. Replaces an existing tag (also the empty <tag/> form) or appends it. */
fun setTag(xml: String, tag: String, value: String): String {
    val t = Regex.escape(tag)
    val full = Regex("<$t>[\\s\\S]*?</$t>")
    val empty = Regex("<$t\\s*/>")
    val rep = "<$tag>$value</$tag>"
    return when {
        full.containsMatchIn(xml) -> full.replaceFirst(xml, java.util.regex.Matcher.quoteReplacement(rep))
        empty.containsMatchIn(xml) -> empty.replaceFirst(xml, java.util.regex.Matcher.quoteReplacement(rep))
        else -> xml + rep
    }
}

fun hasTag(xml: String, tag: String): Boolean {
    val t = Regex.escape(tag)
    return Regex("<$t>").containsMatchIn(xml) || Regex("<$t\\s*/>").containsMatchIn(xml)
}

/** Turns a GET <response>...</response> into a POST <request>...</request> (keeps every field the modem sent). */
fun responseToRequest(x: String): String {
    val inner = x.substringAfter("<response>", "").substringBeforeLast("</response>", "")
    return "<request>$inner</request>"
}

fun errorText(r: String): String {
    val c = Xml.errorCode(r)
    return if (c.isNotEmpty()) "error $c" else r.replace(Regex("\\s+"), " ").take(80)
}

// ---------- reboot ----------
fun ModemClient.reboot(): String = post("/api/device/control", "<request><Control>1</Control></request>")

// ---------- data usage ----------
data class Usage(val monthDown: Long, val monthUp: Long, val totalDown: Long, val totalUp: Long, val monthKnown: Boolean)

fun formatBytes(b: Long): String {
    val kb = 1024.0
    val d = b.toDouble()
    return when {
        d >= kb * kb * kb -> String.format(java.util.Locale.US, "%.2f GB", d / (kb * kb * kb))
        d >= kb * kb -> String.format(java.util.Locale.US, "%.1f MB", d / (kb * kb))
        d >= kb -> String.format(java.util.Locale.US, "%.0f KB", d / kb)
        else -> "$b B"
    }
}

fun parseUsage(month: String, total: String): Usage {
    fun l(x: String, k: String): Long = Xml.num(Xml.tag(x, k))?.toLong() ?: 0L
    return Usage(
        l(month, "CurrentMonthDownload"), l(month, "CurrentMonthUpload"),
        l(total, "TotalDownload"), l(total, "TotalUpload"),
        month.contains("CurrentMonthDownload")
    )
}

fun ModemClient.usage(): Usage = parseUsage(get("/api/monitoring/month-statistics"), get("/api/monitoring/traffic-statistics"))

// ---------- SMS ----------
data class Sms(val index: String, val phone: String, val content: String, val date: String, val unread: Boolean)

fun parseSms(x: String): List<Sms> = Xml.blocks(x, "Message").map {
    Sms(
        Xml.tag(it, "Index"), unescapeXml(Xml.tag(it, "Phone")), unescapeXml(Xml.tag(it, "Content")),
        Xml.tag(it, "Date"), Xml.tag(it, "Smstat") == "0"
    )
}

/** box: 1 = inbox, 2 = sent, 3 = drafts. Returns (messages, raw reply). */
fun ModemClient.smsList(box: Int = 1, page: Int = 1, count: Int = 20): Pair<List<Sms>, String> {
    val r = post(
        "/api/sms/sms-list",
        "<request><PageIndex>$page</PageIndex><ReadCount>$count</ReadCount><BoxType>$box</BoxType><SortType>0</SortType><Ascending>0</Ascending><UnreadPreferred>0</UnreadPreferred></request>"
    )
    return Pair(parseSms(r), r)
}

fun ModemClient.smsDelete(index: String): String = post("/api/sms/delete-sms", "<request><Index>" + Xml.escape(index) + "</Index></request>")

// ---------- DNS (DHCP settings, read-modify-write) ----------
data class DhcpInfo(val primary: String, val secondary: String, val dnsStatus: String, val raw: String)

fun parseDhcp(x: String): DhcpInfo = DhcpInfo(Xml.tag(x, "PrimaryDns"), Xml.tag(x, "SecondaryDns"), Xml.tag(x, "DnsStatus"), x)

private val IPV4 = Regex("^((25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1?\\d?\\d)$")
fun validIpv4(s: String): Boolean = IPV4.matches(s.trim())

/** Builds the POST body: everything the modem sent, with only the DNS fields changed. Null if the reply has no DNS fields. */
fun dhcpRequest(x: String, primary: String, secondary: String): String? {
    if (!hasTag(x, "PrimaryDns")) return null
    var r = responseToRequest(x)
    r = setTag(r, "PrimaryDns", primary)
    r = setTag(r, "SecondaryDns", secondary)
    return r
}

fun ModemClient.dhcp(): DhcpInfo = parseDhcp(get("/api/dhcp/settings"))

/** Returns "" on success, otherwise an error text. */
fun ModemClient.setDns(primary: String, secondary: String): String {
    val x = get("/api/dhcp/settings")
    val body = dhcpRequest(x, primary, secondary) ?: return "This modem did not report DNS fields: " + errorText(x)
    val r = post("/api/dhcp/settings", body)
    return if (Xml.isOk(r)) "" else errorText(r)
}

// ---------- Wi-Fi name (read-modify-write) ----------
data class WifiNet(val index: String, val ssid: String, val enabled: Boolean)

fun parseWifi(x: String): List<WifiNet> = Xml.blocks(x, "Ssid").map {
    WifiNet(Xml.tag(it, "Index"), unescapeXml(Xml.tag(it, "WifiSsid")), Xml.tag(it, "WifiEnable") != "0")
}

fun validSsid(s: String): Boolean = s.isNotEmpty() && s.toByteArray(Charsets.UTF_8).size <= 32 && !s.contains('<') && !s.contains('>')

/** Builds the POST body that renames the Wi-Fi with this Index. Null if that Wi-Fi is not in the reply. */
fun wifiRenameRequest(x: String, index: String, newName: String): String? {
    val re = Regex("<Ssid>([\\s\\S]*?)</Ssid>")
    var found = false
    val blocks = StringBuilder()
    for (m in re.findAll(x)) {
        var b = m.groupValues[1]
        if (Xml.tag(b, "Index") == index) {
            b = setTag(b, "WifiSsid", Xml.escape(newName))
            found = true
        }
        blocks.append("<Ssid>").append(b).append("</Ssid>")
    }
    if (!found) return null
    return "<request><Ssids>$blocks</Ssids><WifiRestart>1</WifiRestart></request>"
}

fun ModemClient.wifiNetworks(): Pair<List<WifiNet>, String> {
    val x = get("/api/wlan/multi-basic-settings")
    return Pair(parseWifi(x), x)
}

/** Returns "" on success, otherwise an error text. */
fun ModemClient.renameWifi(index: String, newName: String): String {
    val x = get("/api/wlan/multi-basic-settings")
    val body = wifiRenameRequest(x, index, newName) ?: return "Wi-Fi $index not found in the modem reply"
    val r = post("/api/wlan/multi-basic-settings", body)
    return if (Xml.isOk(r)) "" else errorText(r)
}

// ---------- MAC filter (block devices) ----------
data class BlockedDevice(val mac: String, val name: String)

fun normMac(s: String): String = s.trim().uppercase().replace('-', ':')

/** Devices listed in the modem's MAC filter (deduplicated over all Wi-Fi networks). */
fun parseMacFilter(x: String): List<BlockedDevice> {
    val out = LinkedHashMap<String, BlockedDevice>()
    for (b in Xml.blocks(x, "Ssid")) {
        for (k in 0..9) {
            val mac = normMac(Xml.tag(b, "WifiMacFilterMac$k"))
            if (mac.isNotEmpty()) out[mac] = BlockedDevice(mac, unescapeXml(Xml.tag(b, "wifihostname$k")))
        }
    }
    return out.values.toList()
}

/** "deny" (2), "allow" (1) or "off" (0) of the first Wi-Fi network; "" if unknown. */
fun macFilterMode(x: String): String =
    when (Xml.tag(Xml.blocks(x, "Ssid").firstOrNull() ?: "", "WifiMacFilterStatus")) { "2" -> "deny"; "1" -> "allow"; "0" -> "off"; else -> "" }

/**
 * Adds (block = true) or removes (block = false) a MAC in every Wi-Fi network's filter list.
 * Returns the POST body, or null when the reply has no filter fields. Throws IllegalStateException with a message
 * when the filter is in "allow" mode or all 10 slots are used.
 */
fun macFilterRequest(x: String, mac0: String, name: String, block: Boolean): String? {
    val mac = normMac(mac0)
    val re = Regex("<Ssid>([\\s\\S]*?)</Ssid>")
    if (!re.containsMatchIn(x) || !hasTag(x, "WifiMacFilterStatus")) return null
    val blocks = StringBuilder()
    for (m in re.findAll(x)) {
        var b = m.groupValues[1]
        val macs = (0..9).map { normMac(Xml.tag(b, "WifiMacFilterMac$it")) }
        if (block) {
            val status = Xml.tag(b, "WifiMacFilterStatus")
            if (status == "1") throw IllegalStateException("The modem's MAC filter is in allow-list mode; switch it to deny mode first")
            if (!macs.contains(mac)) {
                val slot = macs.indexOfFirst { it.isEmpty() }
                if (slot < 0) throw IllegalStateException("The MAC filter list is full (10 devices)")
                b = setTag(b, "WifiMacFilterMac$slot", mac)
                b = setTag(b, "wifihostname$slot", Xml.escape(name))
            }
            b = setTag(b, "WifiMacFilterStatus", "2")
        } else {
            for (k in 0..9) {
                if (macs[k] == mac) {
                    b = setTag(b, "WifiMacFilterMac$k", "")
                    b = setTag(b, "wifihostname$k", "")
                }
            }
        }
        blocks.append("<Ssid>").append(b).append("</Ssid>")
    }
    return "<request><Ssids>$blocks</Ssids></request>"
}

private const val MACF = "/api/wlan/multi-macfilter-settings"

fun ModemClient.macFilter(): String = get(MACF)

/** Returns "" on success, otherwise an error text. */
fun ModemClient.setBlocked(mac: String, name: String, block: Boolean): String {
    val x = get(MACF)
    val body = try {
        macFilterRequest(x, mac, name, block) ?: return "This modem's MAC filter format is not recognized: " + errorText(x)
    } catch (e: IllegalStateException) {
        return e.message ?: "Cannot change the MAC filter"
    }
    val r = post(MACF, body)
    return if (Xml.isOk(r)) "" else errorText(r)
}

// ---------- modem identity ----------
data class DeviceInfo(val name: String, val software: String, val hardware: String)

fun parseDevice(x: String): DeviceInfo? {
    val n = unescapeXml(Xml.tag(x, "DeviceName"))
    if (n.isEmpty()) return null
    return DeviceInfo(n, unescapeXml(Xml.tag(x, "SoftwareVersion")), unescapeXml(Xml.tag(x, "HardwareVersion")))
}

fun ModemClient.deviceInfo(): DeviceInfo? = parseDevice(get("/api/device/information"))
