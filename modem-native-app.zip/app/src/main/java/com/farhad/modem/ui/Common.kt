package com.farhad.modem.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.core.Level
import com.farhad.modem.core.Metric
import com.farhad.modem.core.fmt

object C {
    val bg = Color(0xFF0C1118)
    val panel = Color(0xFF141B24)
    val card = Color(0xFF1A2430)
    val btn = Color(0xFF2C3746)
    val bar = Color(0xFF243041)
    val blue = Color(0xFF2F7BF5)
    val red = Color(0xFFE5484D)
    val dangerBtn = Color(0xFF4A2530)
    val green = Color(0xFF2ECC71)
    val yellow = Color(0xFFF5C542)
    val gold = Color(0xFFFFD84D)
    val text = Color(0xFFE8EDF3)
    val mute = Color(0xFF8A97A8)
    val hdr1 = Color(0xFFC7000B)
    val hdr2 = Color(0xFF6E0A1C)
    val lteOn = Color(0xFF1F7A3D)
    val nrOn = Color(0xFF7A1F6E)
    val nrBorder = Color(0xFFE060D0)
    val dlBg = Color(0xFF0F4D2A)
    val ulBg = Color(0xFF5A4A0A)
    val chartBg = Color(0xFF0F151D)
    val line = Color(0xFF5AA2FF)
    val orange = Color(0xFFFF9F43)
}

fun levelColor(l: Level): Color = when (l) {
    Level.GOOD -> C.green
    Level.OK -> C.yellow
    Level.BAD -> C.red
}

fun levelName(l: Level): String = when (l) {
    Level.GOOD -> "عالی"
    Level.OK -> "متوسط"
    Level.BAD -> "بد"
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.blue,
            background = C.bg,
            surface = C.card,
            onSurface = C.text,
            onBackground = C.text
        ),
        content = content
    )
}

@Composable
fun Sec(t: String) {
    Text(t, color = C.mute, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
}

/** kind: 0 = معمولی، 1 = آبی (اصلی)، 2 = قرمز، 3 = قرمز تیره (حذف) */
@Composable
fun Btn(text: String, modifier: Modifier = Modifier, kind: Int = 0, onClick: () -> Unit) {
    val bg = when (kind) {
        1 -> C.blue
        2 -> C.red
        3 -> C.dangerBtn
        else -> C.btn
    }
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor = Color.White),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 13.dp)
    ) {
        Text(text, fontSize = if (kind == 1) 17.sp else 14.sp, fontWeight = if (kind == 1) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun Tag(text: String) {
    Box(Modifier.clip(RoundedCornerShape(7.dp)).background(C.card).padding(horizontal = 9.dp, vertical = 4.dp)) {
        Text(text, fontSize = 12.sp, color = C.text)
    }
}

/** تگ‌ها رو ردیف‌های ۳تایی می‌چینه */
@Composable
fun TagRows(items: List<String>) {
    items.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            row.forEach { Tag(it) }
        }
    }
}

@Composable
fun SignalBar(label: String, v: Double?, m: Metric) {
    val lvl = if (v == null) null else m.level(v)
    val col = if (lvl == null) C.btn else levelColor(lvl)
    val frac = if (v == null) 0f else maxOf(0.05, m.fraction(v)).toFloat()
    val txt = if (v == null || lvl == null) "-" else fmt(v) + " " + m.unit + "  " + levelName(lvl)
    Box(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).height(28.dp)
            .clip(RoundedCornerShape(14.dp)).background(C.bar)
    ) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(col))
        Row(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(txt, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@Composable
fun Chip(text: String, sub: String, on: Boolean, nr: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = if (on) (if (nr) C.nrOn else C.lteOn) else C.card
    val br = if (on) (if (nr) C.nrBorder else C.green) else C.btn
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier.clip(shape).background(bg).border(1.dp, br, shape).clickable(onClick = onClick).padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = C.mute, modifier = Modifier.padding(start = 5.dp))
        }
    }
}

/** لیست کشویی ساده: options = (مقدار، متن) */
@Composable
fun Drop(options: List<Pair<String, String>>, value: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.first == value }?.second ?: value
    Box(modifier) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(C.card)
                .clickable { open = true }.padding(12.dp)
        ) {
            Text(label + "  ▾", fontSize = 15.sp, color = C.text)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(o.second) }, onClick = { onChange(o.first); open = false })
            }
        }
    }
}

@Composable
fun Gap(h: Int = 6) {
    Spacer(Modifier.height(h.dp))
}
