package com.farhad.modem.core

import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * کلاینت HTTP مودم هواوی (لاگین SCRAM + توکن CSRF + لاگین خودکار دوباره‌ی نشست).
 * [opener] اتصال رو می‌سازه؛ توی اندروید اتصال از شبکه‌ی وای‌فای مودم باز می‌شه.
 */
class ModemClient(
    private val opener: (URL) -> HttpURLConnection = { it.openConnection() as HttpURLConnection },
    @Volatile var log: (String) -> Unit = { }
) {
    class Resp(val code: Int, val body: String)

    companion object {
        const val FORM = "application/x-www-form-urlencoded; charset=UTF-8"
        const val XML = "application/xml"
        private val SESSION_ERRORS = setOf("125001", "125002", "125003", "100003")
        private const val XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
    }

    @Volatile var base = ""
        private set
    @Volatile private var host = ""
    @Volatile private var cookie = ""
    @Volatile private var token = ""
    @Volatile private var user = ""
    @Volatile private var pass = ""
    @Volatile private var lastLoginAt = 0L
    @Volatile private var reloginFails = 0
    private val loginLock = Any()

    val hasSession: Boolean get() = user.isNotEmpty()

    private fun http(method: String, path: String, body: String, contentType: String, tok: String?, timeoutMs: Int): Resp {
        val c = opener(URL(base + path))
        try {
            c.requestMethod = method
            c.connectTimeout = 8000
            c.readTimeout = timeoutMs
            val ck = cookie
            if (ck.isNotEmpty()) c.setRequestProperty("Cookie", ck)
            val tk = tok ?: token
            if (tk.isNotEmpty()) c.setRequestProperty("__RequestVerificationToken", tk)
            if (method == "POST") {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType)
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            var one = ""
            var plain = ""
            for ((k, v) in c.headerFields) {
                if (k == null || v.isNullOrEmpty()) continue
                if (k.equals("__RequestVerificationTokenone", true)) one = v[0]
                if (k.equals("__RequestVerificationToken", true)) plain = v[0]
                if (k.equals("Set-Cookie", true)) v.firstOrNull { it.startsWith("SessionID=") }?.let { cookie = it.substringBefore(";") }
            }
            if (one.isNotEmpty()) token = one else if (plain.isNotEmpty()) token = plain
            val stream = if (code < 400) c.inputStream else c.errorStream
            val text = stream?.readBytes()?.toString(Charsets.UTF_8) ?: ""
            return Resp(code, text)
        } finally {
            c.disconnect()
        }
    }

    // ---------- login (SCRAM-SHA256) ----------
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    private fun hmac(key: ByteArray, data: ByteArray): ByteArray =
        Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(key, "HmacSHA256")) }.doFinal(data)

    /** "OK" اگه موفق بود، وگرنه متن خطا. */
    fun login(hostAddr: String, u: String, pw: String): String = synchronized(loginLock) {
        try {
            val r = doLogin(hostAddr.trim(), u, pw)
            if (r == "OK") {
                user = u; pass = pw; lastLoginAt = System.currentTimeMillis(); reloginFails = 0
            }
            r
        } catch (e: Exception) {
            "ERR $e"
        }
    }

    private fun doLogin(h: String, u: String, pw: String): String {
        base = "http://$h"
        host = h
        cookie = ""; token = ""
        val tk = Xml.tag(http("GET", "/api/webserver/token", "", FORM, null, 10000).body, "token")
        token = ""
        val st = http("GET", "/api/webserver/SesTokInfo", "", FORM, null, 10000).body
        cookie = Xml.tag(st, "SesInfo")
        token = if (tk.length > 32) tk.takeLast(32) else if (tk.isNotEmpty()) tk else Xml.tag(st, "TokInfo")
        val fn = hex(ByteArray(32).also { SecureRandom().nextBytes(it) })
        val ch = http(
            "POST", "/api/user/challenge_login",
            XML_HEAD + "<request><username>" + Xml.escape(u) + "</username><firstnonce>" + fn + "</firstnonce><mode>1</mode></request>",
            FORM, null, 10000
        ).body
        val sn = Xml.tag(ch, "servernonce")
        if (sn.isEmpty()) return "FAIL challenge: " + ch.take(200)
        val iters = Xml.tag(ch, "iterations").toIntOrNull() ?: return "FAIL iterations: " + ch.take(200)
        val salted = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), unhex(Xml.tag(ch, "salt")), iters, 256)).encoded
        // نکته‌ی مهم: جاوااسکریپت مودم هواوی آرگومان‌های HMAC رو برعکس RFC 5802 می‌ده (کلید و پیام جابه‌جا)
        val authMsg = "$fn,$sn,$sn".toByteArray()
        val ck = hmac("Client Key".toByteArray(), salted)
        val sk = MessageDigest.getInstance("SHA-256").digest(ck)
        val sig = hmac(authMsg, sk)
        val proof = hex(ByteArray(32) { (ck[it].toInt() xor sig[it].toInt()).toByte() })
        val expectedServerSig = hex(hmac(authMsg, hmac("Server Key".toByteArray(), salted)))
        val r = http(
            "POST", "/api/user/authentication_login",
            XML_HEAD + "<request><clientproof>" + proof + "</clientproof><finalnonce>" + sn + "</finalnonce></request>",
            FORM, null, 10000
        ).body
        if (r.contains("<error>")) return "FAIL: " + r.take(200) + " | tokenLen=" + token.length + " cookieLen=" + cookie.length
        val sigOk = Xml.tag(r, "serversignature").equals(expectedServerSig, true)
        log("login: server signature " + (if (sigOk) "OK" else "MISMATCH (login accepted anyway)"))
        return "OK"
    }

    private fun relogin(): Boolean = synchronized(loginLock) {
        if (user.isEmpty() || host.isEmpty()) return false
        // یه نخ دیگه همین الان لاگین کرده؛ دوباره نزن
        if (System.currentTimeMillis() - lastLoginAt < 3000L) return true
        // چند بار پشت‌سرهم شکست خورد: دیگه تلاش نکن تا مودم قفل نشه
        if (reloginFails >= 3) return false
        val r = try { doLogin(host, user, pass) } catch (e: Exception) { "ERR $e" }
        log("relogin -> " + r.take(80))
        if (r == "OK") { lastLoginAt = System.currentTimeMillis(); reloginFails = 0; true } else { reloginFails++; false }
    }

    fun logout() {
        user = ""; pass = ""; cookie = ""; token = ""; reloginFails = 0
    }

    private fun sessionError(r: Resp): Boolean =
        r.code == 401 || r.code == 403 || SESSION_ERRORS.contains(Xml.errorCode(r.body))

    // ---------- API ----------
    /** GET؛ اگه نشست تموم شده بود یه بار دوباره لاگین می‌کنه. خطای شبکه رو throw می‌کنه. */
    fun get(path: String, timeoutMs: Int = 12000): String {
        var r = http("GET", path, "", FORM, null, timeoutMs)
        if (sessionError(r) && relogin()) r = http("GET", path, "", FORM, null, timeoutMs)
        return r.body
    }

    /** توکن CSRF تازه از صفحه‌ی مودم (آخرین meta). */
    private fun pageToken(): String {
        return try {
            val r = http("GET", "/html/home.html", "", FORM, null, 10000)
            val ms = Regex("name=\"csrf_token\" content=\"([^\"]*)\"").findAll(r.body).toList()
            if (ms.isEmpty()) "" else ms[ms.size - 1].groupValues[1]
        } catch (e: Exception) {
            ""
        }
    }

    /** POST؛ خطای شبکه رو به‌صورت "ERR ..." برمی‌گردونه (هیچ‌وقت throw نمی‌کنه). */
    fun post(path: String, body: String, timeoutMs: Int = 20000): String {
        try {
            var r = Resp(0, "")
            for (tries in 0..1) {
                val t = pageToken().ifEmpty { token }
                r = http("POST", path, body, XML, t, timeoutMs)
                log("POST " + path + " -> " + r.body.take(300))
                if (tries == 0 && sessionError(r) && relogin()) continue
                break
            }
            return r.body
        } catch (e: Exception) {
            log("POST $path ERR $e")
            return "ERR $e"
        }
    }
}

/** Turns a modem login error into a short English message (with remaining attempts before lockout). */
fun loginMessage(r: String): String {
    if (r == "OK") return ""
    val code = Xml.tag(r, "code")
    return when (code) {
        "108006" -> {
            val left = Xml.tag(r, "remaincount")
            "Username or password rejected." + (if (left.isNotEmpty()) " Attempts left before lockout: $left." else "") +
                (if (left == "1" || left == "0") " WARNING: do not try again!" else "")
        }
        "108007" -> "Login is temporarily locked after wrong attempts. Wait a few minutes (waittime=" + Xml.tag(r, "waittime") + ")."
        else -> r.take(250)
    }
}
