package com.farhad.modem

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.farhad.modem.core.History
import com.farhad.modem.core.Snapshot
import com.farhad.modem.core.fmt
import com.farhad.modem.core.operatorInfo
import com.farhad.modem.core.signal
import com.farhad.modem.core.traffic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** سرویس پس‌زمینه: سیگنال رو می‌خونه، تاریخچه رو ثبت می‌کنه، سوییچ خودکار رو اجرا می‌کنه و تو نوار اعلان نشون می‌ده. */
class MonitorService : Service() {
    companion object {
        const val ACTION_STOP = "com.farhad.modem.STOP"
        private const val CH = "signal"
        private const val ID = 1
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var started = false
    private var lastText = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        if (intent != null && ACTION_STOP == intent.action) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (!started) {
            started = true
            Store.monitoring.value = true
            scope.launch { loop() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        Store.monitoring.value = false
        Store.persist()
        super.onDestroy()
    }

    private suspend fun loop() {
        var lastSample = 0L
        var lastAuto = System.currentTimeMillis()
        var lastOp = 0L
        while (scope.isActive) {
            val now = System.currentTimeMillis()
            try {
                val s = Store.client.signal(now)
                if (s != null) {
                    Store.snapshot.value = s
                    Store.online.value = true
                    if (now - lastSample >= History.SAMPLE_MS) {
                        lastSample = now
                        Store.addSample(s)
                    }
                } else {
                    Store.online.value = false
                }
                if (Store.foreground) {
                    Store.traffic.value = Store.client.traffic()
                    if (now - lastOp >= 9000L) {
                        lastOp = now
                        Store.operator.value = Store.client.operatorInfo()
                    }
                }
                if (now - lastAuto >= 30000L) {
                    lastAuto = now
                    Act.autoTick()
                }
                notifyText(textOf(s))
            } catch (e: Exception) {
                if (Store.online.value) Store.log("poll ERR $e")
                Store.online.value = false
                notifyText("ارتباط با مودم برقرار نیست")
            }
            delay(Store.pollInterval())
        }
    }

    private fun textOf(s: Snapshot?): String {
        if (s == null) return "سیگنالی دریافت نشد"
        val parts = mutableListOf<String>()
        s.rsrp?.let { parts.add("RSRP " + fmt(it)) }
        s.mainSinr?.let { parts.add("SINR " + fmt(it)) }
        s.band?.let { parts.add("B$it") }
        return if (parts.isEmpty()) "بدون سرویس" else parts.joinToString(" · ")
    }

    private fun notifyText(text: String) {
        if (text == lastText) return
        lastText = text
        getSystemService(NotificationManager::class.java).notify(ID, build(text))
    }

    private fun build(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, MonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_signal)
            .setContentTitle("Huawei 5G CPE")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(0, "توقف", stop).build())
            .build()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Signal", NotificationManager.IMPORTANCE_LOW))
        val n = build("در حال اتصال...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(ID, n)
        }
    }
}
