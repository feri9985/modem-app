package com.farhad.modem.core

/** ابزارهای ساده‌ی XML برای پاسخ‌های مودم (وابسته به اندروید نیست تا روی JVM تست بشه). */
object Xml {
    fun tag(x: String, t: String): String {
        val re = Regex("<" + Regex.escape(t) + ">([^<]*)</" + Regex.escape(t) + ">", RegexOption.IGNORE_CASE)
        return re.find(x)?.groupValues?.get(1)?.trim() ?: ""
    }

    fun blocks(x: String, t: String): List<String> {
        val re = Regex("<" + Regex.escape(t) + ">([\\s\\S]*?)</" + Regex.escape(t) + ">", RegexOption.IGNORE_CASE)
        return re.findAll(x).map { it.groupValues[1] }.toList()
    }

    private val numRe = Regex("-?\\d+(\\.\\d+)?")

    fun num(v: String): Double? = numRe.find(v)?.value?.toDoubleOrNull()

    fun isOk(x: String): Boolean = x.contains("OK")

    /** کد خطا اگه پاسخ <error> باشه، وگرنه رشته‌ی خالی. */
    fun errorCode(x: String): String = if (x.contains("<error>", ignoreCase = true)) tag(x, "code") else ""

    fun escape(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}
