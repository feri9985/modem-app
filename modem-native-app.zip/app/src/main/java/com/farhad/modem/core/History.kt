package com.farhad.modem.core

data class Sample(
    val t: Long,
    val rsrp: Double?,
    val sinr: Double?,
    val nrRsrp: Double?,
    val nrSinr: Double?,
    val band: Int?,
    val pci: Int?
) {
    /** 5G SINR اگه بود، وگرنه 4G SINR (برای سوییچ خودکار) */
    val mainSinr: Double? get() = nrSinr ?: sinr
}

data class Event(val t: Long, val text: String)

data class Stats(val min: Double, val avg: Double, val max: Double, val n: Int)

object History {
    const val MAX = 720          // ۲ ساعت با نمونه‌ی هر ۱۰ ثانیه
    const val SAMPLE_MS = 10000L

    /** کلیدهای نمودار: s = 4G SINR ، a = 4G RSRP ، ns = 5G SINR ، na = 5G RSRP */
    val METRICS: List<Triple<String, String, Metric>> = listOf(
        Triple("s", "4G SINR", Metrics.SINR),
        Triple("a", "4G RSRP", Metrics.RSRP),
        Triple("ns", "5G SINR", Metrics.SINR),
        Triple("na", "5G RSRP", Metrics.RSRP)
    )

    fun fromSnapshot(s: Snapshot): Sample = Sample(s.t, s.rsrp, s.sinr, s.nrRsrp, s.nrSinr, s.band, s.pci)

    fun value(p: Sample, key: String): Double? = when (key) {
        "s" -> p.sinr
        "a" -> p.rsrp
        "ns" -> p.nrSinr
        else -> p.nrRsrp
    }

    fun append(list: List<Sample>, s: Sample): List<Sample> {
        val n = list + s
        return if (n.size > MAX) n.subList(n.size - MAX, n.size) else n
    }

    fun stats(vals: List<Double>): Stats? {
        if (vals.isEmpty()) return null
        val avg = Math.round(vals.sum() / vals.size * 10.0) / 10.0
        return Stats(vals.min(), avg, vals.max(), vals.size)
    }

    /** تغییر باند/سلول بین نمونه‌های پشت‌سرهم. فاصله‌ی بیشتر از ۲ دقیقه = اپ بسته بوده، تغییر حساب نمی‌شه. */
    fun changes(h: List<Sample>, from: Long): List<Event> {
        val out = mutableListOf<Event>()
        for (i in 1 until h.size) {
            val a = h[i - 1]
            val b = h[i]
            if (b.t < from || b.t - a.t > 120000L) continue
            val ch = mutableListOf<String>()
            if (a.band != b.band) ch.add(bandText(a.band) + "→" + bandText(b.band))
            if (a.pci != b.pci) ch.add("PCI " + (a.pci?.toString() ?: "-") + "→" + (b.pci?.toString() ?: "-"))
            if (ch.isNotEmpty()) out.add(Event(b.t, ch.joinToString("  ")))
        }
        return out
    }

    private fun bandText(b: Int?): String = if (b == null) "-" else "B$b"
}

object HistoryCodec {
    private fun d(v: Double?): String = if (v == null) "" else v.toString()
    private fun i(v: Int?): String = if (v == null) "" else v.toString()

    fun encode(l: List<Sample>): String =
        l.joinToString("\n") { listOf(it.t.toString(), d(it.rsrp), d(it.sinr), d(it.nrRsrp), d(it.nrSinr), i(it.band), i(it.pci)).joinToString(",") }

    fun decode(s: String): List<Sample> {
        val out = mutableListOf<Sample>()
        for (line in s.split("\n")) {
            val p = line.split(",")
            if (p.size < 7) continue
            val t = p[0].toLongOrNull() ?: continue
            out.add(Sample(t, p[1].toDoubleOrNull(), p[2].toDoubleOrNull(), p[3].toDoubleOrNull(), p[4].toDoubleOrNull(), p[5].toIntOrNull(), p[6].toIntOrNull()))
        }
        return out
    }

    fun encodeEvents(l: List<Event>): String =
        l.joinToString("\n") { it.t.toString() + "\t" + it.text.replace('\n', ' ').replace('\t', ' ') }

    fun decodeEvents(s: String): List<Event> {
        val out = mutableListOf<Event>()
        for (line in s.split("\n")) {
            val k = line.indexOf('\t')
            if (k < 0) continue
            val t = line.substring(0, k).toLongOrNull() ?: continue
            out.add(Event(t, line.substring(k + 1)))
        }
        return out
    }
}
