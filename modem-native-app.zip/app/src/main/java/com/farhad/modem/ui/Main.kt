package com.farhad.modem.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Act
import com.farhad.modem.Store
import com.farhad.modem.core.loginMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun Root() {
    val logged by Store.loggedIn.collectAsState()
    Surface(modifier = Modifier.fillMaxSize(), color = C.bg, contentColor = C.text) {
        if (logged) MainScreen() else LoginScreen()
    }
}

@Composable
fun LoginScreen() {
    val scope = rememberCoroutineScope()
    var ip by remember { mutableStateOf(Store.savedIp()) }
    var user by remember { mutableStateOf(Store.savedUser()) }
    var pw by remember { mutableStateOf(Store.savedPass()) }
    var busy by remember { mutableStateOf(false) }
    var keep by remember { mutableStateOf(Store.keepPass()) }
    var show by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    val wifi by Store.wifiReady.collectAsState()

    fun go() {
        if (busy) return
        busy = true
        err = ""
        scope.launch(Dispatchers.IO) {
            try {
                val r = Act.login(ip, user, pw)
                if (r != "OK") err = loginMessage(r)
            } catch (e: Exception) {
                err = "ERR $e"
            } finally {
                busy = false
            }
        }
    }

    // If a password was saved, log in automatically once
    LaunchedEffect(Unit) {
        if (!Store.autoLoginTried && pw.isNotEmpty()) {
            Store.autoLoginTried = true
            go()
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center) {
        Text("Modem Manager", color = C.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Gap(16)
        OutlinedTextField(
            value = ip, onValueChange = { ip = it }, label = { Text("Modem IP") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Gap(8)
        OutlinedTextField(
            value = user, onValueChange = { user = it }, label = { Text("Username") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Gap(8)
        OutlinedTextField(
            value = pw, onValueChange = { pw = it }, label = { Text("Password") },
            singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                Text(
                    if (show) "Hide" else "Show", color = C.blue, fontSize = 14.sp,
                    modifier = Modifier.clickable { show = !show }.padding(12.dp)
                )
            },
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = keep, onCheckedChange = { keep = it; Store.setKeepPass(it) })
            Text("Save password", color = C.text, fontSize = 14.sp)
        }
        Gap(12)
        Btn(if (busy) "Logging in..." else "Log in", Modifier.fillMaxWidth(), kind = 1) { go() }
        Gap(8)
        Text(
            if (wifi) "Connected to the modem Wi-Fi" else "Waiting for the modem Wi-Fi... (the phone must be connected to the modem Wi-Fi)",
            color = C.mute, fontSize = 12.sp
        )
        if (err.isNotEmpty()) {
            Gap(8)
            Text(err, color = C.red, fontSize = 13.sp)
        }
    }
}

@Composable
fun MainScreen() {
    var tab by remember { mutableStateOf("h") }
    val online by Store.online.collectAsState()
    val tabs = listOf(
        Pair("h", "Home"), Pair("a", "Align"), Pair("g", "History"),
        Pair("c", "Cell lock"), Pair("o", "Operator"), Pair("d", "Devices")
    )
    Column(Modifier.fillMaxSize().background(C.bg)) {
        Row(
            Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(C.hdr1, C.hdr2))).padding(horizontal = 12.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Huawei 5G CPE Max", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Box(
                Modifier.clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.35f))
                    .clickable { Store.toast("Logging out..."); Thread { Act.logout() }.start() }
                    .padding(horizontal = 14.dp, vertical = 5.dp)
            ) {
                Text("Log out", color = Color.White, fontSize = 14.sp)
            }
        }
        Row(
            Modifier.fillMaxWidth().background(C.panel).horizontalScroll(rememberScrollState()).padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            tabs.forEach { t ->
                Box(
                    Modifier.clip(RoundedCornerShape(10.dp))
                        .background(if (tab == t.first) C.blue else C.btn)
                        .clickable { tab = t.first }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(t.second, color = Color.White, fontSize = 14.sp, fontWeight = if (tab == t.first) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
        if (!online) {
            Text(
                "Modem not reachable (is it rebooting? is Wi-Fi connected?)",
                color = Color.White, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().background(C.red).padding(6.dp)
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                "h" -> HomeScreen()
                "a" -> AlignScreen()
                "g" -> HistoryScreen()
                "c" -> CellLockScreen()
                "o" -> OperatorScreen()
                else -> DevicesScreen()
            }
        }
    }
}
