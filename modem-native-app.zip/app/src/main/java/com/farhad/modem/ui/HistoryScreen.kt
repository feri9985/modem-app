package com.farhad.modem.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Store
import com.farhad.modem.core.Auto
import com.farhad.modem.core.Event
import com.farhad.modem.core.History
import com.farhad.modem.core.Metric
import com.farhad.modem.core.Sample
import com.farhad.modem.core.fmt

private class Line(val e: Event, val auto: Boolean)

/** نمودار سیگنال با ناحیه‌های سبز/زرد/قرمز، خط عمودی برای تغییر باند/سلول (سفید) و سوییچ خودکار (نارنجی). */
@Composable
fun SignalChart(pts: List<Sample>, key: String, m: Metric, t0: Long, t1: Long, marks: List<Pair<Long, Boolean>>) {
    val paint = remember {
        android.graphics.Paint().apply {
            color = 0xFF8A97A8.toInt()
            textSize = 26f
            isAntiAlias = true
        }
    }
    Canvas(Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(12.dp)).background(C.chartBg)) {
        val w = size.width
        val h = size.height
        val left = 100f
        val right = 16f
        val top = 16f
        val bottom = 44f
        val span = (t1 - t0).toFloat().coerceAtLeast(1f)
        fun x(t: Long): Float = left + (t - t0).toFloat() * (w - left - right) / span
        fun y(v: Double): Float {
            val c = v.coerceIn(m.min, m.max)
            return (top + (1.0 - (c - m.min) / (m.max - m.min)) * (h - top - bottom)).toFloat()
        }
        val zw = w - left - right
        drawRect(C.green.copy(alpha = 0.13f), topLeft = Offset(left, y(m.max)), size = Size(zw, y(m.good) - y(m.max)))
        drawRect(C.yellow.copy(alpha = 0.13f), topLeft = Offset(left, y(m.good)), size = Size(zw, y(m.ok) - y(m.good)))
        drawRect(C.red.copy(alpha = 0.13f), topLeft = Offset(left, y(m.ok)), size = Size(zw, y(m.min) - y(m.ok)))

        drawIntoCanvas { c ->
            paint.textAlign = android.graphics.Paint.Align.RIGHT
            listOf(m.min, m.ok, m.good, m.max).forEach { v ->
                c.nativeCanvas.drawText(fmt(v), left - 8f, y(v) + 9f, paint)
            }
            paint.textAlign = android.graphics.Paint.Align.LEFT
            c.nativeCanvas.drawText(Auto.hm(t0), left, h - 8f, paint)
            paint.textAlign = android.graphics.Paint.Align.RIGHT
            c.nativeCanvas.drawText(Auto.hm(t1), w - right, h - 8f, paint)
        }

        marks.forEach { mk ->
            if (mk.first in t0..t1) {
                drawLine(
                    if (mk.second) C.orange else C.mute.copy(alpha = 0.6f),
                    Offset(x(mk.first), top), Offset(x(mk.first), h - bottom), strokeWidth = 3f
                )
            }
        }

        val path = Path()
        var prev = -1L
        for (p in pts) {
            val v = History.value(p, key)
            if (v == null) {
                prev = -1L
            } else {
                if (prev < 0L || p.t - prev > 60000L) path.moveTo(x(p.t), y(v)) else path.lineTo(x(p.t), y(v))
                prev = p.t
            }
        }
        drawPath(path, C.line, style = Stroke(width = 4f))
        if (pts.size <= 150) {
            for (p in pts) {
                val v = History.value(p, key)
                if (v != null) drawCircle(C.line, radius = 3.5f, center = Offset(x(p.t), y(v)))
            }
        }
    }
}

@Composable
fun HistoryScreen() {
    val hist by Store.history.collectAsState()
    val evs by Store.events.collectAsState()
    var mkey by remember { mutableStateOf("s") }
    var range by remember { mutableStateOf("60") }

    val def = History.METRICS.first { it.first == mkey }
    val now = System.currentTimeMillis()
    val t0 = now - range.toLong() * 60000L
    val pts = hist.filter { it.t >= t0 }
    val stats = History.stats(pts.mapNotNull { History.value(it, mkey) })
    val lines = (History.changes(hist, t0).map { Line(it, false) } + evs.filter { it.t >= t0 }.map { Line(it, true) })
        .sortedByDescending { it.e.t }
    val marks = lines.map { Pair(it.e.t, it.auto) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Sec("نمودار سیگنال (حتی وقتی این تب بسته‌ست ثبت می‌شه). خط‌های عمودی = تغییر باند/سلول، نارنجی = سوییچ خودکار")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Drop(History.METRICS.map { Pair(it.first, it.second) }, mkey, Modifier.weight(1f)) { mkey = it }
            Drop(listOf(Pair("15", "۱۵ دقیقه"), Pair("60", "۱ ساعت"), Pair("120", "۲ ساعت")), range, Modifier.weight(1f)) { range = it }
        }
        Gap(6)
        SignalChart(pts, mkey, def.third, t0, now, marks)
        Gap(6)
        if (stats == null) {
            Tag("هنوز داده‌ای نیست؛ هر ۱۰ ثانیه یه نمونه ثبت می‌شه")
        } else {
            TagRows(listOf("کمترین: " + fmt(stats.min), "میانگین: " + fmt(stats.avg), "بیشترین: " + fmt(stats.max), "نمونه: " + stats.n))
        }
        Sec("رویدادها")
        if (lines.isEmpty()) {
            Text("(تغییر باند/سلول یا سوییچی نبوده)", color = C.mute, fontSize = 12.sp)
        } else {
            lines.take(12).forEach { l ->
                Text(Auto.hm(l.e.t) + "  " + l.e.text, color = if (l.auto) C.orange else C.text, fontSize = 12.sp, modifier = Modifier.padding(bottom = 3.dp))
            }
        }
        Gap(8)
        Btn("پاک کردن تاریخچه", Modifier.fillMaxWidth()) { Store.clearHistory() }
    }
}
