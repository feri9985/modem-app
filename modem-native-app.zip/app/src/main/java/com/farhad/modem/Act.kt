package com.farhad.modem

import android.content.Intent
import androidx.core.content.ContextCompat
import com.farhad.modem.core.Auto
import com.farhad.modem.core.Bands
import com.farhad.modem.core.Profile
import com.farhad.modem.core.Xml
import com.farhad.modem.core.bandInfo
import com.farhad.modem.core.fmt
import com.farhad.modem.core.set5gOnly
import com.farhad.modem.core.setSimpleMode
import java.math.BigInteger

/** عملیات‌هایی که هم رابط و هم سرویس صدا می‌زنن. همه blocking هستن؛ روی نخ IO صدا بزن. */
object Act {
    fun login(ip: String, user: String, pw: String): String {
        Store.awaitWifi(4000)
        val r = Store.client.login(ip, user, pw)
        if (r == "OK") {
            Store.saveCreds(ip.trim(), user, pw)
            Store.loggedIn.value = true
            try { startMonitor() } catch (e: Exception) { Store.log("service ERR $e") }
            refreshBands()
        }
        return r
    }

    fun logout() {
        stopMonitor()
        Store.client.logout()
        Store.clearPass()
        Store.persist()
        Store.resetSession()
    }

    fun startMonitor() {
        ContextCompat.startForegroundService(Store.app, Intent(Store.app, MonitorService::class.java))
    }

    fun stopMonitor() {
        Store.app.stopService(Intent(Store.app, MonitorService::class.java))
    }

    fun refreshBands() {
        try {
            Store.bandInfo.value = Store.client.bandInfo()
        } catch (e: Exception) {
            Store.log("bands ERR $e")
        }
    }

    /** برمی‌گردونه true اگه مودم OK داد. isAuto=true یعنی سوییچ خودکار (وضعیت خودکار ریست نشه). */
    fun applyBands(lte: BigInteger, nr: BigInteger, option: String, en5: Boolean, label: String, isAuto: Boolean): Boolean {
        if (lte.signum() == 0 && nr.signum() == 0) {
            Store.toast("حداقل یک باند انتخاب کن")
            return false
        }
        val tag = Store.bandInfo.value?.nrTag ?: ""
        if (nr.signum() != 0 && tag.isEmpty()) {
            Store.toast("API قفل 5G هنوز مشخص نشده. Tools ← جمع‌آوری اطلاعات 5G رو بزن و متن رو بفرست")
            return false
        }
        Store.toast(if (isAuto) "سوییچ خودکار: «$label»..." else "در حال اعمال...")
        val r = Store.client.post("/api/net/net-mode", Bands.bandsBody(lte, nr, tag, option, en5))
        val good = Xml.isOk(r)
        Store.toast(
            if (good) (if (label.isNotEmpty()) "«$label» اعمال شد ✓" else "اعمال شد ✓")
            else "خطا: " + r.take(80)
        )
        if (good && !isAuto) Store.saveAuto(Auto.manualApplied(Store.auto.value, label, System.currentTimeMillis()))
        refreshBands()
        return good
    }

    fun applyProfile(p: Profile, isAuto: Boolean): Boolean =
        applyBands(p.lteMask(), p.nrMask(), p.option, p.en5, p.name, isAuto)

    /** دکمه‌های حالت شبکه: Auto / 5G فقط / 4G / 3G / 2G */
    fun quick(name: String, mode: String, option: String) {
        Store.toast("$name ...")
        if (mode != "08") {
            val r = Store.client.setSimpleMode(mode)
            Store.toast(if (Xml.isOk(r)) "$name ✓" else "خطا: " + r.take(120))
            refreshBands()
            return
        }
        val done = try { Store.client.set5gOnly(option) } catch (e: Exception) { Store.log("5G ERR $e"); null }
        Store.toast(if (done != null) "5G فقط ✓ (option $done)" else "5G فقط ثبت نشد؛ Tools ← Log رو ببین")
        refreshBands()
    }

    private fun withCur(cur: String, msg: String): String = if (cur.isNotEmpty()) "«$cur» · $msg" else msg

    /** هر ۳۰ ثانیه از سرویس صدا زده می‌شه. */
    fun autoTick() {
        val s = Store.auto.value
        if (!s.on || Store.autoBusy) return
        val now = System.currentTimeMillis()
        val r = Auto.decide(s, Store.profiles.value, Store.history.value, now)
        val p = r.apply
        if (p == null) {
            Store.saveAuto(r.state)
            Store.autoMsg.value = withCur(r.state.cur, r.msg)
            return
        }
        Store.autoBusy = true
        try {
            var st = r.state
            val msg: String
            if (p.name != st.cur) {
                val ok = applyProfile(p, true)
                val a = Auto.afterApply(st, p, ok, now)
                st = a.state
                msg = a.msg
                if (ok) Store.addEvent("سوییچ خودکار ← «" + p.name + "» (" + r.why + "، میانگین قبلی " + fmt(r.avg) + " dB)")
            } else {
                st = st.copy(t0 = now + Auto.SETTLE_MS)
                msg = "«" + p.name + "» همین الان فعاله؛ صبر برای ارزیابی"
            }
            Store.saveAuto(st)
            Store.autoMsg.value = withCur(st.cur, msg)
        } finally {
            Store.autoBusy = false
        }
    }
}
