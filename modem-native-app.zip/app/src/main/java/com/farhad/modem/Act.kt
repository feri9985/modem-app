package com.farhad.modem

import android.content.Intent
import androidx.core.content.ContextCompat
import com.farhad.modem.core.Bands
import com.farhad.modem.core.Xml
import com.farhad.modem.core.bandInfo
import com.farhad.modem.core.set5gOnly
import com.farhad.modem.core.setSimpleMode
import java.math.BigInteger

/** Operations called from the UI. All blocking; call on an IO thread. */
object Act {
    fun login(ip: String, user: String, pw: String): String {
        Store.awaitWifi(4000)
        val r = Store.client.login(ip, user, pw)
        if (r == "OK") {
            Store.saveCreds(ip.trim(), user, pw)
            Store.loggedIn.value = true
            try { startMonitor() } catch (e: Exception) { Store.log("service ERR $e") }
            refreshBands()
        }
        return r
    }

    fun logout() {
        stopMonitor()
        Store.client.logout()
        Store.clearPass()
        com.farhad.modem.ui.DevWeb.reset()
        Store.persist()
        Store.resetSession()
    }

    fun startMonitor() {
        ContextCompat.startForegroundService(Store.app, Intent(Store.app, MonitorService::class.java))
    }

    fun stopMonitor() {
        Store.app.stopService(Intent(Store.app, MonitorService::class.java))
    }

    fun refreshBands() {
        try {
            Store.bandInfo.value = Store.client.bandInfo()
        } catch (e: Exception) {
            Store.log("bands ERR $e")
        }
    }

    /** Returns true if the modem answered OK. */
    fun applyBands(lte: BigInteger, nr: BigInteger, option: String, en5: Boolean): Boolean {
        if (lte.signum() == 0 && nr.signum() == 0) {
            Store.toast("Select at least one band")
            return false
        }
        val tag = Store.bandInfo.value?.nrTag ?: ""
        val nrUnsupported = nr.signum() != 0 && tag.isEmpty()
        if (nrUnsupported && lte.signum() == 0) {
            Store.toast("This modem has no 5G band-lock field. Use the Dev options tab (Band selection) for 5G locks.")
            return false
        }
        Store.toast("Applying...")
        val r = Store.client.post("/api/net/net-mode", Bands.bandsBody(lte, if (nrUnsupported) BigInteger.ZERO else nr, tag, option, en5))
        val good = Xml.isOk(r)
        Store.toast(
            if (!good) "Error: " + r.take(80)
            else if (nrUnsupported) "4G bands applied ✓ (N77/N78 lock not supported by this modem; use Dev options tab)"
            else "Applied ✓"
        )
        refreshBands()
        return good
    }

    /** Network mode buttons: Auto / 5G only / 4G / 3G / 2G */
    fun quick(name: String, mode: String, option: String) {
        Store.toast("$name ...")
        if (mode != "08") {
            val r = Store.client.setSimpleMode(mode)
            Store.toast(if (Xml.isOk(r)) "$name ✓" else "Error: " + r.take(120))
            refreshBands()
            return
        }
        val done = try { Store.client.set5gOnly(option) } catch (e: Exception) { Store.log("5G ERR $e"); null }
        Store.toast(if (done != null) "5G only ✓ (option $done)" else "5G only was not accepted by the modem")
        refreshBands()
    }
}
