package com.farhad.modem

import android.content.Intent
import androidx.core.content.ContextCompat
import com.farhad.modem.core.Bands
import com.farhad.modem.core.Xml
import com.farhad.modem.core.bandInfo
import com.farhad.modem.core.freqRanges
import com.farhad.modem.core.lockFreqState
import com.farhad.modem.core.setLockBand
import com.farhad.modem.core.setLockCell
import com.farhad.modem.core.setLockFreq
import com.farhad.modem.core.setLteBands
import com.farhad.modem.core.FreqPlan
import com.farhad.modem.core.set5gOnly
import com.farhad.modem.core.setSimpleMode
import java.math.BigInteger

/** Operations called from the UI. All blocking; call on an IO thread. */
object Act {
    fun login(ip: String, user: String, pw: String): String {
        Store.awaitWifi(4000)
        val r = Store.client.login(ip, user, pw)
        if (r == "OK") {
            Store.saveCreds(ip.trim(), user, pw)
            Store.loggedIn.value = true
            try { startMonitor() } catch (e: Exception) { Store.log("service ERR $e") }
            refreshBands()
        }
        return r
    }

    fun logout() {
        stopMonitor()
        Store.client.logout()
        Store.clearPass()
        com.farhad.modem.ui.DevWeb.reset()
        Store.persist()
        Store.resetSession()
    }

    fun startMonitor() {
        ContextCompat.startForegroundService(Store.app, Intent(Store.app, MonitorService::class.java))
    }

    fun stopMonitor() {
        Store.app.stopService(Intent(Store.app, MonitorService::class.java))
    }

    fun refreshBands() {
        try {
            Store.bandInfo.value = Store.client.bandInfo()
        } catch (e: Exception) {
            Store.log("bands ERR $e")
        }
    }

    /** Returns true if the modem answered OK. Bands go through the same two requests as the modem page. */
    fun applyBands(lte: BigInteger, option: String, en5: Boolean): Boolean {
        if (lte.signum() == 0) {
            Store.toast("Select at least one band")
            return false
        }
        Store.toast("Applying...")
        val r = Store.client.post("/api/net/net-mode", Bands.bandsBody(lte, BigInteger.ZERO, "", option, en5))
        var good = Xml.isOk(r)
        if (good) good = Xml.isOk(Store.client.setLteBands(lte))
        Store.toast(if (good) "Applied ✓" else "Error: " + r.take(80))
        refreshBands()
        return good
    }

    /** Network mode buttons: Auto / 5G only / 4G (the only modes this modem lists) */
    fun quick(name: String, mode: String, option: String) {
        Store.toast("$name ...")
        if (mode != "08") {
            val r = Store.client.setSimpleMode(mode)
            Store.toast(if (Xml.isOk(r)) "$name ✓" else "Error: " + r.take(120))
            refreshBands()
            return
        }
        val done = try { Store.client.set5gOnly(option) } catch (e: Exception) { Store.log("5G ERR $e"); null }
        Store.toast(if (done != null) "5G only ✓ (option $done)" else "5G only was not accepted by the modem")
        refreshBands()
    }

    fun refreshLock() {
        try {
            Store.lockFreq.value = Store.client.lockFreqState()
        } catch (e: Exception) {
            Store.log("lock state ERR $e")
        }
    }

    /**
     * Same requests as the modem's Developer options > Band selection page.
     * type: "none" | "band" | "freq" | "cell". Returns true on success.
     */
    fun bandSelection(type: String, band: Int?, freq: Int?, pci: Int? = null): Boolean {
        val c = Store.client
        try {
            when (type) {
                "none" -> {
                    val a = Xml.isOk(c.setLockFreq(false, 0, 0))
                    val b = Xml.isOk(c.setLteBands(BigInteger.ZERO))
                    if (!(a && b)) { Store.toast("Error while removing the lock"); return false }
                    Store.toast("No lock ✓")
                }
                "band" -> {
                    if (band == null) { Store.toast("Select a band"); return false }
                    if (!Xml.isOk(c.setLockBand(band))) { Store.toast("Error while locking the band"); return false }
                    if (!Xml.isOk(c.setLteBands(Bands.mask(listOf(band))))) { Store.toast("Error while locking the band"); return false }
                    Store.toast("Band lock: B$band ✓")
                }
                "freq" -> {
                    if (band == null || freq == null) { Store.toast("Select a band and enter EARFCN"); return false }
                    val range = c.freqRanges()[band]
                    if (range != null && freq !in range) {
                        Store.toast("EARFCN $freq is not in B$band (" + range.first + "~" + range.last + ")")
                        return false
                    }
                    if (!Xml.isOk(c.setLockFreq(true, band, freq))) { Store.toast("Error while locking the frequency"); return false }
                    c.setLteBands(BigInteger.ZERO)
                    Store.toast("Frequency lock: B$band / $freq ✓")
                }
                "cell" -> {
                    if (band == null || freq == null || pci == null) { Store.toast("Select a band and enter EARFCN and PCI"); return false }
                    if (pci < 0 || pci > 503) { Store.toast("PCI must be 0 ~ 503 for 4G"); return false }
                    val range = c.freqRanges()[band]
                    if (range != null && freq !in range) {
                        Store.toast("EARFCN $freq is not in B$band (" + range.first + "~" + range.last + ")")
                        return false
                    }
                    if (!Xml.isOk(c.setLockCell(band, freq, pci))) { Store.toast("Error while locking the cell"); return false }
                    c.setLteBands(BigInteger.ZERO)
                    Store.toast("Cell lock: B$band / $freq / PCI $pci ✓")
                }
                else -> return false
            }
            return true
        } finally {
            refreshLock()
            refreshBands()
        }
    }
}
