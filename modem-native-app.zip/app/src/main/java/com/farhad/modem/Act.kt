package com.farhad.modem

import android.content.Intent
import androidx.core.content.ContextCompat
import com.farhad.modem.core.Bands
import com.farhad.modem.core.Xml
import com.farhad.modem.core.bandInfo
import com.farhad.modem.core.freqRanges
import com.farhad.modem.core.lockFreqState
import com.farhad.modem.core.setLockBand
import com.farhad.modem.core.setLockCell
import com.farhad.modem.core.setLockFreq
import com.farhad.modem.core.setLteBands
import com.farhad.modem.core.FreqPlan
import com.farhad.modem.core.set5gOnly
import com.farhad.modem.core.setSimpleMode
import java.math.BigInteger

/** Operations called from the UI. All blocking; call on an IO thread. */
object Act {
    fun login(ip: String, user: String, pw: String): String {
        Store.awaitWifi(4000)
        val r = Store.client.login(ip, user, pw)
        if (r == "OK") {
            Store.saveCreds(ip.trim(), user, pw)
            Store.loggedIn.value = true
            try { startMonitor() } catch (e: Exception) { Store.log("service ERR $e") }
            refreshBands()
        }
        return r
    }

    fun logout() {
        stopMonitor()
        Store.client.logout()
        Store.clearPass()
        com.farhad.modem.ui.DevWeb.reset()
        Store.persist()
        Store.resetSession()
    }

    fun startMonitor() {
        ContextCompat.startForegroundService(Store.app, Intent(Store.app, MonitorService::class.java))
    }

    fun stopMonitor() {
        Store.app.stopService(Intent(Store.app, MonitorService::class.java))
    }

    fun refreshBands() {
        try {
            Store.bandInfo.value = Store.client.bandInfo()
        } catch (e: Exception) {
            Store.log("bands ERR $e")
        }
    }

    private fun errText(r: String): String {
        val code = Xml.errorCode(r)
        return if (code.isNotEmpty()) "error $code" else r.replace(Regex("\\s+"), " ").take(80)
    }

    /** Removes any active lock (same two requests as "No lock" on the modem page). */
    private fun clearLocks(): Boolean {
        val c = Store.client
        val a = Xml.isOk(c.setLockFreq(false, 0, 0))
        val b = Xml.isOk(c.setLteBands(BigInteger.ZERO))
        return a && b
    }

    /**
     * Applies the selected LTE bands. The modem only accepts a new band mask when no lock is active and
     * when the net-mode request carries the same mask as lte-band-info, so: clear lock, set mask, then net-mode.
     */
    fun applyBands(lte: BigInteger, option: String, en5: Boolean): Boolean {
        if (lte.signum() == 0) {
            Store.toast("Select at least one band")
            return false
        }
        val c = Store.client
        Store.toast("Applying...")
        try {
            if ((c.lockFreqState()?.enable ?: 0) != 0) {
                if (!clearLocks()) { Store.toast("Could not remove the active lock"); return false }
                Thread.sleep(1500)
            }
            val r1 = c.setLteBands(lte)
            if (!Xml.isOk(r1)) { Store.toast("Bands not accepted: " + errText(r1)); return false }
            val r2 = c.post("/api/net/net-mode", Bands.bandsBody(lte, BigInteger.ZERO, "", option, en5))
            if (!Xml.isOk(r2)) { Store.toast("Bands set, but network mode not accepted: " + errText(r2)); return false }
            Store.toast("Applied ✓")
            return true
        } finally {
            refreshBands()
            refreshLock()
        }
    }

    /** Network mode buttons: Auto / 5G only / 4G (the only modes this modem lists) */
    fun quick(name: String, mode: String, option: String) {
        Store.toast("$name ...")
        if (mode != "08") {
            val r = Store.client.setSimpleMode(mode)
            Store.toast(if (Xml.isOk(r)) "$name ✓" else "Error: " + r.take(120))
            refreshBands()
            return
        }
        val done = try { Store.client.set5gOnly(option) } catch (e: Exception) { Store.log("5G ERR $e"); null }
        Store.toast(if (done != null) "5G only ✓ (option $done)" else "5G only was not accepted by the modem")
        refreshBands()
    }

    fun refreshLock() {
        try {
            Store.lockFreq.value = Store.client.lockFreqState()
        } catch (e: Exception) {
            Store.log("lock state ERR $e")
        }
    }

    /** Reads the lock state back; false (with a message) if the modem did not keep the lock. */
    private fun confirmed(enable: Int, band: Int): Boolean {
        val st = try { Store.client.lockFreqState() } catch (e: Exception) { null }
        if (st != null && st.enable == enable && st.band == band) return true
        Store.toast("The modem did not keep the lock. State: " + (st?.describe() ?: "unknown"))
        return false
    }

    /**
     * Same requests as the modem's Developer options > Band selection page.
     * type: "none" | "band" | "freq" | "cell". Returns true on success.
     */
    fun bandSelection(type: String, band: Int?, freq: Int?, pci: Int? = null): Boolean {
        val c = Store.client
        try {
            if (type != "none" && type != "band" && type != "freq" && type != "cell") return false
            if (type != "none") {
                // like selecting "No lock" first on the modem page: a new lock is only accepted over a clean state
                if (!clearLocks()) { Store.toast("Could not remove the old lock"); return false }
                Thread.sleep(1500)
            }
            when (type) {
                "none" -> {
                    val a = Xml.isOk(c.setLockFreq(false, 0, 0))
                    val b = Xml.isOk(c.setLteBands(BigInteger.ZERO))
                    if (!(a && b)) { Store.toast("Error while removing the lock"); return false }
                    Store.toast("No lock ✓")
                }
                "band" -> {
                    if (band == null) { Store.toast("Select a band"); return false }
                    if (!Xml.isOk(c.setLockBand(band))) { Store.toast("Error while locking the band"); return false }
                    if (!Xml.isOk(c.setLteBands(Bands.mask(listOf(band))))) { Store.toast("Error while locking the band"); return false }
                    if (!confirmed(3, band)) return false
                    Store.toast("Band lock: B$band ✓")
                }
                "freq" -> {
                    if (band == null || freq == null) { Store.toast("Select a band and enter EARFCN"); return false }
                    val range = c.freqRanges()[band]
                    if (range != null && freq !in range) {
                        Store.toast("EARFCN $freq is not in B$band (" + range.first + "~" + range.last + ")")
                        return false
                    }
                    if (!Xml.isOk(c.setLockFreq(true, band, freq))) { Store.toast("Error while locking the frequency"); return false }
                    c.setLteBands(BigInteger.ZERO)
                    if (!confirmed(1, band)) return false
                    Store.toast("Frequency lock: B$band / $freq ✓")
                }
                "cell" -> {
                    if (band == null || freq == null || pci == null) { Store.toast("Select a band and enter EARFCN and PCI"); return false }
                    if (pci < 0 || pci > 503) { Store.toast("PCI must be 0 ~ 503 for 4G"); return false }
                    val range = c.freqRanges()[band]
                    if (range != null && freq !in range) {
                        Store.toast("EARFCN $freq is not in B$band (" + range.first + "~" + range.last + ")")
                        return false
                    }
                    if (!Xml.isOk(c.setLockCell(band, freq, pci))) { Store.toast("Error while locking the cell"); return false }
                    c.setLteBands(BigInteger.ZERO)
                    if (!confirmed(2, band)) return false
                    Store.toast("Cell lock: B$band / $freq / PCI $pci ✓")
                }
                else -> return false
            }
            return true
        } finally {
            refreshLock()
            refreshBands()
        }
    }
}
