package com.farhad.modem.core

import java.math.BigInteger

data class BandInfo(
    val mode: String,
    val lteSup: List<Int>,
    val lteCur: BigInteger,
    val nrTag: String,
    val nrSup: List<Int>,
    val nrCur: BigInteger,
    val option: String = ""
)

object Bands {
    const val ALL_LTE = "7FFFFFFFFFFFFFFF"

    val LTE_FREQ: Map<Int, Int> = mapOf(
        1 to 2100, 2 to 1900, 3 to 1800, 4 to 1700, 5 to 850, 7 to 2600, 8 to 900, 12 to 700, 13 to 700,
        17 to 700, 18 to 850, 19 to 850, 20 to 800, 25 to 1900, 26 to 850, 28 to 700, 32 to 1500, 34 to 2000,
        38 to 2600, 39 to 1900, 40 to 2300, 41 to 2500, 42 to 3500, 43 to 3700, 46 to 5200, 48 to 3500
    )
    val NR_FREQ: Map<Int, Int> = mapOf(
        1 to 2100, 3 to 1800, 5 to 850, 7 to 2600, 8 to 900, 20 to 800, 28 to 700, 38 to 2600, 40 to 2300,
        41 to 2500, 48 to 3500, 77 to 3700, 78 to 3500, 79 to 4700
    )

    fun parseHex(s: String): BigInteger {
        val t = s.trim()
        if (t.isEmpty()) return BigInteger.ZERO
        return try { BigInteger(t, 16) } catch (e: NumberFormatException) { BigInteger.ZERO }
    }

    fun hex(v: BigInteger): String = v.toString(16).uppercase()

    fun bitsOf(v: BigInteger, max: Int): List<Int> = (1..max).filter { v.testBit(it - 1) }

    fun mask(bands: Collection<Int>): BigInteger {
        var v = BigInteger.ZERO
        for (b in bands) v = v.or(BigInteger.ONE.shiftLeft(b - 1))
        return v
    }

    fun netModeBody(mode: String, band: String, lte: String, option: String, extra: String = ""): String =
        "<request><NetworkMode>" + mode + "</NetworkMode><NetworkBand>" + band + "</NetworkBand><LTEBand>" + lte +
            "</LTEBand>" + (if (option != "") "<networkOption>" + option + "</networkOption>" else "") + extra + "</request>"

    /** بدنه‌ی درخواست «اعمال باندها». nr=0 یعنی بدون قفل 5G. */
    fun bandsBody(lte: BigInteger, nr: BigInteger, nrTag: String, option: String, en5: Boolean): String {
        val lteHex = if (lte.signum() == 0) ALL_LTE else hex(lte)
        val extra = if (nr.signum() != 0) "<" + nrTag + ">" + hex(nr) + "</" + nrTag + ">" else ""
        return if (en5) netModeBody("00", "00000000", lteHex, option, extra)
        else netModeBody("03", "3FFFFFFF", lteHex, "", extra)
    }

    private val nrTagRe = Regex("<([A-Za-z_]*(?:NR|Nr|nr)[A-Za-z_]*[Bb]and[A-Za-z_]*)>([0-9A-Fa-f]*)</")
    private val lteSupRe = Regex("<LTEBand>[\\s\\S]*?<Value>([0-9A-Fa-f]+)</Value>")

    fun parse(netMode: String, netModeList: String): BandInfo {
        val cm = lteSupRe.find(netModeList)
        val sup = if (cm != null) parseHex(cm.groupValues[1]) else BigInteger.ONE.shiftLeft(53).subtract(BigInteger.ONE)
        val lteCur = parseHex(Xml.tag(netMode, "LTEBand"))
        val mt = nrTagRe.find(netMode)
        val nrTag = mt?.groupValues?.get(1) ?: ""
        val nrCur = if (mt != null) parseHex(mt.groupValues[2]) else BigInteger.ZERO
        var nrSupMask = BigInteger.ZERO
        if (mt != null) {
            val sm = Regex("<" + Regex.escape(nrTag) + ">[\\s\\S]*?<Value>([0-9A-Fa-f]+)</Value>").find(netModeList)
            if (sm != null) nrSupMask = parseHex(sm.groupValues[1])
        }
        val nrSup = if (nrSupMask.signum() != 0) bitsOf(nrSupMask, 128) else listOf(78, 48)
        return BandInfo(Xml.tag(netMode, "NetworkMode"), bitsOf(sup, 64), lteCur, nrTag, nrSup, nrCur, Xml.tag(netMode, "networkOption"))
    }
}
