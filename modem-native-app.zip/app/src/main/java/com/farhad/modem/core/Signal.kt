package com.farhad.modem.core

enum class Level { GOOD, OK, BAD }

data class Metric(
    val label: String,
    val unit: String,
    val min: Double,
    val max: Double,
    val good: Double,
    val ok: Double
) {
    fun level(v: Double): Level = if (v >= good) Level.GOOD else if (v >= ok) Level.OK else Level.BAD
    fun fraction(v: Double): Double = ((v - min) / (max - min)).coerceIn(0.0, 1.0)
}

object Metrics {
    val RSSI = Metric("RSSI", "dBm", -100.0, -45.0, -65.0, -80.0)
    val RSRP = Metric("RSRP", "dBm", -120.0, -70.0, -90.0, -105.0)
    val RSRQ = Metric("RSRQ", "dB", -20.0, -3.0, -10.0, -15.0)
    val SINR = Metric("SINR", "dB", -5.0, 30.0, 13.0, 0.0)
}

/** عدد رو بدون صفر اضافه چاپ می‌کنه: -85.0 -> "-85" ، 12.5 -> "12.5" */
fun fmt(v: Double): String =
    if (v == Math.rint(v)) v.toLong().toString() else String.format(java.util.Locale.US, "%.1f", v)

data class Snapshot(
    val t: Long,
    val rssi: Double?,
    val rsrp: Double?,
    val rsrq: Double?,
    val sinr: Double?,
    val nrRsrp: Double?,
    val nrRsrq: Double?,
    val nrSinr: Double?,
    val band: Int?,
    val pci: Int?,
    val cellId: String,
    val tac: String,
    val dlBw: String,
    val nrBw: String,
    val earfcn: Int? = null,
    val nrPci: Int? = null,
    val nrArfcn: Int? = null
) {
    /** 5G SINR اگه بود، وگرنه 4G SINR */
    val mainSinr: Double? get() = nrSinr ?: sinr
}

/** پاسخ /api/device/signal رو به Snapshot تبدیل می‌کنه؛ اگه پاسخ معتبر نبود (مثلاً لاگین نیستی) null. */
fun parseSignal(x: String, now: Long): Snapshot? {
    if (!x.contains("<response")) return null
    fun d(k: String): Double? = Xml.num(Xml.tag(x, k))
    fun first(vararg keys: String): Int? {
        for (k in keys) {
            val v = d(k)
            if (v != null) return v.toInt()
        }
        return null
    }
    val b = d("band")?.toInt()
    return Snapshot(
        t = now,
        rssi = d("rssi"), rsrp = d("rsrp"), rsrq = d("rsrq"), sinr = d("sinr"),
        nrRsrp = d("nrrsrp"), nrRsrq = d("nrrsrq"), nrSinr = d("nrsinr"),
        band = if (b == null || b == 0) null else b,
        pci = d("pci")?.toInt(),
        cellId = Xml.tag(x, "cell_id"),
        tac = Xml.tag(x, "tac"),
        dlBw = Xml.tag(x, "dlbandwidth"),
        nrBw = Xml.tag(x, "nrdlbandwidth"),
        earfcn = first("earfcn", "dlearfcn", "lteearfcn", "dl_earfcn"),
        nrPci = first("nrpci", "nr_pci"),
        nrArfcn = first("nrearfcn", "nrarfcn", "nrdlearfcn", "nr_arfcn")
    )
}

/** منطق تب Align (جهت‌یابی آنتن) */
object Align {
    val OPTIONS: List<Pair<String, String>> = listOf(
        "auto" to "Auto (5G SINR, else 4G SINR)",
        "sinr" to "4G SINR",
        "rsrp" to "4G RSRP",
        "nrsinr" to "5G SINR",
        "nrrsrp" to "5G RSRP"
    )

    class Picked(val key: String, val label: String, val value: Double?, val metric: Metric)

    fun pick(s: Snapshot, sel: String): Picked {
        val key = if (sel == "auto") (if (s.nrSinr == null) "sinr" else "nrsinr") else sel
        val value: Double?
        val metric: Metric
        when (key) {
            "sinr" -> { value = s.sinr; metric = Metrics.SINR }
            "rsrp" -> { value = s.rsrp; metric = Metrics.RSRP }
            "nrsinr" -> { value = s.nrSinr; metric = Metrics.SINR }
            else -> { value = s.nrRsrp; metric = Metrics.RSRP }
        }
        val label = OPTIONS.firstOrNull { it.first == key }?.second ?: key
        return Picked(key, label, value, metric)
    }

    /** کیفیت 0..100 */
    fun quality(m: Metric, v: Double): Double = m.fraction(v) * 100.0

    /** هرچی سیگنال بهتر، بیپ تیزتر */
    fun beepFreq(q: Double): Double = 350.0 + q * 9.0

    /** هرچی سیگنال بهتر، بیپ سریع‌تر (۱۰۰۰ms تا ۱۵۰ms) */
    fun beepIntervalMs(q: Double): Long = (1000.0 - q * 8.5).toLong()
}
