package com.farhad.modem.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Beeper
import com.farhad.modem.Store
import com.farhad.modem.core.Align
import com.farhad.modem.core.fmt
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/** جهت‌یابی آنتن: عدد بزرگ + «بهترین» + بیپ اختیاری (پیش‌فرض بی‌صدا، با خروج از تب دوباره خاموش می‌شه). */
@Composable
fun AlignScreen() {
    val snap by Store.snapshot.collectAsState()
    var sel by remember { mutableStateOf("auto") }
    var peak by remember { mutableStateOf<Double?>(null) }
    var beepOn by remember { mutableStateOf(false) }
    val selNow by rememberUpdatedState(sel)
    val beeper = remember { Beeper() }

    // وقتی این تب بازه، سرویس سریع‌تر (۰.۸ ثانیه) سیگنال می‌خونه
    DisposableEffect(Unit) {
        Store.alignActive = true
        onDispose { Store.alignActive = false }
    }

    val s = snap
    val picked = if (s == null) null else Align.pick(s, sel)
    val value = picked?.value
    val pkey = picked?.key ?: ""

    LaunchedEffect(pkey) { peak = null }
    LaunchedEffect(snap) {
        val v = value
        val p = peak
        if (v == null) peak = null else if (p == null || v > p) peak = v
    }

    LaunchedEffect(beepOn) {
        while (beepOn && isActive) {
            val cur = Store.snapshot.value
            val pk = if (cur == null) null else Align.pick(cur, selNow)
            val v = pk?.value
            if (pk != null && v != null) {
                val q = Align.quality(pk.metric, v)
                beeper.beep(Align.beepFreq(q))
                delay(Align.beepIntervalMs(q))
            } else {
                delay(800)
            }
        }
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Sec("آنتن یا مودم رو آروم جابه‌جا کن؛ عدد بالاتر و بیپ تندتر = سیگنال بهتر. هر جابه‌جایی رو چند ثانیه صبر کن تا عدد جا بیفته.")
        Drop(Align.OPTIONS, sel, Modifier.fillMaxWidth()) { sel = it; peak = null }

        val col = if (picked == null || value == null) C.mute else levelColor(picked.metric.level(value))
        Row(
            Modifier.fillMaxWidth().padding(top = 18.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(if (value == null) "-" else fmt(value), fontSize = 60.sp, fontWeight = FontWeight.Bold, color = col)
            if (picked != null && value != null) {
                Text(picked.metric.unit, fontSize = 20.sp, color = C.mute, modifier = Modifier.padding(start = 6.dp, bottom = 10.dp))
            }
        }
        Text(
            if (picked == null) "..." else if (value == null) picked.label + " — سیگنالی دریافت نمی‌شه" else picked.label,
            color = C.mute, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        )
        if (picked != null) SignalBar("", value, picked.metric)

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val pk = peak
            Tag("بهترین: " + (if (pk == null || picked == null) "-" else fmt(pk) + " " + picked.metric.unit))
            Btn("ریست", Modifier.padding(start = 4.dp)) { peak = null }
        }
        Gap(8)
        val tags = mutableListOf<String>()
        if (s != null) {
            s.band?.let { tags.add("Band: B$it") }
            s.pci?.let { tags.add("PCI: $it") }
            if (s.cellId.isNotEmpty()) tags.add("Cell: " + s.cellId)
        }
        TagRows(tags)
        Gap(8)
        Btn(
            if (beepOn) "🔊 بیپ روشن" else "🔈 بیپ خاموش", Modifier.fillMaxWidth(), kind = if (beepOn) 1 else 0
        ) { beepOn = !beepOn }
    }
}
