package com.farhad.modem

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.farhad.modem.core.Snapshot
import com.farhad.modem.core.fmt

/** Home-screen widget: signal summary. Updated by the monitor service; tap opens the app. */
class SignalWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        Store.init(context)
        push(context, Store.snapshot.value, Store.online.value)
    }

    companion object {
        fun push(ctx: Context, s: Snapshot?, online: Boolean) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, SignalWidget::class.java))
                if (ids.isEmpty()) return
                val v = RemoteViews(ctx.packageName, R.layout.widget_signal)
                val main: String
                val sub: String
                if (s == null || !online) {
                    main = if (online) "Tap to open" else "Modem not reachable"
                    sub = ""
                } else {
                    main = (s.rsrp?.let { "RSRP " + fmt(it) } ?: "No signal") + (s.mainSinr?.let { "  SINR " + fmt(it) } ?: "")
                    sub = (s.band?.let { "B$it" } ?: "") + (s.pci?.let { "  PCI $it" } ?: "") + (s.earfcn?.let { "  EARFCN $it" } ?: "")
                }
                v.setTextViewText(R.id.w_main, main)
                v.setTextViewText(R.id.w_sub, sub)
                val open = PendingIntent.getActivity(
                    ctx, 2, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                v.setOnClickPendingIntent(R.id.w_root, open)
                mgr.updateAppWidget(ids, v)
            } catch (e: Exception) {
                Store.log("widget ERR $e")
            }
        }
    }
}
