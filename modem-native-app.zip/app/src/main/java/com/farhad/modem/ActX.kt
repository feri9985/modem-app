package com.farhad.modem

import com.farhad.modem.core.Xml
import com.farhad.modem.core.lockFreqState
import com.farhad.modem.core.setLockFreq
import com.farhad.modem.core.setLteBands
import com.farhad.modem.core.signal
import java.math.BigInteger

/** Extra operations (experimental 5G lock). Blocking; call on an IO thread. */
object ActX {
    /**
     * EXPERIMENTAL: asks the modem for a 5G cell lock with the same lock-freq request, Mode = 1 (5G).
     * The modem page only has this for 4G, so this is a guess. It is verified by reading the state back and by checking
     * that the modem is still online; otherwise the lock is removed automatically.
     */
    fun try5gLock(nrarfcn: Int, pci: Int, band: Int = 78): Boolean {
        val c = Store.client
        try {
            c.setLockFreq(false, 0, 0)
            c.setLteBands(BigInteger.ZERO)
            Thread.sleep(1500)
            val r = c.post(
                "/api/net/lock-freq",
                "<request><Mode>1</Mode><Enable>2</Enable><Freq>$nrarfcn</Freq><Band>$band</Band><CellId>$pci</CellId></request>"
            )
            if (!Xml.isOk(r)) {
                Store.toast("Modem refused the 5G lock (" + (Xml.errorCode(r).ifEmpty { r.take(40) }) + ")")
                return false
            }
            Thread.sleep(5000)
            val st = try { c.lockFreqState() } catch (e: Exception) { null }
            val alive = try { c.signal(System.currentTimeMillis()) != null } catch (e: Exception) { false }
            if (!alive || st == null || st.enable == 0) {
                Store.toast("5G lock not accepted — removing it")
                revert()
                return false
            }
            Store.toast("Modem accepted a lock: " + st.describe() + ". Check the 5G cell on Home. If the internet drops, tap Remove lock.")
            return true
        } catch (e: Exception) {
            Store.toast("5G lock failed: $e")
            revert()
            return false
        } finally {
            Act.refreshLock()
        }
    }

    fun revert() {
        try {
            Store.client.setLockFreq(false, 0, 0)
            Store.client.post(
                "/api/net/lock-freq",
                "<request><Mode>1</Mode><Enable>0</Enable><Freq>0</Freq><Band>0</Band><CellId>0</CellId></request>"
            )
            Store.client.setLteBands(BigInteger.ZERO)
        } catch (e: Exception) {
            Store.log("revert ERR $e")
        }
    }
}
