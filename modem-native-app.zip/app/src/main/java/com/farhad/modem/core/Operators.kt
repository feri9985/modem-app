package com.farhad.modem.core

/** A colored badge (name + color) for the operator the modem is registered on. Not an official logo. */
data class Brand(val name: String, val short: String, val color: Long, val darkText: Boolean)

object Operators {
    /** Iran (MCC 432). Shatel and Azartel are MVNOs with their own codes. */
    val PLMN: Map<String, String> = mapOf(
        "43211" to "MCI", "43214" to "TKC", "43219" to "MTCE", "43220" to "RighTel", "43232" to "Taliya",
        "43235" to "Irancell", "43208" to "Shatel", "43202" to "Azartel"
    )

    private val BRANDS: Map<String, Brand> = mapOf(
        "Irancell" to Brand("Irancell", "Irancell", 0xFFFFCC00, true),
        "MCI" to Brand("Hamrah-e Aval", "MCI", 0xFF0A8FD6, false),
        "RighTel" to Brand("RighTel", "RighTel", 0xFF7B2D9B, false),
        "Shatel" to Brand("Shatel Mobile", "Shatel", 0xFF1E9E5A, false),
        "Aptel" to Brand("Aptel", "Aptel", 0xFFE8731A, false),
        "Taliya" to Brand("Taliya", "Taliya", 0xFF14A0A0, false),
        "Azartel" to Brand("Azartel", "Azartel", 0xFFC0392B, false),
        "TKC" to Brand("Kish", "TKC", 0xFF4A6FA5, false),
        "MTCE" to Brand("MTCE", "MTCE", 0xFF8E6E3A, false)
    )

    private val NAME_HINTS: List<Pair<String, String>> = listOf(
        "irancell" to "Irancell", "mtn" to "Irancell", "mci" to "MCI", "hamrah" to "MCI", "همراه" to "MCI",
        "ایرانسل" to "Irancell", "rightel" to "RighTel", "رایتل" to "RighTel", "shatel" to "Shatel", "شاتل" to "Shatel",
        "aptel" to "Aptel", "آپتل" to "Aptel", "taliya" to "Taliya", "azartel" to "Azartel", "kish" to "TKC"
    )

    /** Key of the operator ("Irancell", "MCI", ...) or null if unknown. The PLMN code wins, then the name the modem reports. */
    fun key(plmn: String, name: String): String? {
        PLMN[plmn.trim()]?.let { return it }
        val n = name.lowercase()
        return NAME_HINTS.firstOrNull { n.contains(it.first) }?.second
    }

    fun brand(plmn: String, name: String): Brand {
        val k = key(plmn, name)
        if (k != null) BRANDS[k]?.let { return it }
        val label = name.ifEmpty { plmn }.ifEmpty { "No service" }
        return Brand(label, label.take(10), 0xFF55657A, false)
    }
}

/** Antenna bars (0..5) from RSRP, like a phone's signal indicator. */
object Bars {
    fun fromRsrp(v: Double?): Int = when {
        v == null -> 0
        v >= -80 -> 5
        v >= -90 -> 4
        v >= -100 -> 3
        v >= -110 -> 2
        v >= -120 -> 1
        else -> 0
    }
}
