package com.farhad.modem.core

import java.math.BigInteger

/** escape ساده تا اسم پروفایل‌ها (فارسی، فاصله، | و ...) داخل یه خط متن ذخیره بشه */
object Esc {
    fun enc(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when (c) {
                '\\' -> sb.append("\\\\")
                '|' -> sb.append("\\p")
                '\n' -> sb.append("\\n")
                '\r' -> { }
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun dec(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    '\\' -> sb.append('\\')
                    'p' -> sb.append('|')
                    'n' -> sb.append('\n')
                    else -> sb.append(s[i + 1])
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }
}

/** پروفایل باند: lte/nr به‌صورت hex، option = حالت 5G ("" / "0" NSA / "1" SA / "2" SA+NSA)، en5 = 4G+5G فعال */
data class Profile(
    val name: String,
    val lte: String,
    val nr: String,
    val option: String,
    val en5: Boolean
) {
    fun lteMask(): BigInteger = Bands.parseHex(lte)
    fun nrMask(): BigInteger = Bands.parseHex(nr)

    fun describe(): String {
        val l = Bands.bitsOf(lteMask(), 64)
        val r = Bands.bitsOf(nrMask(), 128)
        var s = if (l.size > 5) "4G×" + l.size else l.joinToString(" ") { "B$it" }
        if (r.isNotEmpty()) {
            s += (if (s.isNotEmpty()) " " else "") + (if (r.size > 4) "5G×" + r.size else r.joinToString(" ") { "n$it" })
        }
        return s
    }
}

object ProfileCodec {
    fun encode(list: List<Profile>): String =
        list.joinToString("\n") { Esc.enc(it.name) + "|" + it.lte + "|" + it.nr + "|" + it.option + "|" + (if (it.en5) "1" else "0") }

    fun decode(s: String): List<Profile> {
        val out = mutableListOf<Profile>()
        for (line in s.split("\n")) {
            if (line.isBlank()) continue
            val p = line.split("|")
            if (p.size < 5) continue
            out.add(Profile(Esc.dec(p[0]), p[1], p[2], p[3], p[4] == "1"))
        }
        return out
    }
}
