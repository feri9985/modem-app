package com.farhad.modem.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Store
import com.farhad.modem.core.CellEntry
import com.farhad.modem.core.CellLock
import com.farhad.modem.core.detectCellLock
import com.farhad.modem.core.fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private fun cellText(c: CellEntry): String =
    "PCI " + c.pci + "   RSRP " + (c.rsrp?.let { fmt(it) } ?: "-") + "   EARFCN " + c.earfcn

@Composable
fun CellLockScreen() {
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val snap by Store.snapshot.collectAsState()
    val saved4 by Store.cells4.collectAsState()
    val saved5 by Store.cells5.collectAsState()

    var mode by remember { mutableStateOf("auto") }
    var lockMode by remember { mutableStateOf("pci") }
    var scanned4 by remember { mutableStateOf<List<CellEntry>>(emptyList()) }
    var scanned5 by remember { mutableStateOf<List<CellEntry>>(emptyList()) }
    var detecting by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf("") }

    fun scan() {
        val s = snap
        if (s == null) {
            Store.toast("No signal data yet")
            return
        }
        scanned4 = listOfNotNull(CellLock.serving(s, 4))
        scanned5 = listOfNotNull(CellLock.serving(s, 5))
        Store.toast("Showing the serving cell. " + CellLock.NOT_MAPPED_MSG)
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Sec("Cell lock")
        Drop(listOf(Pair("auto", "Cell lock: auto lock"), Pair("manual", "Cell lock: manual lock")), mode, Modifier.fillMaxWidth()) { mode = it }
        Gap(6)
        Drop(listOf(Pair("pci", "Lock mode: PCI lock")), lockMode, Modifier.fillMaxWidth()) { lockMode = it }
        Gap(6)
        Btn("Scan: scan neighborhood cell", Modifier.fillMaxWidth(), kind = 1) { scan() }

        CellList("4G cell lock list", 4, scanned4, saved4, snap?.let { CellLock.serving(it, 4) }, "cells4")
        CellList("5G cell lock list", 5, scanned5, saved5, snap?.let { CellLock.serving(it, 5) }, "cells5")

        Sec("Local physical cell locking")
        LocalLock("4G", 4, "lock4", Store.lockCells4.collectAsState().value, snap?.let { CellLock.serving(it, 4) })
        LocalLock("5G", 5, "lock5", Store.lockCells5.collectAsState().value, snap?.let { CellLock.serving(it, 5) })

        Sec("Cell-lock API detection (read-only: nothing is changed on the modem)")
        Btn(if (detecting) "Detecting..." else "Detect cell-lock API", Modifier.fillMaxWidth()) {
            if (!detecting) {
                detecting = true
                out = "Detecting...\n"
                scope.launch(Dispatchers.IO) {
                    val sb = StringBuilder()
                    Store.client.detectCellLock { sb.append(it).append('\n'); out = sb.toString().take(40000) }
                    detecting = false
                }
            }
        }
        if (out.isNotEmpty()) {
            Gap(6)
            SelectionContainer { Mono(out) }
            Gap(4)
            Btn("Copy text", Modifier.fillMaxWidth()) {
                clip.setText(AnnotatedString(out))
                Store.toast("Copied")
            }
        }
        Gap(12)
    }
}

/** List of cells (scanned + saved). Ticking the white checkbox adds the cell to the saved list. */
@Composable
private fun CellList(title: String, rat: Int, scanned: List<CellEntry>, saved: List<CellEntry>, serving: CellEntry?, prefKey: String) {
    var pci by remember { mutableStateOf("") }
    var earfcn by remember { mutableStateOf("") }
    val all = (scanned + saved).distinctBy { it.key }
    Sec(title)
    if (all.isEmpty()) Tag("No cells yet. Tap Scan, or add one below.")
    all.forEach { c ->
        val on = saved.any { it.key == c.key }
        Row(
            Modifier.fillMaxWidth().padding(bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Checkbox(
                checked = on,
                onCheckedChange = { v ->
                    val cur = if (rat == 4) Store.cells4.value else Store.cells5.value
                    val next = if (v) (cur.filter { it.key != c.key } + c) else cur.filter { it.key != c.key }
                    Store.saveCells(prefKey, next)
                    Store.toast(if (v) "Added & saved" else "Removed")
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color.White, uncheckedColor = Color.White, checkmarkColor = Color.Black
                )
            )
            Text(
                cellText(c) + (if (serving != null && serving.key == c.key) "  (serving)" else ""),
                color = C.text, fontSize = 14.sp, modifier = Modifier.weight(1f)
            )
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = pci, onValueChange = { pci = it }, placeholder = { Text("PCI") },
            singleLine = true, modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
            value = earfcn, onValueChange = { earfcn = it }, placeholder = { Text("EARFCN") },
            singleLine = true, modifier = Modifier.weight(1f)
        )
        Btn("Add", Modifier.width(76.dp)) {
            val p = CellLock.parseIntOrNull(pci)
            val e = CellLock.parseIntOrNull(earfcn)
            if (!CellLock.validPci(p)) {
                Store.toast("PCI must be 1 ~ 512")
            } else if (!CellLock.validEarfcn(e)) {
                Store.toast("EARFCN must be 1 ~ 16777215")
            } else {
                val cur = if (rat == 4) Store.cells4.value else Store.cells5.value
                val c = CellEntry(rat, p ?: 1, e ?: 1, null)
                Store.saveCells(prefKey, cur.filter { it.key != c.key } + c)
                pci = ""
                earfcn = ""
                Store.toast("Added & saved")
            }
        }
    }
}

@Composable
private fun LocalLock(name: String, rat: Int, prefKey: String, list: List<CellEntry>, serving: CellEntry?) {
    var lock by remember { mutableStateOf(false) }
    var earfcn by remember { mutableStateOf("") }
    var pci by remember { mutableStateOf("") }

    Text("$name locked physical cell list", color = C.text, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
    if (list.isEmpty()) Tag("Empty")
    list.forEach { c ->
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PCI " + c.pci + "   EARFCN " + c.earfcn, color = C.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Btn("✕", Modifier.width(52.dp), kind = 3) {
                val cur = if (rat == 4) Store.lockCells4.value else Store.lockCells5.value
                Store.saveCells(prefKey, cur.filter { it.key != c.key })
            }
        }
    }

    Text("Cell: unlock / lock specific physical cell", color = C.mute, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = !lock, onClick = { lock = false })
        Text("Unlock", color = C.text, fontSize = 14.sp)
        RadioButton(selected = lock, onClick = { lock = true })
        Text("Lock specific physical cell", color = C.text, fontSize = 14.sp)
    }

    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = earfcn, onValueChange = { earfcn = it }, label = { Text("EARFCN") },
            placeholder = { Text("Range: 1 ~ 16777215") },
            singleLine = true, modifier = Modifier.weight(1f)
        )
        Btn("Get", Modifier.width(70.dp)) {
            val e = serving?.earfcn
            if (e == null) Store.toast("EARFCN not available from the modem") else earfcn = e.toString()
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = pci, onValueChange = { pci = it }, label = { Text("PCI") },
            placeholder = { Text("Range: 1 ~ 512") },
            singleLine = true, modifier = Modifier.weight(1f)
        )
        Btn("Get", Modifier.width(70.dp)) {
            val p = serving?.pci
            if (p == null) Store.toast("PCI not available from the modem") else pci = p.toString()
        }
    }
    Gap(6)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("Add", Modifier.weight(1f)) {
            val p = CellLock.parseIntOrNull(pci)
            val e = CellLock.parseIntOrNull(earfcn)
            if (!CellLock.validEarfcn(e)) {
                Store.toast("EARFCN must be 1 ~ 16777215")
            } else if (!CellLock.validPci(p)) {
                Store.toast("PCI must be 1 ~ 512")
            } else {
                val cur = if (rat == 4) Store.lockCells4.value else Store.lockCells5.value
                val c = CellEntry(rat, p ?: 1, e ?: 1, null)
                Store.saveCells(prefKey, cur.filter { it.key != c.key } + c)
                Store.toast("Added & saved")
            }
        }
        Btn("Apply", Modifier.weight(1f), kind = 1) {
            Store.toast(CellLock.NOT_MAPPED_MSG)
        }
    }
}
