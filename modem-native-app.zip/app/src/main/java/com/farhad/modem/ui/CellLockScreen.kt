package com.farhad.modem.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Act
import com.farhad.modem.Store
import com.farhad.modem.core.Bands
import com.farhad.modem.core.CellEntry
import com.farhad.modem.core.CellLock
import com.farhad.modem.core.FreqPlan
import com.farhad.modem.core.Snapshot
import com.farhad.modem.core.freqRanges
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun CellLockScreen() {
    val snap by Store.snapshot.collectAsState()
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Sec("Band selection (same as the modem's Developer options)")
        BandSelection(snap)
        Sec("Saved 4G cells")
        SavedCells(snap)
        Gap(12)
    }
}

/** Band-lock, Frequency-lock and Cell lock use the exact requests the modem page sends. */
@Composable
private fun BandSelection(snap: Snapshot?) {
    val scope = rememberCoroutineScope()
    val binfo by Store.bandInfo.collectAsState()
    val state by Store.lockFreq.collectAsState()
    var lockType by remember { mutableStateOf("none") }
    var band by remember { mutableStateOf("") }
    var freq by remember { mutableStateOf("") }
    var pci by remember { mutableStateOf("") }
    val bands = (binfo?.lteSup ?: emptyList()).map { Pair(it.toString(), "B$it") }

    LaunchedEffect(Unit) { launch(Dispatchers.IO) { Act.refreshLock() } }

    Tag(state?.describe() ?: "Lock state: unknown")
    binfo?.let { b -> Gap(4); Tag("Bands now: " + Bands.bitsOf(b.lteCur, 64).joinToString(" ") { "B$it" }) }
    Gap(6)
    Drop(
        listOf(Pair("none", "No lock"), Pair("band", "Band-lock"), Pair("freq", "Frequency-lock"), Pair("cell", "Cell lock")),
        lockType, Modifier.fillMaxWidth()
    ) { lockType = it }
    if (lockType != "none") {
        Gap(6)
        if (bands.isNotEmpty()) Drop(bands, band.ifEmpty { bands[0].first }, Modifier.fillMaxWidth()) { band = it }
        if (lockType == "freq" || lockType == "cell") {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = freq, onValueChange = { freq = it }, label = { Text("Frequency (EARFCN)") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Btn("Get", Modifier.width(70.dp)) {
                    val e = snap?.earfcn
                    if (e == null) Store.toast("EARFCN not available from the modem") else freq = e.toString()
                }
            }
        }
        if (lockType == "cell") {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = pci, onValueChange = { pci = it }, label = { Text("PCI") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Btn("Get", Modifier.width(70.dp)) {
                    val p = snap?.pci
                    if (p == null) Store.toast("PCI not available from the modem") else pci = p.toString()
                }
            }
        }
    }
    Gap(6)
    Btn("Save", Modifier.fillMaxWidth(), kind = 1) {
        val f = CellLock.parseIntOrNull(freq)
        val p = CellLock.parseIntOrNull(pci)
        val b = (band.ifEmpty { bands.firstOrNull()?.first ?: "" }).toIntOrNull()
        if ((lockType == "freq" || lockType == "cell") && !CellLock.validEarfcn(f)) {
            Store.toast("Frequency must be a number")
        } else if (lockType == "cell" && p == null) {
            Store.toast("Enter the PCI")
        } else {
            scope.launch(Dispatchers.IO) { Act.bandSelection(lockType, b, f, p) }
        }
    }
    Gap(4)
    Text("If the internet drops after a lock, choose No lock and tap Save.", color = C.mute, fontSize = 12.sp)
}

/** Cells you typed in (e.g. from a phone cell-info app). Lock = Cell lock on that cell. */
@Composable
private fun SavedCells(snap: Snapshot?) {
    val scope = rememberCoroutineScope()
    val saved by Store.cells4.collectAsState()
    var pci by remember { mutableStateOf("") }
    var earfcn by remember { mutableStateOf("") }

    if (saved.isEmpty()) Tag("No saved cells yet")
    saved.forEach { c ->
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PCI " + c.pci + "   EARFCN " + c.earfcn, color = C.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Btn("Lock", Modifier.width(70.dp)) {
                scope.launch(Dispatchers.IO) {
                    val b = FreqPlan.bandFor(c.earfcn, Store.client.freqRanges())
                    if (b == null) Store.toast("EARFCN " + c.earfcn + " is not in any LTE band") else Act.bandSelection("cell", b, c.earfcn, c.pci)
                }
            }
            Btn("✕", Modifier.width(52.dp), kind = 3) { Store.saveCells(saved.filter { it.key != c.key }) }
        }
    }
    Gap(4)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = pci, onValueChange = { pci = it }, label = { Text("PCI") },
            singleLine = true, modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
            value = earfcn, onValueChange = { earfcn = it }, label = { Text("EARFCN") },
            singleLine = true, modifier = Modifier.weight(1f)
        )
    }
    Gap(6)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Btn("Get current cell", Modifier.weight(1f)) {
            val cur = snap?.let { CellLock.serving4(it) }
            if (cur == null) {
                Store.toast("The modem does not report the current PCI/EARFCN")
            } else {
                pci = cur.pci.toString()
                earfcn = cur.earfcn.toString()
            }
        }
        Btn("Add", Modifier.weight(1f), kind = 1) {
            val p = CellLock.parseIntOrNull(pci)
            val e = CellLock.parseIntOrNull(earfcn)
            if (p == null || p < 0 || p > 503) {
                Store.toast("PCI must be 0 ~ 503")
            } else if (!CellLock.validEarfcn(e)) {
                Store.toast("EARFCN must be a number")
            } else {
                val c = CellEntry(4, p, e ?: 1, null)
                Store.saveCells(saved.filter { it.key != c.key } + c)
                pci = ""
                earfcn = ""
                Store.toast("Saved")
            }
        }
    }
}
