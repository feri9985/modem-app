package com.farhad.modem.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Store
import com.farhad.modem.core.FoundNetwork
import com.farhad.modem.core.Host
import com.farhad.modem.core.Xml
import com.farhad.modem.core.hosts
import com.farhad.modem.core.macFilter
import com.farhad.modem.core.macFilterMode
import com.farhad.modem.core.normMac
import com.farhad.modem.core.parseMacFilter
import com.farhad.modem.core.setBlocked
import com.farhad.modem.core.operatorInfo
import com.farhad.modem.core.registerInfo
import com.farhad.modem.core.scanPlmn
import com.farhad.modem.core.setRegister
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ======================= Operator =======================
@Composable
fun OperatorScreen() {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("...") }
    val rat = "7"   // 4G/5G (LTE); this modem lists no 3G/2G modes
    var plmn by remember { mutableStateOf("") }
    var scanning by remember { mutableStateOf(false) }
    var nets by remember { mutableStateOf<List<FoundNetwork>>(emptyList()) }
    var rawScan by remember { mutableStateOf("") }

    fun show() {
        scope.launch(Dispatchers.IO) {
            status = try {
                val r = Store.client.registerInfo()
                val o = Store.client.operatorInfo()
                "Mode: " + (if (r.manual) "Manual" else "Auto") + "\nPLMN: " + r.plmn.ifEmpty { "-" } +
                    "  Rat: " + r.rat.ifEmpty { "-" } + "\nCurrent operator: " + o.name + " " + o.plmn
            } catch (e: Exception) {
                "ERR $e"
            }
        }
    }

    fun setReg(mode: Int, p: String, r: String) {
        Store.toast("Applying...")
        scope.launch(Dispatchers.IO) {
            val x = Store.client.setRegister(mode, p, r)
            Store.toast(if (Xml.isOk(x)) "Done ✓ wait a few seconds" else "Error: " + x.take(100))
            delay(5000)
            show()
        }
    }

    fun scan() {
        scanning = true
        nets = emptyList()
        rawScan = ""
        Store.toast("Scan started...")
        scope.launch(Dispatchers.IO) {
            try {
                val r = Store.client.scanPlmn()
                nets = r.first
                rawScan = if (r.first.isEmpty()) r.second.take(1200) else ""
            } catch (e: Exception) {
                rawScan = "ERR $e"
            }
            scanning = false
        }
    }

    LaunchedEffect(Unit) { show() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Sec("Current status")
        Mono(status)
        Gap(6)
        Btn("Automatic (Auto)", Modifier.fillMaxWidth()) { setReg(0, "", "") }
        Sec("Quick select (no scan)")
        Gap(6)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Irancell", Modifier.weight(1f)) { setReg(1, "43235", rat) }
            Btn("MCI (Hamrah-e Aval)", Modifier.weight(1f)) { setReg(1, "43211", rat) }
            Btn("RighTel", Modifier.weight(1f)) { setReg(1, "43220", rat) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Shatel Mobile", Modifier.weight(1f)) { setReg(1, "43208", rat) }
            Btn("Taliya", Modifier.weight(1f)) { setReg(1, "43232", rat) }
            Btn("Aptel", Modifier.weight(1f)) { Store.toast("Aptel: type its PLMN in Custom PLMN below") }
        }
        Text(
            "Shatel / Aptel are virtual operators. If the modem cannot register on their own code, pick the real network they run on (Irancell, MCI or RighTel).",
            color = C.mute, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
        )
        Sec("Custom PLMN")
        OutlinedTextField(
            value = plmn, onValueChange = { plmn = it }, placeholder = { Text("PLMN e.g. 43235") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Gap(6)
        Btn("Connect to the PLMN above", Modifier.fillMaxWidth()) { if (plmn.isNotBlank()) setReg(1, plmn.trim(), rat) }
        Sec("Scan nearby operators")
        Btn(
            if (scanning) "Scanning..." else "Scan (internet drops for a few minutes)", Modifier.fillMaxWidth(), kind = 1
        ) { if (!scanning) scan() }
        if (scanning) Sec("Takes 1 to 3 minutes and the internet drops. Please wait.")
        nets.forEach { n ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(12.dp)).background(C.panel).padding(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    OperatorBadge(com.farhad.modem.core.Operators.brand(n.plmn, n.name))
                    Text(n.name, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    n.plmn + "  Rat:" + n.rat + "  " + (if (n.state == "2") "(current)" else if (n.state == "3") "(forbidden)" else ""),
                    color = C.mute, fontSize = 14.sp
                )
                Gap(6)
                Btn("Connect to this operator", Modifier.fillMaxWidth(), kind = 1) { setReg(1, n.plmn, n.rat) }
            }
        }
        if (rawScan.isNotEmpty()) Mono(rawScan)
    }
}

// ======================= Devices =======================
@Composable
fun DevicesScreen() {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var list by remember { mutableStateOf<List<Host>>(emptyList()) }
    var raw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var blocked by remember { mutableStateOf<Set<String>>(emptySet()) }
    var blockedList by remember { mutableStateOf<List<com.farhad.modem.core.BlockedDevice>>(emptyList()) }

    fun load() {
        loading = true
        scope.launch(Dispatchers.IO) {
            try {
                val r = Store.client.hosts()
                list = r.first
                raw = r.second
                err = ""
                try {
                    val mf = Store.client.macFilter()
                    blockedList = parseMacFilter(mf)
                    blocked = if (macFilterMode(mf) == "deny") blockedList.map { it.mac }.toSet() else emptySet()
                } catch (e: Exception) { }
            } catch (e: Exception) {
                err = "Could not reach the modem: $e"
            }
            loading = false
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Btn("Refresh", Modifier.fillMaxWidth()) { load() }
        if (loading) Sec("Loading...")
        if (err.isNotEmpty()) Sec(err)
        if (!loading && err.isEmpty()) Sec("Connected devices: " + list.size)
        list.forEach { h ->
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(12.dp)).background(C.panel).padding(12.dp)) {
                Text(h.name.ifEmpty { "Unknown" }, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(h.ip, color = C.mute, fontSize = 14.sp)
                Text(h.mac + "  " + h.iface, color = C.mute, fontSize = 14.sp)
                val isB = blocked.contains(normMac(h.mac))
                Btn(if (isB) "Unblock" else "Block (kick off Wi-Fi)", Modifier.fillMaxWidth().padding(top = 6.dp), kind = if (isB) 0 else 3) {
                    scope.launch(Dispatchers.IO) {
                        val r = Store.client.setBlocked(h.mac, h.name, !isB)
                        Store.toast(if (r.isEmpty()) (if (isB) "Unblocked" else "Blocked") else "Failed: $r")
                        load()
                    }
                }
            }
        }
        val others = blockedList.filter { b -> list.none { normMac(it.mac) == b.mac } }
        if (others.isNotEmpty()) {
            Sec("Blocked devices (not connected now)")
            others.forEach { b ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(b.mac + " " + b.name, color = C.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Btn("Unblock", Modifier.width(100.dp)) {
                        scope.launch(Dispatchers.IO) {
                            val r = Store.client.setBlocked(b.mac, b.name, false)
                            Store.toast(if (r.isEmpty()) "Unblocked" else "Failed: $r")
                            load()
                        }
                    }
                }
            }
        }
        Text("Blocking uses the modem's Wi-Fi MAC filter (deny list) and works for Wi-Fi devices.", color = C.mute, fontSize = 11.sp)
        if (!loading && list.isEmpty() && err.isEmpty()) Mono(raw.take(1500))
    }
}

@Composable
fun Mono(t: String) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.chartBg).padding(8.dp)) {
        SelectionContainer { Text(t, color = C.text, fontSize = 12.sp) }
    }
}
