package com.farhad.modem.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Store
import com.farhad.modem.core.FoundNetwork
import com.farhad.modem.core.Host
import com.farhad.modem.core.Xml
import com.farhad.modem.core.collect5g
import com.farhad.modem.core.explore
import com.farhad.modem.core.hosts
import com.farhad.modem.core.operatorInfo
import com.farhad.modem.core.reboot
import com.farhad.modem.core.registerInfo
import com.farhad.modem.core.scanPlmn
import com.farhad.modem.core.setRegister
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ======================= اپراتور =======================
@Composable
fun OperatorScreen() {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("...") }
    var rat by remember { mutableStateOf("7") }
    var plmn by remember { mutableStateOf("") }
    var scanning by remember { mutableStateOf(false) }
    var nets by remember { mutableStateOf<List<FoundNetwork>>(emptyList()) }
    var rawScan by remember { mutableStateOf("") }

    fun show() {
        scope.launch(Dispatchers.IO) {
            status = try {
                val r = Store.client.registerInfo()
                val o = Store.client.operatorInfo()
                "حالت: " + (if (r.manual) "دستی" else "خودکار") + "\nPLMN: " + r.plmn.ifEmpty { "-" } +
                    "  Rat: " + r.rat.ifEmpty { "-" } + "\nاپراتور فعلی: " + o.name + " " + o.plmn
            } catch (e: Exception) {
                "ERR $e"
            }
        }
    }

    fun setReg(mode: Int, p: String, r: String) {
        Store.toast("در حال اعمال...")
        scope.launch(Dispatchers.IO) {
            val x = Store.client.setRegister(mode, p, r)
            Store.toast(if (Xml.isOk(x)) "ثبت شد ✓ چند ثانیه صبر کن" else "خطا: " + x.take(100))
            delay(5000)
            show()
        }
    }

    fun scan() {
        scanning = true
        nets = emptyList()
        rawScan = ""
        Store.toast("شروع جستجو...")
        scope.launch(Dispatchers.IO) {
            try {
                val r = Store.client.scanPlmn()
                nets = r.first
                rawScan = if (r.first.isEmpty()) r.second.take(1200) else ""
            } catch (e: Exception) {
                rawScan = "ERR $e"
            }
            scanning = false
        }
    }

    LaunchedEffect(Unit) { show() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Sec("وضعیت فعلی")
        Mono(status)
        Gap(6)
        Btn("خودکار (Auto)", Modifier.fillMaxWidth()) { setReg(0, "", "") }
        Sec("انتخاب سریع (بدون جستجو)")
        Drop(
            listOf(Pair("7", "4G/5G NSA (LTE)"), Pair("2", "3G"), Pair("0", "2G")), rat, Modifier.fillMaxWidth()
        ) { rat = it }
        Gap(6)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("ایرانسل", Modifier.weight(1f)) { setReg(1, "43235", rat) }
            Btn("همراه اول", Modifier.weight(1f)) { setReg(1, "43211", rat) }
            Btn("رایتل", Modifier.weight(1f)) { setReg(1, "43220", rat) }
        }
        Sec("PLMN دلخواه")
        OutlinedTextField(
            value = plmn, onValueChange = { plmn = it }, placeholder = { Text("PLMN مثلا 43235") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Gap(6)
        Btn("اتصال به PLMN بالا", Modifier.fillMaxWidth()) { if (plmn.isNotBlank()) setReg(1, plmn.trim(), rat) }
        Sec("جستجوی اپراتورهای اطراف")
        Btn(
            if (scanning) "در حال جستجو..." else "جستجو (اینترنت چند دقیقه قطع می‌شه)", Modifier.fillMaxWidth(), kind = 1
        ) { if (!scanning) scan() }
        if (scanning) Sec("۱ تا ۳ دقیقه طول می‌کشه و اینترنت قطع می‌شه. صبر کن.")
        nets.forEach { n ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(12.dp)).background(C.panel).padding(12.dp)) {
                Text(n.name, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(
                    n.plmn + "  Rat:" + n.rat + "  " + (if (n.state == "2") "(فعلی)" else if (n.state == "3") "(ممنوع)" else ""),
                    color = C.mute, fontSize = 14.sp
                )
                Gap(6)
                Btn("اتصال به این اپراتور", Modifier.fillMaxWidth(), kind = 1) { setReg(1, n.plmn, n.rat) }
            }
        }
        if (rawScan.isNotEmpty()) Mono(rawScan)
    }
}

// ======================= دستگاه‌ها =======================
@Composable
fun DevicesScreen() {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var list by remember { mutableStateOf<List<Host>>(emptyList()) }
    var raw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }

    fun load() {
        loading = true
        scope.launch(Dispatchers.IO) {
            try {
                val r = Store.client.hosts()
                list = r.first
                raw = r.second
                err = ""
            } catch (e: Exception) {
                err = "ارتباط با مودم برقرار نشد: $e"
            }
            loading = false
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Btn("Refresh", Modifier.fillMaxWidth()) { load() }
        if (loading) Sec("Loading...")
        if (err.isNotEmpty()) Sec(err)
        if (!loading && err.isEmpty()) Sec("دستگاه‌های متصل: " + list.size)
        list.forEach { h ->
            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(12.dp)).background(C.panel).padding(12.dp)) {
                Text(h.name.ifEmpty { "Unknown" }, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(h.ip, color = C.mute, fontSize = 14.sp)
                Text(h.mac + "  " + h.iface, color = C.mute, fontSize = 14.sp)
            }
        }
        if (!loading && list.isEmpty() && err.isEmpty()) Mono(raw.take(1500))
    }
}

// ======================= ابزارها =======================
@Composable
fun ToolsScreen() {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val logText by Store.logText.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf("") }
    var collecting by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("/html/developmode.html") }
    var method by remember { mutableStateOf("GET") }
    var path by remember { mutableStateOf("/api/net/net-mode") }
    var body by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Reboot modem?") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    Store.toast("Reboot...")
                    scope.launch(Dispatchers.IO) { Store.client.reboot() }
                }) { Text("Reboot") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("لغو") } }
        )
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Btn("Reboot modem", Modifier.fillMaxWidth(), kind = 2) { confirm = true }
        Gap(6)
        Btn("باز کردن صفحه‌ی وب مودم (مرورگر)", Modifier.fillMaxWidth()) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://" + Store.savedIp())))
            } catch (e: Exception) {
                Store.toast("مرورگر پیدا نشد")
            }
        }

        Sec("برای ساخت قفل n78/n48: این دکمه رو بزن، صبر کن تا «done» بیاد، متن رو کپی کن و برام بفرست.")
        Btn(if (collecting) "در حال جمع‌آوری..." else "جمع‌آوری اطلاعات 5G", Modifier.fillMaxWidth(), kind = 1) {
            if (!collecting) {
                collecting = true
                out = "در حال جمع‌آوری...\n"
                val pg = page
                scope.launch(Dispatchers.IO) {
                    val sb = StringBuilder()
                    Store.client.collect5g(pg) { sb.append(it).append('\n'); out = sb.toString().take(7000) }
                    collecting = false
                }
            }
        }
        if (out.isNotEmpty()) {
            SelectionContainer { Mono(out) }
            Gap(4)
            Btn("کپی متن", Modifier.fillMaxWidth()) {
                clip.setText(AnnotatedString(out))
                Store.toast("کپی شد")
            }
        }
        Sec("صفحه‌ی دلخواه مودم برای بررسی (مثلاً Developer options)")
        OutlinedTextField(value = page, onValueChange = { page = it }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Sec("Explorer")
        Drop(listOf(Pair("GET", "GET"), Pair("POST", "POST")), method, Modifier.fillMaxWidth()) { method = it }
        OutlinedTextField(value = path, onValueChange = { path = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = body, onValueChange = { body = it }, placeholder = { Text("XML body (POST)") },
            minLines = 2, modifier = Modifier.fillMaxWidth()
        )
        Gap(6)
        Btn("Send", Modifier.fillMaxWidth()) {
            val m = method
            val p = path
            val b = body
            scope.launch(Dispatchers.IO) {
                result = try { Store.client.explore(m, p, b) } catch (e: Exception) { "ERR $e" }
            }
        }
        if (result.isNotEmpty()) SelectionContainer { Mono(result) }

        Sec("Log")
        SelectionContainer { Mono(logText) }
        Gap(12)
    }
}

@Composable
fun Mono(t: String) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.chartBg).padding(8.dp)) {
        Text(t, color = C.text, fontSize = 12.sp)
    }
}
