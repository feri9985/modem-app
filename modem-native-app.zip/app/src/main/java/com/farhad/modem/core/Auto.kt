package com.farhad.modem.core

/**
 * سوییچ خودکار پروفایل: اگه میانگین SINR در [mins] دقیقه زیر [thr] بمونه، پروفایل بعدی رو امتحان می‌کنه.
 * وقتی همه امتحان شدن، بهترین رو می‌ذاره و ۳۰ دقیقه دست نمی‌زنه.
 */
data class AutoState(
    val on: Boolean = false,
    val thr: Int = 5,
    val mins: Int = 3,
    val cur: String = "",
    val t0: Long = 0L,
    val hold: Long = 0L,
    val tried: Map<String, Double> = emptyMap()
)

class AutoResult(
    val state: AutoState,
    val msg: String,
    /** اگه null نباشه یعنی باید این پروفایل اعمال بشه (بعدش [Auto.afterApply] صدا زده بشه) */
    val apply: Profile? = null,
    val why: String = "",
    val avg: Double = 0.0
)

object Auto {
    const val SETTLE_MS = 45000L        // بعد از هر سوییچ برای وصل شدن دوباره‌ی مودم
    const val HOLD_MS = 30 * 60000L     // نگه داشتن بهترین پروفایل
    const val NO_SERVICE = -20.0        // نمونه‌ی بدون سرویس = خیلی بد

    fun hm(t: Long): String {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = t
        return String.format(java.util.Locale.US, "%02d:%02d", c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE))
    }

    fun decide(s: AutoState, ps: List<Profile>, hist: List<Sample>, now: Long): AutoResult {
        val win = s.mins * 60000L
        if (ps.size < 2) return AutoResult(s, "حداقل ۲ پروفایل ذخیره کن")
        if (now < s.hold) return AutoResult(s, "روی بهترین پروفایل نگه داشته شد تا " + hm(s.hold))
        val from = maxOf(s.t0, now - win)
        val pts = hist.filter { it.t >= from }
        val span = if (pts.isEmpty()) 0L else pts[pts.size - 1].t - pts[0].t
        if (now - s.t0 < win || pts.size < 3 || span < win * 0.7) return AutoResult(s, "در حال بررسی سیگنال...")

        var sum = 0.0
        for (p in pts) sum += (p.mainSinr ?: NO_SERVICE)
        val avg = Math.round(sum / pts.size * 10.0) / 10.0
        if (avg >= s.thr) return AutoResult(s.copy(tried = emptyMap()), "سیگنال خوبه (میانگین " + fmt(avg) + " dB)")

        var tried = s.tried
        if (s.cur.isNotEmpty()) tried = tried + (s.cur to avg)
        var target: Profile? = ps.firstOrNull { !tried.containsKey(it.name) }
        var why = "امتحان"
        var hold = s.hold
        if (target == null) {
            // همه امتحان شدن: بهترین رو انتخاب کن (اولین بیشینه)
            var best: Profile = ps[0]
            var bestScore = tried[best.name] ?: -99.0
            for (p in ps) {
                val sc = tried[p.name] ?: -99.0
                if (sc > bestScore) { best = p; bestScore = sc }
            }
            target = best
            why = "بهترین"
            hold = now + HOLD_MS
            tried = emptyMap()
        }
        return AutoResult(s.copy(tried = tried, hold = hold), "در حال سوییچ به «" + target.name + "»", target, why, avg)
    }

    /** نتیجه‌ی اعمال پروفایل رو روی state می‌ذاره. ok=false یعنی مودم قبول نکرد. */
    fun afterApply(s: AutoState, target: Profile, ok: Boolean, now: Long): AutoResult {
        if (!ok) return AutoResult(s.copy(t0 = now), "اعمال «" + target.name + "» ناموفق بود؛ بعداً دوباره")
        return AutoResult(s.copy(cur = target.name, t0 = now + SETTLE_MS), "«" + target.name + "» اعمال شد؛ صبر برای ارزیابی")
    }

    /** وقتی کاربر دستی پروفایل/باند رو اعمال کرد */
    fun manualApplied(s: AutoState, label: String, now: Long): AutoState =
        s.copy(cur = label, t0 = now + SETTLE_MS, tried = emptyMap())

    /** وقتی کاربر سوییچ خودکار رو روشن کرد */
    fun turnedOn(s: AutoState, now: Long): AutoState = s.copy(on = true, t0 = now, tried = emptyMap(), hold = 0L)

    fun encodeTried(m: Map<String, Double>): String =
        m.entries.joinToString("\n") { Esc.enc(it.key) + "|" + it.value }

    fun decodeTried(s: String): Map<String, Double> {
        val out = LinkedHashMap<String, Double>()
        for (line in s.split("\n")) {
            val k = line.lastIndexOf('|')
            if (k < 0) continue
            val v = line.substring(k + 1).toDoubleOrNull() ?: continue
            out[Esc.dec(line.substring(0, k))] = v
        }
        return out
    }
}
