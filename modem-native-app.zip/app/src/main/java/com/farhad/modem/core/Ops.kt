package com.farhad.modem.core

import java.net.URI

/** عملیات سطح‌بالا روی مودم (همه blocking هستن؛ روی نخ IO صدا بزن). */

const val NET_MODE = "/api/net/net-mode"

fun ModemClient.signal(now: Long = System.currentTimeMillis()): Snapshot? =
    parseSignal(get("/api/device/signal"), now)

data class Traffic(val downMbps: Double?, val upMbps: Double?)

fun ModemClient.traffic(): Traffic {
    val t = get("/api/monitoring/traffic-statistics")
    fun mbps(k: String): Double? = Xml.num(Xml.tag(t, k))?.let { it * 8.0 / 1e6 }
    return Traffic(mbps("CurrentDownloadRate"), mbps("CurrentUploadRate"))
}

private val NET_TYPES: Map<String, String> = mapOf(
    "0" to "No Service", "1" to "2G", "2" to "2G", "3" to "2G",
    "41" to "3G", "42" to "3G", "43" to "3G", "44" to "3G", "45" to "3G+", "46" to "3G+",
    "101" to "LTE 4G", "1011" to "LTE CA 4G+", "111" to "5G NR"
)

data class OperatorInfo(val name: String, val plmn: String, val netType: String)

fun ModemClient.operatorInfo(): OperatorInfo {
    val pl = get("/api/net/current-plmn")
    val st = get("/api/monitoring/status")
    val code = Xml.tag(st, "CurrentNetworkTypeEx")
    return OperatorInfo(Xml.tag(pl, "FullName").ifEmpty { "No Service" }, Xml.tag(pl, "Numeric"), NET_TYPES[code] ?: code)
}

fun ModemClient.bandInfo(): BandInfo = Bands.parse(get(NET_MODE), get("/api/net/net-mode-list"))

/** حالت «فقط 5G»: چند ترکیب option/باند رو امتحان می‌کنه تا مودم واقعاً NetworkMode=08 بشه. برمی‌گردونه option موفق یا null. */
fun ModemClient.set5gOnly(option: String): String? {
    val opts = if (option != "") listOf(option) else listOf("2", "1", "0")
    val bands = listOf("3FFFFFFF", "00000000")
    for (o in opts) {
        for (b in bands) {
            val r = post(NET_MODE, Bands.netModeBody("08", b, Bands.ALL_LTE, o))
            if (!Xml.isOk(r)) continue
            Thread.sleep(1500)
            val nm = get(NET_MODE)
            log("check: $nm")
            if (Xml.tag(nm, "NetworkMode") == "08") return o
        }
    }
    return null
}

fun ModemClient.setSimpleMode(mode: String): String =
    post(NET_MODE, Bands.netModeBody(mode, "3FFFFFFF", Bands.ALL_LTE, ""))

// ---------- اپراتور ----------
data class RegisterInfo(val manual: Boolean, val plmn: String, val rat: String)

fun ModemClient.registerInfo(): RegisterInfo {
    val r = get("/api/net/register")
    return RegisterInfo(Xml.tag(r, "Mode") == "1", Xml.tag(r, "Plmn"), Xml.tag(r, "Rat"))
}

fun ModemClient.setRegister(mode: Int, plmn: String, rat: String): String =
    post("/api/net/register", "<request><Mode>$mode</Mode><Plmn>$plmn</Plmn><Rat>$rat</Rat></request>")

data class FoundNetwork(val name: String, val plmn: String, val rat: String, val state: String)

/** جستجوی اپراتورهای اطراف (۱ تا ۳ دقیقه طول می‌کشه و اینترنت قطع می‌شه). */
fun ModemClient.scanPlmn(): Pair<List<FoundNetwork>, String> {
    val x = get("/api/net/plmn-list", 240000)
    val list = Xml.blocks(x, "Network").map {
        val num = Xml.tag(it, "Numeric")
        FoundNetwork(Xml.tag(it, "FullName").ifEmpty { Xml.tag(it, "ShortName") }.ifEmpty { num }, num, Xml.tag(it, "Rat"), Xml.tag(it, "State"))
    }
    return Pair(list, x)
}

// ---------- دستگاه‌ها ----------
data class Host(val name: String, val ip: String, val mac: String, val iface: String)

fun ModemClient.hosts(): Pair<List<Host>, String> {
    var x = get("/api/lan/HostInfo")
    if (!x.contains("<Host")) x = get("/api/wlan/host-list")
    val list = Xml.blocks(x, "Host").map {
        Host(Xml.tag(it, "HostName"), Xml.tag(it, "IpAddress"), Xml.tag(it, "MacAddress"), Xml.tag(it, "InterfaceType"))
    }
    return Pair(list, x)
}

fun ModemClient.reboot(): String = post("/api/device/control", "<request><Control>1</Control></request>")

fun ModemClient.explore(method: String, path: String, body: String): String =
    if (method == "GET") get(path) else post(path, body)

// ---------- جمع‌آوری اطلاعات برای قفل باند 5G ----------
private fun resolvePath(basePath: String, ref: String): String {
    val u = URI(basePath).resolve(ref)
    val q = u.rawQuery
    return u.rawPath + (if (q != null) "?$q" else "")
}

private fun snippet(tx: String, at: Int, before: Int, after: Int): String =
    tx.substring(maxOf(0, at - before), minOf(tx.length, at + after)).replace(Regex("\\s+"), " ")

/** صفحه‌ی content.html و اسکریپت‌هاش رو می‌گرده دنبال صفحه‌ی Developer options و APIهای قفل باند. */
fun ModemClient.collect5g(extra: String, add: (String) -> Unit) {
    try {
        val shell = get("/html/content.html")
        val texts = mutableListOf(shell)
        val srcs = Regex("src=\"([^\"]+\\.js[^\"]*)\"").findAll(shell).map { it.groupValues[1] }.take(14).toList()
        for (s in srcs) {
            try { texts.add(get(resolvePath("/html/content.html", s))) } catch (e: Exception) { }
        }
        add("scripts: " + srcs.size)
        val found = LinkedHashSet<String>()
        val ctx = mutableListOf<String>()
        val re = Regex("[\\w\\-/.#]*devel[\\w\\-/.#]*", RegexOption.IGNORE_CASE)
        for (tx in texts) {
            var n = 0
            for (m in re.findAll(tx)) {
                if (n >= 30) break
                found.add(m.value)
                if (ctx.size < 4) ctx.add(snippet(tx, m.range.first, 60, 120))
                n++
            }
        }
        add("== devel tokens ==\n" + found.joinToString("\n"))
        for (c in ctx) add("...$c")

        fun norm(f0: String): String {
            val f = f0.replace(Regex("^(\\.\\.?/)+"), "")
            return if (f.startsWith("/")) f else if (f.startsWith("html/")) "/$f" else "/html/$f"
        }
        val base = get("/html/zz_notfound.html").length
        val cand = LinkedHashSet<String>()
        if (extra.isNotBlank()) cand.add(norm(extra.trim()))
        for (f in found) if (Regex("\\.html", RegexOption.IGNORE_CASE).containsMatchIn(f)) cand.add(norm(f))
        for (n in listOf("developmode", "developer", "developeroptions", "developOptions", "developerOptions", "develop_options", "developer_options", "develop", "development", "developopt")) {
            cand.add("/html/$n.html")
        }
        val lines = mutableListOf<String>()
        val real = mutableListOf<Pair<String, String>>()
        for (p in cand) {
            val pg = try { get(p) } catch (e: Exception) { lines.add("$p ERR"); continue }
            lines.add(p + " len=" + pg.length + (if (pg.length == base) " (=default page)" else ""))
            if (pg.length > 300 && pg.length != base) real.add(Pair(p, pg))
        }
        add("== pages ==\n" + lines.joinToString("\n"))
        for ((path, page) in real) {
            val txs = mutableListOf(page)
            val ss = Regex("src=\"([^\"]+\\.js[^\"]*)\"").findAll(page).map { it.groupValues[1] }.take(6).toList()
            for (s in ss) {
                try { txs.add(get(resolvePath(path, s))) } catch (e: Exception) { }
            }
            val apis = LinkedHashSet<String>()
            for (tx in txs) for (m in Regex("/api/[\\w\\-/]+").findAll(tx)) apis.add(m.value)
            add("== $path APIs ==\n" + apis.joinToString(" "))
            val lockRe = Regex("band.?lock|lockband|nrband|lock_band", RegexOption.IGNORE_CASE)
            for (tx in txs) {
                var n = 0
                var from = 0
                while (n < 3) {
                    val m = lockRe.find(tx, from) ?: break
                    add("..." + snippet(tx, m.range.first, 100, 220))
                    from = m.range.first + 300
                    if (from >= tx.length) break
                    n++
                }
            }
        }
    } catch (e: Exception) {
        add("ERR $e")
    }
    add("== done ==")
}
