package com.farhad.modem.core

/** عملیات سطح‌بالا روی مودم (همه blocking هستن؛ روی نخ IO صدا بزن). */

const val NET_MODE = "/api/net/net-mode"

fun ModemClient.signal(now: Long = System.currentTimeMillis()): Snapshot? =
    parseSignal(get("/api/device/signal"), now)

data class Traffic(val downMbps: Double?, val upMbps: Double?)

fun ModemClient.traffic(): Traffic {
    val t = get("/api/monitoring/traffic-statistics")
    fun mbps(k: String): Double? = Xml.num(Xml.tag(t, k))?.let { it * 8.0 / 1e6 }
    return Traffic(mbps("CurrentDownloadRate"), mbps("CurrentUploadRate"))
}

private val NET_TYPES: Map<String, String> = mapOf(
    "0" to "No Service", "1" to "2G", "2" to "2G", "3" to "2G",
    "41" to "3G", "42" to "3G", "43" to "3G", "44" to "3G", "45" to "3G+", "46" to "3G+",
    "101" to "LTE 4G", "1011" to "LTE CA 4G+", "111" to "5G NR"
)

data class OperatorInfo(val name: String, val plmn: String, val netType: String, val endc: Boolean = false)

/** "5G NSA" when the modem reports an active EN-DC link (LTE anchor + NR), else the mapped type (111 = "5G NR"). */
fun netTypeText(code: String, endc: Boolean): String = when {
    endc -> "5G NSA"
    else -> NET_TYPES[code] ?: code
}

fun ModemClient.operatorInfo(): OperatorInfo {
    val pl = get("/api/net/current-plmn")
    val st = get("/api/monitoring/status")
    val code = Xml.tag(st, "CurrentNetworkTypeEx")
    val endc = Xml.tag(st, "EndcStatus") == "1"
    return OperatorInfo(Xml.tag(pl, "FullName").ifEmpty { "No Service" }, Xml.tag(pl, "Numeric"), netTypeText(code, endc), endc)
}

fun ModemClient.bandInfo(): BandInfo {
    val info = try { get("/api/net/lte-band-info") } catch (e: Exception) { "" }
    return Bands.parse(get(NET_MODE), get("/api/net/net-mode-list"), info)
}

/** حالت «فقط 5G»: چند ترکیب option/باند رو امتحان می‌کنه تا مودم واقعاً NetworkMode=08 بشه. برمی‌گردونه option موفق یا null. */
fun ModemClient.set5gOnly(option: String): String? {
    val opts = if (option != "") listOf(option) else listOf("2", "1", "0")
    val bands = listOf("3FFFFFFF", "00000000")
    for (o in opts) {
        for (b in bands) {
            val r = post(NET_MODE, Bands.netModeBody("08", b, Bands.ALL_LTE, o))
            if (!Xml.isOk(r)) continue
            Thread.sleep(1500)
            val nm = get(NET_MODE)
            log("check: $nm")
            if (Xml.tag(nm, "NetworkMode") == "08") return o
        }
    }
    return null
}

fun ModemClient.setSimpleMode(mode: String): String =
    post(NET_MODE, Bands.netModeBody(mode, "3FFFFFFF", Bands.ALL_LTE, ""))

// ---------- اپراتور ----------
data class RegisterInfo(val manual: Boolean, val plmn: String, val rat: String)

fun ModemClient.registerInfo(): RegisterInfo {
    val r = get("/api/net/register")
    return RegisterInfo(Xml.tag(r, "Mode") == "1", Xml.tag(r, "Plmn"), Xml.tag(r, "Rat"))
}

fun ModemClient.setRegister(mode: Int, plmn: String, rat: String): String =
    post("/api/net/register", "<request><Mode>$mode</Mode><Plmn>$plmn</Plmn><Rat>$rat</Rat></request>")

data class FoundNetwork(val name: String, val plmn: String, val rat: String, val state: String)

/** جستجوی اپراتورهای اطراف (۱ تا ۳ دقیقه طول می‌کشه و اینترنت قطع می‌شه). */
fun ModemClient.scanPlmn(): Pair<List<FoundNetwork>, String> {
    val x = get("/api/net/plmn-list", 240000)
    val list = Xml.blocks(x, "Network").map {
        val num = Xml.tag(it, "Numeric")
        FoundNetwork(Xml.tag(it, "FullName").ifEmpty { Xml.tag(it, "ShortName") }.ifEmpty { num }, num, Xml.tag(it, "Rat"), Xml.tag(it, "State"))
    }
    return Pair(list, x)
}

// ---------- دستگاه‌ها ----------
data class Host(val name: String, val ip: String, val mac: String, val iface: String)

fun ModemClient.hosts(): Pair<List<Host>, String> {
    var x = get("/api/lan/HostInfo")
    if (!x.contains("<Host")) x = get("/api/wlan/host-list")
    val list = Xml.blocks(x, "Host").map {
        Host(Xml.tag(it, "HostName"), Xml.tag(it, "IpAddress"), Xml.tag(it, "MacAddress"), Xml.tag(it, "InterfaceType"))
    }
    return Pair(list, x)
}
