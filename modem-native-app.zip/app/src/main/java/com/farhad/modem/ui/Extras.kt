package com.farhad.modem.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farhad.modem.Store
import com.farhad.modem.core.Sms
import com.farhad.modem.core.Speed
import com.farhad.modem.core.Usage
import com.farhad.modem.core.WifiNet
import com.farhad.modem.core.dhcp
import com.farhad.modem.core.formatBytes
import com.farhad.modem.core.reboot
import com.farhad.modem.core.renameWifi
import com.farhad.modem.core.setDns
import com.farhad.modem.core.smsDelete
import com.farhad.modem.core.smsList
import com.farhad.modem.core.usage
import com.farhad.modem.core.validIpv4
import com.farhad.modem.core.validSsid
import com.farhad.modem.core.wifiNetworks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(C.panel).padding(12.dp)) { content() }
}

// ---------------- Data usage ----------------
@Composable
fun UsageScreen() {
    val scope = rememberCoroutineScope()
    var u by remember { mutableStateOf<Usage?>(null) }
    var limit by remember { mutableStateOf(Store.pref("limitGb")) }
    var err by remember { mutableStateOf("") }
    fun load() {
        scope.launch(Dispatchers.IO) {
            try { u = Store.client.usage(); err = "" } catch (e: Exception) { err = "Could not reach the modem" }
        }
    }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Btn("Refresh", Modifier.fillMaxWidth()) { load() }
        if (err.isNotEmpty()) Sec(err)
        u?.let { x ->
            Sec("This month")
            Card {
                Text("Download  " + formatBytes(x.monthDown), color = C.text, fontSize = 16.sp)
                Text("Upload  " + formatBytes(x.monthUp), color = C.text, fontSize = 16.sp)
                Text("Total  " + formatBytes(x.monthDown + x.monthUp), color = C.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (!x.monthKnown) Text("This modem does not report monthly numbers.", color = C.mute, fontSize = 12.sp)
            }
            Sec("Since last reset")
            Card {
                Text("Download  " + formatBytes(x.totalDown), color = C.text, fontSize = 15.sp)
                Text("Upload  " + formatBytes(x.totalUp), color = C.text, fontSize = 15.sp)
            }
        }
        Sec("Alert")
        Text("Notification at 80% and 100% of this monthly limit (while the app monitor is running). Empty = off.", color = C.mute, fontSize = 12.sp)
        OutlinedTextField(limit, { limit = it }, label = { Text("Monthly limit (GB)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        Gap(6)
        Btn("Save limit", Modifier.fillMaxWidth(), kind = 1) {
            val v = limit.trim()
            if (v.isNotEmpty() && v.toDoubleOrNull() == null) Store.toast("Enter a number") else {
                Store.putPref("limitGb", v); Store.putPref("alertLevel", ""); Store.toast("Saved")
            }
        }
    }
}

// ---------------- Speed test ----------------
private fun mbpsText(v: Double?): String = if (v == null) "failed" else String.format(java.util.Locale.US, "%.1f Mbps", v)

@Composable
fun SpeedScreen() {
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var phase by remember { mutableStateOf("Tap Start. About 25 seconds, uses roughly 100-300 MB.") }
    var live by remember { mutableStateOf("") }
    var ping by remember { mutableStateOf("-") }
    var jitter by remember { mutableStateOf("-") }
    var down by remember { mutableStateOf("-") }
    var up by remember { mutableStateOf("-") }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Card {
            Text("Ping  $ping     Jitter  $jitter", color = C.text, fontSize = 17.sp)
            Gap(4)
            Text("Download  $down", color = C.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Upload  $up", color = C.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Gap(4)
        if (live.isNotEmpty()) Text("Live: $live", color = C.blue, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(phase, color = C.mute, fontSize = 13.sp)
        Gap(6)
        Btn(if (running) "Running..." else "Start", Modifier.fillMaxWidth(), kind = 1) {
            if (!running) {
                running = true; ping = "-"; jitter = "-"; down = "-"; up = "-"; live = ""
                scope.launch(Dispatchers.IO) {
                    phase = "Ping..."
                    val p = Speed.ping()
                    ping = p?.let { String.format(java.util.Locale.US, "%.0f ms", it.ms) } ?: "failed"
                    jitter = p?.let { String.format(java.util.Locale.US, "%.1f ms", it.jitter) } ?: "-"
                    phase = "Download (6 connections)..."
                    val d = Speed.download { live = String.format(java.util.Locale.US, "%.1f Mbps", it) }
                    down = mbpsText(d); live = ""
                    phase = "Upload (4 connections)..."
                    val u = Speed.upload { live = String.format(java.util.Locale.US, "%.1f Mbps", it) }
                    up = mbpsText(u); live = ""
                    phase = if (d == null && u == null) "No test server reachable (does the modem have internet?)"
                    else "Done. Result = sustained speed after the first 2 seconds (like speed-test sites)."
                    running = false
                }
            }
        }
        Text(
            "Tip: close other downloads on your devices while testing. The server (Cloudflare) can be a bit different from Ookla's, so numbers may differ by 10-20%.",
            color = C.mute, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

// ---------------- Wi-Fi name, DNS, reboot ----------------
@Composable
fun SettingsScreen() {
    val scope = rememberCoroutineScope()
    var nets by remember { mutableStateOf<List<WifiNet>>(emptyList()) }
    var wifiMsg by remember { mutableStateOf("") }
    var names by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var dns1 by remember { mutableStateOf("") }
    var dns2 by remember { mutableStateOf("") }
    var dnsMsg by remember { mutableStateOf("") }
    var confirmReboot by remember { mutableStateOf(false) }

    fun load() {
        scope.launch(Dispatchers.IO) {
            try {
                val w = Store.client.wifiNetworks()
                nets = w.first
                names = w.first.associate { it.index to it.ssid }
                wifiMsg = if (w.first.isEmpty()) "This modem did not return Wi-Fi settings" else ""
            } catch (e: Exception) { wifiMsg = "Could not reach the modem" }
            try {
                val d = Store.client.dhcp()
                dns1 = d.primary; dns2 = d.secondary
                dnsMsg = if (d.raw.contains("PrimaryDns")) "" else "This modem did not report DNS fields"
            } catch (e: Exception) { dnsMsg = "Could not reach the modem" }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Sec("Wi-Fi name")
        if (wifiMsg.isNotEmpty()) Tag(wifiMsg)
        nets.forEach { n ->
            OutlinedTextField(
                names[n.index] ?: n.ssid, { names = names + (n.index to it) },
                label = { Text("Wi-Fi " + n.index + (if (n.enabled) "" else " (off)")) },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            Btn("Rename", Modifier.fillMaxWidth().padding(top = 4.dp), kind = 1) {
                val nn = (names[n.index] ?: "").trim()
                if (!validSsid(nn)) Store.toast("Name: 1~32 characters") else scope.launch(Dispatchers.IO) {
                    val r = Store.client.renameWifi(n.index, nn)
                    Store.toast(if (r.isEmpty()) "Renamed. The Wi-Fi restarts — reconnect with the new name." else "Failed: $r")
                }
            }
        }
        Text("The Wi-Fi password is not changed from this app.", color = C.mute, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))

        Sec("DNS")
        if (dnsMsg.isNotEmpty()) Tag(dnsMsg)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(dns1, { dns1 = it }, label = { Text("Primary") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(dns2, { dns2 = it }, label = { Text("Secondary") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Google", Modifier.weight(1f)) { dns1 = "8.8.8.8"; dns2 = "8.8.4.4" }
            Btn("Cloudflare", Modifier.weight(1f)) { dns1 = "1.1.1.1"; dns2 = "1.0.0.1" }
            Btn("Shecan", Modifier.weight(1f)) { dns1 = "178.22.122.100"; dns2 = "185.51.200.2" }
        }
        Gap(6)
        Btn("Save DNS", Modifier.fillMaxWidth(), kind = 1) {
            val a = dns1.trim(); val b = dns2.trim()
            if (!validIpv4(a) || (b.isNotEmpty() && !validIpv4(b))) Store.toast("Enter valid IPv4 addresses") else scope.launch(Dispatchers.IO) {
                val r = Store.client.setDns(a, b)
                Store.toast(if (r.isEmpty()) "DNS saved" else "Failed: $r")
            }
        }
        Text("This sets the DNS the modem gives to connected devices. If it fails, the modem may use manual DNS in another page.", color = C.mute, fontSize = 12.sp)

        Sec("Modem")
        if (!confirmReboot) {
            Btn("Reboot modem", Modifier.fillMaxWidth(), kind = 3) { confirmReboot = true }
        } else {
            Text("Reboot now? The internet is down for about 2 minutes.", color = C.red, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("Cancel", Modifier.weight(1f)) { confirmReboot = false }
                Btn("Yes, reboot", Modifier.weight(1f), kind = 3) {
                    confirmReboot = false
                    scope.launch(Dispatchers.IO) {
                        val r = Store.client.reboot()
                        Store.toast(if (com.farhad.modem.core.Xml.isOk(r)) "Rebooting..." else "Failed: " + r.take(60))
                    }
                }
            }
        }
        Gap(12)
    }
}

// ---------------- SMS ----------------
@Composable
fun SmsScreen() {
    val scope = rememberCoroutineScope()
    var box by remember { mutableStateOf(1) }
    var list by remember { mutableStateOf<List<Sms>>(emptyList()) }
    var raw by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    fun load() {
        loading = true
        scope.launch(Dispatchers.IO) {
            try { val r = Store.client.smsList(box); list = r.first; raw = r.second } catch (e: Exception) { raw = "Could not reach the modem" }
            loading = false
        }
    }
    LaunchedEffect(box) { load() }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Inbox", Modifier.weight(1f), kind = if (box == 1) 1 else 0) { box = 1 }
            Btn("Sent", Modifier.weight(1f), kind = if (box == 2) 1 else 0) { box = 2 }
            Btn("Refresh", Modifier.weight(1f)) { load() }
        }
        if (loading) Sec("Loading...")
        list.forEach { s ->
            Card {
                Text(s.phone + (if (s.unread) "  • new" else ""), color = C.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(s.date, color = C.mute, fontSize = 12.sp)
                Gap(2)
                Text(s.content, color = C.text, fontSize = 14.sp)
                Gap(4)
                Btn("Delete", Modifier.width(100.dp), kind = 3) {
                    scope.launch(Dispatchers.IO) {
                        val r = Store.client.smsDelete(s.index)
                        Store.toast(if (com.farhad.modem.core.Xml.isOk(r)) "Deleted" else "Failed: " + r.take(60))
                        load()
                    }
                }
            }
        }
        if (!loading && list.isEmpty()) {
            Tag("No messages")
            Text("If you expect messages, the modem may not support SMS here. Reply from the modem:", color = C.mute, fontSize = 12.sp)
            Mono(raw.take(600))
        }
    }
}
