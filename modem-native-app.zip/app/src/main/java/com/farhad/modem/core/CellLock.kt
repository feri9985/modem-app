package com.farhad.modem.core

import java.math.BigInteger

/** A saved 4G cell (rat is always 4). */
data class CellEntry(val rat: Int, val pci: Int, val earfcn: Int, val rsrp: Double?) {
    val key: String get() = "$rat:$pci:$earfcn"
}

object CellLock {
    const val EARFCN_MIN = 1
    const val EARFCN_MAX = 16777215
    const val PCI_MIN = 1
    const val PCI_MAX = 512


    fun parseIntOrNull(s: String): Int? = s.trim().toIntOrNull()
    fun validPci(v: Int?): Boolean = v != null && v >= PCI_MIN && v <= PCI_MAX
    fun validEarfcn(v: Int?): Boolean = v != null && v >= EARFCN_MIN && v <= EARFCN_MAX

    /** The 4G cell the modem is on now (from /api/device/signal), if the modem reports EARFCN and PCI. */
    fun serving4(s: Snapshot): CellEntry? {
        val p = s.pci
        val e = s.earfcn
        return if (p != null && e != null) CellEntry(4, p, e, s.rsrp) else null
    }
}

object CellCodec {
    fun encode(l: List<CellEntry>): String =
        l.joinToString("\n") { it.rat.toString() + "," + it.pci + "," + it.earfcn + "," + (it.rsrp?.toString() ?: "") }

    fun decode(s: String): List<CellEntry> {
        val out = mutableListOf<CellEntry>()
        for (line in s.split("\n")) {
            val p = line.split(",")
            if (p.size < 4) continue
            val rat = p[0].toIntOrNull() ?: continue
            val pci = p[1].toIntOrNull() ?: continue
            val e = p[2].toIntOrNull() ?: continue
            out.add(CellEntry(rat, pci, e, p[3].toDoubleOrNull()))
        }
        return out
    }
}

// ---------- Band selection (captured from the modem page: /api/net/lock-freq and /api/net/lte-band-info) ----------
/** enable: 0 = no lock, 1 = frequency lock, 2 = cell (PCI) lock, 3 = band lock. cellId carries the PCI for a cell lock. */
data class LockFreq(val mode: Int, val enable: Int, val band: Int, val freq: Int, val cellId: Int) {
    fun describe(): String = when (enable) {
        0 -> "No lock"
        1 -> "Frequency lock: B$band, EARFCN $freq"
        3 -> "Band lock: B$band"
        else -> "Cell lock: B$band, EARFCN $freq, PCI $cellId"
    }
}

object FreqPlan {
    /** EARFCN ranges per LTE band (fallback when the modem's bandfreqlist.xml cannot be read). */
    val FALLBACK: Map<Int, IntRange> = mapOf(
        1 to 0..599, 3 to 1200..1949, 7 to 2750..3449, 8 to 3450..3799, 20 to 6150..6449,
        28 to 9210..9659, 38 to 37750..38249, 40 to 38650..39649, 41 to 39650..41589, 42 to 41590..43589
    )

    /** Parses <lte_mode><band><value>1</value><freq>0-599</freq>... from /config/network/bandfreqlist.xml */
    fun parseRanges(xml: String): Map<Int, IntRange> {
        val lte = xml.substringBefore("</lte_mode>", xml)
        val out = LinkedHashMap<Int, IntRange>()
        for (m in Regex("<value>(\\d+)</value>\\s*<freq>(\\d+)-(\\d+)</freq>").findAll(lte)) {
            out[m.groupValues[1].toInt()] = m.groupValues[2].toInt()..m.groupValues[3].toInt()
        }
        return out
    }

    fun bandFor(earfcn: Int, ranges: Map<Int, IntRange>): Int? = ranges.entries.firstOrNull { earfcn in it.value }?.key
}

fun ModemClient.lockFreqState(): LockFreq? {
    val x = get("/api/net/lock-freq")
    if (!x.contains("<Enable>")) return null
    return LockFreq(
        Xml.tag(x, "Mode").toIntOrNull() ?: 0, Xml.tag(x, "Enable").toIntOrNull() ?: 0,
        Xml.tag(x, "Band").toIntOrNull() ?: 0, Xml.tag(x, "Freq").toIntOrNull() ?: 0, Xml.tag(x, "CellId").toIntOrNull() ?: 0
    )
}

fun ModemClient.freqRanges(): Map<Int, IntRange> {
    val r = try { FreqPlan.parseRanges(get("/config/network/bandfreqlist.xml")) } catch (e: Exception) { emptyMap() }
    return if (r.isEmpty()) FreqPlan.FALLBACK else r
}

/** Same body the modem page sends for Frequency-lock (Enable 1) or No lock (Enable 0). */
fun ModemClient.setLockFreq(enable: Boolean, band: Int, freq: Int): String =
    post("/api/net/lock-freq", "<request><Mode>0</Mode><Enable>" + (if (enable) 1 else 0) + "</Enable><Freq>" + freq + "</Freq><Band>" + band + "</Band><CellId>0</CellId></request>")

/** Same body the modem page sends for Band-lock: Enable 3 with the band (then lte-band-info gets that band's mask). */
fun ModemClient.setLockBand(band: Int): String =
    post("/api/net/lock-freq", "<request><Mode>0</Mode><Enable>3</Enable><Freq>0</Freq><Band>" + band + "</Band><CellId>0</CellId></request>")

/** Same body the modem page sends for Cell lock: Enable 2, CellId = PCI. */
fun ModemClient.setLockCell(band: Int, freq: Int, pci: Int): String =
    post("/api/net/lock-freq", "<request><Mode>0</Mode><Enable>2</Enable><Freq>" + freq + "</Freq><Band>" + band + "</Band><CellId>" + pci + "</CellId></request>")

/** LTE band lock. An empty mask means all bands (the modem trims it to the supported ones). */
fun ModemClient.setLteBands(mask: BigInteger): String =
    post("/api/net/lte-band-info", "<request><current_lte_band>" + (if (mask.signum() == 0) Bands.ALL_LTE else Bands.hex(mask)) + "</current_lte_band></request>")
