package com.farhad.modem.core

import java.net.URI

/** یه سلول (4G یا 5G) برای لیست قفل سلول. rat = 4 یا 5. */
data class CellEntry(val rat: Int, val pci: Int, val earfcn: Int, val rsrp: Double?) {
    val key: String get() = "$rat:$pci:$earfcn"
}

object CellLock {
    const val EARFCN_MIN = 1
    const val EARFCN_MAX = 16777215
    const val PCI_MIN = 1
    const val PCI_MAX = 512

    /** هنوز API قفل سلول این مودم مشخص نشده (باید با دکمه‌ی Detect پیدا بشه). */
    const val API_MAPPED = false
    const val NOT_MAPPED_MSG = "This modem's cell-lock API is not mapped yet. Use the Dev options tab (modem Band selection page) to lock cells for now."

    fun parseIntOrNull(s: String): Int? = s.trim().toIntOrNull()
    fun validPci(v: Int?): Boolean = v != null && v >= PCI_MIN && v <= PCI_MAX
    fun validEarfcn(v: Int?): Boolean = v != null && v >= EARFCN_MIN && v <= EARFCN_MAX

    /** سلولی که الان بهش وصلی (از /api/device/signal) */
    fun serving(s: Snapshot, rat: Int): CellEntry? =
        if (rat == 4) {
            val p = s.pci
            val e = s.earfcn
            if (p != null && e != null) CellEntry(4, p, e, s.rsrp) else null
        } else {
            val p = s.nrPci
            val e = s.nrArfcn
            if (p != null && e != null) CellEntry(5, p, e, s.nrRsrp) else null
        }
}

object CellCodec {
    fun encode(l: List<CellEntry>): String =
        l.joinToString("\n") { it.rat.toString() + "," + it.pci + "," + it.earfcn + "," + (it.rsrp?.toString() ?: "") }

    fun decode(s: String): List<CellEntry> {
        val out = mutableListOf<CellEntry>()
        for (line in s.split("\n")) {
            val p = line.split(",")
            if (p.size < 4) continue
            val rat = p[0].toIntOrNull() ?: continue
            val pci = p[1].toIntOrNull() ?: continue
            val e = p[2].toIntOrNull() ?: continue
            out.add(CellEntry(rat, pci, e, p[3].toDoubleOrNull()))
        }
        return out
    }
}

// ---------- پیدا کردن API قفل سلول از خود صفحه‌ی وب مودم (فقط GET، هیچ تنظیمی عوض نمی‌شه) ----------
private fun resolvePath(basePath: String, ref: String): String {
    val u = URI(basePath).resolve(ref)
    val q = u.rawQuery
    return u.rawPath + (if (q != null) "?$q" else "")
}

private fun snippet(tx: String, at: Int, before: Int, after: Int): String =
    tx.substring(maxOf(0, at - before), minOf(tx.length, at + after)).replace(Regex("\\s+"), " ")

/**
 * Read-only (GET only) search of the modem web UI for the Developer options > Band selection
 * (band lock / frequency lock / cell lock) APIs. Loads every referenced script, then lists all API paths.
 */
fun ModemClient.detectCellLock(add: (String) -> Unit) {
    try {
        val texts = LinkedHashMap<String, String>()
        val tried = HashSet<String>()
        val shellLen = try { get("/html/zz_notfound.html").length } catch (e: Exception) { -1 }
        fun load(path: String) {
            if (!tried.add(path)) return
            try {
                val t = get(path)
                if (t.length > 200 && t.length != shellLen && !t.startsWith("<?xml")) texts[path] = t
            } catch (e: Exception) { }
        }
        load("/html/content.html")
        for (m in Regex("src=\"([^\"]+\\.js[^\"]*)\"").findAll(texts["/html/content.html"] ?: "").toList()) {
            try { load(resolvePath("/html/content.html", m.groupValues[1])) } catch (e: Exception) { }
        }
        val names = LinkedHashSet<String>()
        for ((k, t) in texts.toList()) {
            if (!k.contains("menu.js")) continue
            for (m in Regex(":\\s*'([a-z0-9_]{3,30})'").findAll(t)) names.add(m.groupValues[1])
        }
        for (n in listOf("developmode", "bandselection", "band_selection", "bandlock", "networksettings", "mobileconnection", "systemsettings", "diagnosereport", "diagnosticreport", "network")) names.add(n)
        for (n in names.take(100)) load("/js/$n.js")
        // every .js file mentioned inside the loaded files (two rounds)
        for (round in 0..1) {
            val refs = LinkedHashSet<String>()
            for ((_, t) in texts.toList()) for (m in Regex("[\\w\\-./]+\\.js").findAll(t)) refs.add(m.value)
            for (r in refs.take(150)) {
                val name = r.substringAfterLast('/')
                if (name.contains("jquery")) continue
                load("/js/$name")
            }
        }
        // brute-force the hidden Developer options pages (read-only GETs; the modem answers with the login page when a name does not exist)
        val pre = listOf("develop", "developer", "dev", "developmode", "developoption", "developeroption", "bandselection", "bandselect", "band_selection", "bandlock", "lockfreq", "freqlock", "celllock", "cellselect", "netlock", "band")
        val suf = listOf("", "s", "mode", "_mode", "option", "options", "_options", "setting", "settings", "new", "2", "index", "main")
        val found = mutableListOf<String>()
        for (a in pre) for (b in suf) {
            val n = a + b
            for (path in listOf("/html/$n.html", "/js/$n.js", "/html/$n/index.html")) {
                if (tried.contains(path)) continue
                load(path)
                if (texts.containsKey(path)) found.add(path)
            }
        }
        add("hidden pages found: " + (if (found.isEmpty()) "none" else found.joinToString(" ")))
        for (f in found.filter { it.endsWith(".html") }) {
            val t = texts[f] ?: continue
            add("PAGE " + f + " (" + t.length + "): " + t.replace(Regex("\\s+"), " ").take(1500))
            for (m in Regex("src=\"([^\"]+\\.js[^\"]*)\"").findAll(t).toList()) {
                try { load(resolvePath(f, m.groupValues[1])) } catch (e: Exception) { }
            }
        }
        for (f in found.filter { it.endsWith(".js") }) {
            add("JS " + f + " (" + (texts[f]?.length ?: 0) + "): " + (texts[f] ?: "").replace(Regex("\\s+"), " ").take(2500))
        }
        try { add("net-feature-switch: " + get("/api/net/net-feature-switch").replace(Regex("\\s+"), " ").take(900)) } catch (e: Exception) { }
        add("loaded " + texts.size + " files: " + texts.keys.joinToString(" ") { it.substringBefore('?').substringAfterLast('/') })

        val apis = LinkedHashSet<String>()
        for ((k, t) in texts) {
            if (k.contains("jquery")) continue
            for (m in Regex("api/[\\w\\-/]+").findAll(t)) apis.add(m.value)
        }
        add("== ALL api paths (" + apis.size + ") ==\n" + apis.joinToString(" "))

        var shown = 0
        for ((k, t) in texts) {
            if (k.contains("jquery")) continue
            for (m in Regex("freq|pci|earfcn|arfcn|lock.?type|lockmode|bandsel", RegexOption.IGNORE_CASE).findAll(t)) {
                if (shown >= 10) break
                add("[" + k.substringBefore('?').substringAfterLast('/') + "] ..." + snippet(t, m.range.first, 200, 500))
                shown++
                break
            }
        }

        val probe = mutableListOf<String>()
        val want = Regex("api/(net|ntwk|device|monitoring)/|lock|band|freq|cell|pci", RegexOption.IGNORE_CASE)
        for (p in apis.filter { want.containsMatchIn(it) }.take(40)) {
            val path = if (p.startsWith("/")) p else "/$p"
            val r = try { get(path) } catch (e: Exception) { "ERR $e" }
            probe.add(path + " -> " + r.replace(Regex("\\s+"), " ").take(300))
        }
        add("== GET probes ==\n" + probe.joinToString("\n"))
    } catch (e: Exception) {
        add("ERR $e")
    }
    add("== done ==")
}
