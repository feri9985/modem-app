package com.farhad.modem.core

import java.net.URI

/** یه سلول (4G یا 5G) برای لیست قفل سلول. rat = 4 یا 5. */
data class CellEntry(val rat: Int, val pci: Int, val earfcn: Int, val rsrp: Double?) {
    val key: String get() = "$rat:$pci:$earfcn"
}

object CellLock {
    const val EARFCN_MIN = 1
    const val EARFCN_MAX = 16777215
    const val PCI_MIN = 1
    const val PCI_MAX = 512

    /** هنوز API قفل سلول این مودم مشخص نشده (باید با دکمه‌ی Detect پیدا بشه). */
    const val API_MAPPED = false
    const val NOT_MAPPED_MSG = "This modem's cell-lock API is not mapped yet. Tap \"Detect cell-lock API\" and send the result to the developer."

    fun parseIntOrNull(s: String): Int? = s.trim().toIntOrNull()
    fun validPci(v: Int?): Boolean = v != null && v >= PCI_MIN && v <= PCI_MAX
    fun validEarfcn(v: Int?): Boolean = v != null && v >= EARFCN_MIN && v <= EARFCN_MAX

    /** سلولی که الان بهش وصلی (از /api/device/signal) */
    fun serving(s: Snapshot, rat: Int): CellEntry? =
        if (rat == 4) {
            val p = s.pci
            val e = s.earfcn
            if (p != null && e != null) CellEntry(4, p, e, s.rsrp) else null
        } else {
            val p = s.nrPci
            val e = s.nrArfcn
            if (p != null && e != null) CellEntry(5, p, e, s.nrRsrp) else null
        }
}

object CellCodec {
    fun encode(l: List<CellEntry>): String =
        l.joinToString("\n") { it.rat.toString() + "," + it.pci + "," + it.earfcn + "," + (it.rsrp?.toString() ?: "") }

    fun decode(s: String): List<CellEntry> {
        val out = mutableListOf<CellEntry>()
        for (line in s.split("\n")) {
            val p = line.split(",")
            if (p.size < 4) continue
            val rat = p[0].toIntOrNull() ?: continue
            val pci = p[1].toIntOrNull() ?: continue
            val e = p[2].toIntOrNull() ?: continue
            out.add(CellEntry(rat, pci, e, p[3].toDoubleOrNull()))
        }
        return out
    }
}

// ---------- پیدا کردن API قفل سلول از خود صفحه‌ی وب مودم (فقط GET، هیچ تنظیمی عوض نمی‌شه) ----------
private fun resolvePath(basePath: String, ref: String): String {
    val u = URI(basePath).resolve(ref)
    val q = u.rawQuery
    return u.rawPath + (if (q != null) "?$q" else "")
}

private fun snippet(tx: String, at: Int, before: Int, after: Int): String =
    tx.substring(maxOf(0, at - before), minOf(tx.length, at + after)).replace(Regex("\\s+"), " ")

/**
 * Read-only (GET only) search of the modem web UI for the frequency lock / PCI lock / band lock APIs.
 * Loads the menu page names, then every page script, and lists API paths + code around pci/earfcn/lock words.
 */
fun ModemClient.detectCellLock(add: (String) -> Unit) {
    try {
        val texts = LinkedHashMap<String, String>()
        fun load(path: String) {
            if (texts.containsKey(path)) return
            try {
                val t = get(path)
                if (t.length > 200) texts[path] = t
            } catch (e: Exception) { }
        }
        load("/html/content.html")
        val first = texts["/html/content.html"] ?: ""
        for (m in Regex("src=\"([^\"]+\\.js[^\"]*)\"").findAll(first)) {
            try { load(resolvePath("/html/content.html", m.groupValues[1])) } catch (e: Exception) { }
        }
        // page names listed in menu.js ('xxx_enabled': 'pagename')
        val names = LinkedHashSet<String>()
        for ((k, t) in texts.toList()) {
            if (!k.contains("menu.js")) continue
            for (m in Regex(":\\s*'([a-z0-9_]{3,30})'").findAll(t)) names.add(m.groupValues[1])
        }
        for (n in listOf("networksettings", "mobileconnection", "netmode", "lteband", "freqlock", "pcilock", "cellselect", "developmode", "network", "dialup", "mobilenetworksettings", "networkmode", "plmn", "celllock", "bandselection", "band_selection", "bandlock", "lockband", "developeroptions", "developoptions", "devmode", "diagnosereport", "diagnosticreport", "systemsettings")) names.add(n)
        add("page names: " + names.size)
        for (n in names.take(90)) {
            load("/js/$n.js")
            load("/html/$n.html")
        }
        add("loaded " + texts.size + " files")

        val words = Regex("pci|earfcn|arfcn|freqlock|lockfreq|frequency|lockband|bandlock|celllock|cell_lock", RegexOption.IGNORE_CASE)
        val apis = LinkedHashSet<String>()
        for ((k, t) in texts) {
            val hit = words.containsMatchIn(t) && !k.contains("jquery")
            if (!hit) continue
            val found = Regex("api/[\\w\\-/]+").findAll(t).map { it.value }.toSet()
            add("FILE " + k.substringBefore('?') + " apis: " + found.joinToString(" "))
            apis.addAll(found)
        }
        var shown = 0
        for ((k, t) in texts) {
            if (k.contains("jquery") || k.contains("menu.js") || k.contains("redirect.js") || k.contains("public.js")) continue
            for (m in Regex("pci|earfcn|arfcn|lockfreq|freqlock", RegexOption.IGNORE_CASE).findAll(t)) {
                if (shown >= 14) break
                add("[" + k.substringBefore('?').substringAfterLast('/') + "] ..." + snippet(t, m.range.first, 200, 500))
                shown++
                break
            }
        }
        // developer options / band selection: show where they are mentioned and dump their code
        var dshown = 0
        for ((k, t) in texts) {
            if (k.contains("jquery")) continue
            if (k.contains("develop") || k.contains("bandsel") || k.contains("band_sel")) {
                add("FILE " + k.substringBefore('?') + " (" + t.length + ")\n" + t.replace(Regex("\\s+"), " ").take(3500))
            }
            for (m in Regex("developmode|bandselection|band_selection|frequency.?lock|lockfreq", RegexOption.IGNORE_CASE).findAll(t)) {
                if (dshown >= 10) break
                add("MENTION [" + k.substringBefore('?').substringAfterLast('/') + "] ..." + snippet(t, m.range.first, 200, 400))
                dshown++
                break
            }
        }
        val probe = mutableListOf<String>()
        for (p in apis.take(30) + listOf("api/net/net-mode", "api/net/net-mode-list", "api/ntwk/celllock", "api/device/signal", "api/net/band-lock", "api/net/bandselection", "api/net/frequency-lock", "api/ntwk/bandselection", "api/ntwk/band-lock", "api/ntwk/lockfreq", "api/ntwk/lockpci", "api/net/lockfreq", "api/net/lockpci")) {
            val path = if (p.startsWith("/")) p else "/$p"
            val r = try { get(path) } catch (e: Exception) { "ERR $e" }
            probe.add(path + " -> " + r.replace(Regex("\\s+"), " ").take(350))
        }
        add("== GET probes ==\n" + probe.joinToString("\n"))
    } catch (e: Exception) {
        add("ERR $e")
    }
    add("== done ==")
}
