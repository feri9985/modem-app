package com.farhad.modem.core

import java.net.URI

/** یه سلول (4G یا 5G) برای لیست قفل سلول. rat = 4 یا 5. */
data class CellEntry(val rat: Int, val pci: Int, val earfcn: Int, val rsrp: Double?) {
    val key: String get() = "$rat:$pci:$earfcn"
}

object CellLock {
    const val EARFCN_MIN = 1
    const val EARFCN_MAX = 16777215
    const val PCI_MIN = 1
    const val PCI_MAX = 512

    /** هنوز API قفل سلول این مودم مشخص نشده (باید با دکمه‌ی Detect پیدا بشه). */
    const val API_MAPPED = false
    const val NOT_MAPPED_MSG = "This modem's cell-lock API is not mapped yet. Tap \"Detect cell-lock API\" and send the result to the developer."

    fun parseIntOrNull(s: String): Int? = s.trim().toIntOrNull()
    fun validPci(v: Int?): Boolean = v != null && v >= PCI_MIN && v <= PCI_MAX
    fun validEarfcn(v: Int?): Boolean = v != null && v >= EARFCN_MIN && v <= EARFCN_MAX

    /** سلولی که الان بهش وصلی (از /api/device/signal) */
    fun serving(s: Snapshot, rat: Int): CellEntry? =
        if (rat == 4) {
            val p = s.pci
            val e = s.earfcn
            if (p != null && e != null) CellEntry(4, p, e, s.rsrp) else null
        } else {
            val p = s.nrPci
            val e = s.nrArfcn
            if (p != null && e != null) CellEntry(5, p, e, s.nrRsrp) else null
        }
}

object CellCodec {
    fun encode(l: List<CellEntry>): String =
        l.joinToString("\n") { it.rat.toString() + "," + it.pci + "," + it.earfcn + "," + (it.rsrp?.toString() ?: "") }

    fun decode(s: String): List<CellEntry> {
        val out = mutableListOf<CellEntry>()
        for (line in s.split("\n")) {
            val p = line.split(",")
            if (p.size < 4) continue
            val rat = p[0].toIntOrNull() ?: continue
            val pci = p[1].toIntOrNull() ?: continue
            val e = p[2].toIntOrNull() ?: continue
            out.add(CellEntry(rat, pci, e, p[3].toDoubleOrNull()))
        }
        return out
    }
}

// ---------- پیدا کردن API قفل سلول از خود صفحه‌ی وب مودم (فقط GET، هیچ تنظیمی عوض نمی‌شه) ----------
private fun resolvePath(basePath: String, ref: String): String {
    val u = URI(basePath).resolve(ref)
    val q = u.rawQuery
    return u.rawPath + (if (q != null) "?$q" else "")
}

private fun snippet(tx: String, at: Int, before: Int, after: Int): String =
    tx.substring(maxOf(0, at - before), minOf(tx.length, at + after)).replace(Regex("\\s+"), " ")

private val CANDIDATE_APIS = listOf(
    "/api/global/module-switch",
    "/api/ntwk/celllock", "/api/net/celllock", "/api/net/cell-lock", "/api/net/cell_lock", "/api/net/lock-cell",
    "/api/ntwk/cell-lock", "/api/ntwk/lockcell", "/api/net/neighbor-cell", "/api/net/neighbour-cell",
    "/api/net/net-mode", "/api/net/net-mode-list"
)

/**
 * صفحه‌ها و اسکریپت‌های مودم رو می‌گرده و آدرس‌های API مربوط به cell lock / PCI / EARFCN رو پیدا می‌کنه.
 * خروجی متنیه که کاربر برای من می‌فرسته. فقط درخواست GET می‌زنه.
 */
fun ModemClient.detectCellLock(add: (String) -> Unit) {
    try {
        val interesting = Regex("cell|lock|pci|earfcn|neighbo|scan", RegexOption.IGNORE_CASE)
        val seenPages = LinkedHashSet<String>()
        val texts = mutableListOf<Pair<String, String>>()   // (منبع، متن)

        fun loadWithScripts(path: String, maxScripts: Int) {
            if (!seenPages.add(path)) return
            val page = try { get(path) } catch (e: Exception) { add("$path ERR $e"); return }
            texts.add(Pair(path, page))
            val srcs = Regex("src=\"([^\"]+\\.js[^\"]*)\"").findAll(page).map { it.groupValues[1] }.take(maxScripts).toList()
            for (sr in srcs) {
                try {
                    val sp = resolvePath(path, sr)
                    if (seenPages.add(sp)) texts.add(Pair(sp, get(sp)))
                } catch (e: Exception) { }
            }
        }

        loadWithScripts("/html/content.html", 40)
        add("loaded " + texts.size + " files: " + texts.joinToString(" ") { it.first.substringAfterLast('/') + "(" + it.second.length + ")" }.take(900))

        // صفحه‌های html که اسمشون به cell/lock مربوط می‌شه
        val defaultLen = try { get("/html/zz_notfound.html").length } catch (e: Exception) { -1 }
        val pageNames = LinkedHashSet<String>()
        for ((_, tx) in texts.toList()) {
            for (m in Regex("[\\w\\-/.]*(?:cell|lock)[\\w\\-/.]*\\.html", RegexOption.IGNORE_CASE).findAll(tx)) pageNames.add(m.value)
        }
        for (n in listOf("celllock", "cell_lock", "celllocking", "lockcell", "cell", "developmode", "developer")) pageNames.add("$n.html")
        val pageLines = mutableListOf<String>()
        for (n in pageNames.take(25)) {
            val path = if (n.startsWith("/")) n else if (n.startsWith("html/")) "/$n" else "/html/$n"
            val pg = try { get(path) } catch (e: Exception) { pageLines.add("$path ERR"); continue }
            pageLines.add(path + " len=" + pg.length + (if (pg.length == defaultLen) " (default page)" else ""))
            if (pg.length > 300 && pg.length != defaultLen) loadWithScripts(path, 10)
        }
        add("== html pages ==\n" + pageLines.joinToString("\n"))

        // آدرس‌های API که به موضوع مربوطن
        val apis = LinkedHashSet<String>()
        for ((_, tx) in texts) for (m in Regex("/api/[\\w\\-/]+").findAll(tx)) apis.add(m.value)
        add("== /api paths mentioning cell/lock/pci/earfcn/scan ==\n" + apis.filter { interesting.containsMatchIn(it) }.joinToString("\n"))

        // تکه کدهای دور earfcn و celllock (ساختار XML رو از اینجا می‌خونم)
        var shown = 0
        for ((src, tx) in texts) {
            for (m in Regex("celllock|cell_lock|lockcell|earfcn", RegexOption.IGNORE_CASE).findAll(tx)) {
                if (shown >= 8) break
                add("[" + src.substringAfterLast('/') + "] ..." + snippet(tx, m.range.first, 150, 450))
                shown++
            }
            if (shown >= 8) break
        }

        // GET امن روی آدرس‌های محتمل
        val probe = mutableListOf<String>()
        for (p in CANDIDATE_APIS) {
            val r = try { get(p) } catch (e: Exception) { "ERR $e" }
            probe.add(p + " -> " + r.replace(Regex("\\s+"), " ").take(450))
        }
        add("== GET probes ==\n" + probe.joinToString("\n"))
    } catch (e: Exception) {
        add("ERR $e")
    }
    add("== done ==")
}
