package com.farhad.modem.core

import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

/**
 * Internet speed test through the modem, built like the big speed-test sites: several parallel connections,
 * the TCP slow-start period is thrown away, and the result is the sustained rate (not the average of the whole run).
 */
object Speed {
    val DOWN_URLS = listOf(
        "https://speed.cloudflare.com/__down?bytes=200000000",
        "https://proof.ovh.net/files/100Mb.dat",
        "http://speedtest.tele2.net/100MB.zip"
    )
    const val UP_URL = "https://speed.cloudflare.com/__up"
    const val PING_URL = "https://speed.cloudflare.com/cdn-cgi/trace"

    data class Ping(val ms: Double, val jitter: Double)

    fun mbps(bytes: Long, ms: Long): Double = if (ms <= 0L) 0.0 else bytes * 8.0 / (ms / 1000.0) / 1e6

    /**
     * samples: (time in ms since start, total bytes so far). Rates are taken over 1 second windows after the warm-up
     * and the best 80% of the windows are averaged (a stall or a short dip does not drag the result down).
     */
    fun fromSamples(samples: List<Pair<Long, Long>>, warmupMs: Long, windowMs: Long = 1000L): Double? {
        val s = samples.filter { it.first >= warmupMs }
        if (s.size < 2) return null
        val rates = ArrayList<Double>()
        var i = 0
        while (i < s.size) {
            var j = i + 1
            while (j < s.size && s[j].first - s[i].first < windowMs) j++
            if (j >= s.size) break
            rates.add(mbps(s[j].second - s[i].second, s[j].first - s[i].first))
            i = j
        }
        if (rates.isEmpty()) {
            val a = s.first(); val b = s.last()
            return if (b.first > a.first) mbps(b.second - a.second, b.first - a.first) else null
        }
        rates.sortDescending()
        val keep = maxOf(1, (rates.size * 0.8).toInt())
        return rates.take(keep).average()
    }

    private fun open(u: String, readTimeout: Int = 8000): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = readTimeout
        c.useCaches = false
        return c
    }

    /** Runs [threads] workers for warmupMs + testMs and samples the shared byte counter every 200 ms. */
    private fun run(
        threads: Int, warmupMs: Long, testMs: Long, onLive: (Double) -> Unit,
        worker: (idx: Int, stop: () -> Boolean, add: (Long) -> Unit) -> Unit
    ): Double? {
        val total = AtomicLong(0)
        val stopFlag = java.util.concurrent.atomic.AtomicBoolean(false)
        val pool = (0 until threads).map { idx ->
            Thread {
                try { worker(idx, { stopFlag.get() }, { total.addAndGet(it) }) } catch (e: Exception) { }
            }.also { it.isDaemon = true; it.start() }
        }
        val samples = ArrayList<Pair<Long, Long>>()
        val t0 = System.currentTimeMillis()
        var last = Pair(0L, 0L)
        while (true) {
            Thread.sleep(200)
            val t = System.currentTimeMillis() - t0
            val b = total.get()
            samples.add(Pair(t, b))
            if (t - last.first >= 1000) {
                onLive(mbps(b - last.second, t - last.first))
                last = Pair(t, b)
            }
            if (t >= warmupMs + testMs) break
            if (t > 6000 && b == 0L) break      // nothing arrives: server unreachable
        }
        stopFlag.set(true)
        pool.forEach { try { it.join(1500) } catch (e: Exception) { } }
        return if (total.get() == 0L) null else fromSamples(samples, warmupMs)
    }

    /** Download speed in Mbit/s or null if no server answered. */
    fun download(
        urls: List<String> = DOWN_URLS, threads: Int = 6, warmupMs: Long = 2000, testMs: Long = 8000,
        onLive: (Double) -> Unit = {}
    ): Double? = run(threads, warmupMs, testMs, onLive) { idx, stop, add ->
        val buf = ByteArray(131072)
        var failures = 0
        var k = idx
        while (!stop() && failures < 6) {
            val u = urls[k % urls.size]
            try {
                val sep = if (u.contains('?')) "&" else "?"
                val c = open(u + sep + "r=" + System.nanoTime())
                try {
                    val input = c.inputStream
                    var got = false
                    while (!stop()) {
                        val n = input.read(buf)
                        if (n < 0) break
                        got = true
                        add(n.toLong())
                    }
                    if (!got) { failures++; k++ }
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                failures++
                k++
            }
        }
    }

    /** Upload speed in Mbit/s or null. */
    fun upload(
        url: String = UP_URL, threads: Int = 4, warmupMs: Long = 2000, testMs: Long = 8000,
        onLive: (Double) -> Unit = {}
    ): Double? = run(threads, warmupMs, testMs, onLive) { _, stop, add ->
        val chunk = ByteArray(32768) { (it * 31).toByte() }
        val size = 25_000_000
        var failures = 0
        while (!stop() && failures < 4) {
            try {
                val c = open(url)
                try {
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.setFixedLengthStreamingMode(size)
                    c.setRequestProperty("Content-Type", "application/octet-stream")
                    val o = c.outputStream
                    var sent = 0
                    while (sent < size && !stop()) {
                        val n = minOf(chunk.size, size - sent)
                        o.write(chunk, 0, n)
                        sent += n
                        add(n.toLong())
                    }
                    if (sent >= size) { try { c.responseCode } catch (e: Exception) { } }
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                failures++
            }
        }
    }

    /** Round-trip time: the first request (TCP + TLS set-up) is thrown away, then the median and the jitter of the rest. */
    fun ping(url: String = PING_URL, tries: Int = 12): Ping? {
        val times = ArrayList<Double>()
        repeat(tries + 1) { i ->
            try {
                val c = open(url, 5000)
                try {
                    val t0 = System.nanoTime()
                    c.inputStream.use { it.readBytes() }
                    val ms = (System.nanoTime() - t0) / 1e6
                    if (i > 0) times.add(ms)
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
            }
        }
        if (times.isEmpty()) return null
        val sorted = times.sorted()
        val median = sorted[sorted.size / 2]
        val jitter = if (times.size < 2) 0.0 else times.zipWithNext { a, b -> Math.abs(a - b) }.average()
        return Ping(median, jitter)
    }
}
