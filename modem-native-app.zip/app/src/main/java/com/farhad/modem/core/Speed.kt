package com.farhad.modem.core

import java.net.HttpURLConnection
import java.net.URL

/** Internet speed test through the modem (plain HTTP(S) downloads/uploads to public servers). */
object Speed {
    val DOWN_URLS = listOf(
        "https://speed.cloudflare.com/__down?bytes=30000000",
        "https://proof.ovh.net/files/10Mb.dat"
    )
    const val UP_URL = "https://speed.cloudflare.com/__up"
    const val PING_URL = "https://speed.cloudflare.com/cdn-cgi/trace"

    fun mbps(bytes: Long, ms: Long): Double = if (ms <= 0L) 0.0 else bytes * 8.0 / (ms / 1000.0) / 1e6

    private fun open(u: String): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.useCaches = false
        return c
    }

    /** Download speed in Mbit/s, or null if no server answered. Reads for at most maxMs. */
    fun download(maxMs: Long = 8000L, onProgress: (Double) -> Unit = {}): Double? {
        for (u in DOWN_URLS) {
            try {
                val c = open(u)
                try {
                    val input = c.inputStream
                    val buf = ByteArray(65536)
                    var total = 0L
                    val t0 = System.currentTimeMillis()
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        total += n
                        val dt = System.currentTimeMillis() - t0
                        if (dt > 400) onProgress(mbps(total, dt))
                        if (dt >= maxMs) break
                    }
                    val ms = System.currentTimeMillis() - t0
                    if (total > 100_000L && ms > 0L) return mbps(total, ms)
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                // try the next server
            }
        }
        return null
    }

    /** Upload speed in Mbit/s, or null on failure. */
    fun upload(bytes: Int = 6_000_000): Double? {
        return try {
            val c = open(UP_URL)
            try {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setFixedLengthStreamingMode(bytes)
                c.setRequestProperty("Content-Type", "application/octet-stream")
                val chunk = ByteArray(65536) { (it * 31).toByte() }
                val t0 = System.currentTimeMillis()
                c.outputStream.use { o ->
                    var sent = 0
                    while (sent < bytes) {
                        val n = minOf(chunk.size, bytes - sent)
                        o.write(chunk, 0, n)
                        sent += n
                    }
                }
                c.responseCode
                val ms = System.currentTimeMillis() - t0
                if (ms > 0L) mbps(bytes.toLong(), ms) else null
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Median round-trip time in ms of a few tiny requests, or null. */
    fun ping(tries: Int = 5): Long? {
        val times = ArrayList<Long>()
        repeat(tries) {
            try {
                val c = open(PING_URL)
                try {
                    val t0 = System.currentTimeMillis()
                    c.inputStream.use { it.readBytes() }
                    times.add(System.currentTimeMillis() - t0)
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
            }
        }
        if (times.isEmpty()) return null
        times.sort()
        return times[times.size / 2]
    }
}
