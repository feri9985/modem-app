package com.farhad.modem.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.farhad.modem.Store

/** Keeps one WebView alive while switching tabs. It shows the modem's own pages, already logged in. */
object DevWeb {
    private var view: WebView? = null
    private var lastCookie = ""

    private fun base(): String = "http://" + Store.savedIp()

    @SuppressLint("SetJavaScriptEnabled")
    fun get(ctx: Context): WebView {
        val ck = Store.client.sessionCookie
        var v = view
        if (v == null) {
            v = WebView(ctx)
            v.settings.javaScriptEnabled = true
            v.settings.domStorageEnabled = true
            v.webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    view?.evaluateJavascript(HOOK, null)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    view?.evaluateJavascript(HOOK, null)
                }
            }
            view = v
        }
        if (ck != lastCookie || v.url == null) {
            lastCookie = ck
            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            if (ck.isNotEmpty()) cm.setCookie(base(), "$ck; path=/")
            cm.flush()
            v.loadUrl(base() + "/html/content.html")
        }
        (v.parent as? ViewGroup)?.removeView(v)
        return v
    }

    /** JavaScript that records the requests the modem page sends (POSTs and lock/cell/band related GETs). */
    private const val HOOK = "(function(){if(window.__hk)return;window.__hk=1;window.__log=[];" +
        "var o=XMLHttpRequest.prototype.open,s=XMLHttpRequest.prototype.send;" +
        "XMLHttpRequest.prototype.open=function(m,u){this.__m=m;this.__u=u;return o.apply(this,arguments)};" +
        "XMLHttpRequest.prototype.send=function(b){var x=this;var rec={m:x.__m,u:String(x.__u),b:(b==null?'':String(b))};" +
        "x.addEventListener('load',function(){var u=rec.u;" +
        "if(/user\\//.test(u))return;" +
        "if(String(rec.m).toUpperCase()==='POST'||/lock|freq|cell|pci|band|scan|neighbo/i.test(u)||/pci/i.test(String(x.responseText))){" +
        "rec.r=String(x.responseText).slice(0,700);window.__log.push(rec);}});" +
        "return s.apply(this,arguments)};})();"

    /** Returns the captured requests as text (via callback on the main thread). */
    fun capture(done: (String) -> Unit) {
        val v = view
        if (v == null) {
            done("(no page)")
            return
        }
        v.evaluateJavascript("(function(){return JSON.stringify(window.__log||[]);})()") { raw ->
            val text = try {
                val json = org.json.JSONTokener(raw ?: "null").nextValue() as? String ?: "[]"
                val arr = org.json.JSONArray(json)
                val sb = StringBuilder()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    sb.append(o.optString("m")).append(' ').append(o.optString("u")).append('\n')
                    sb.append("BODY: ").append(o.optString("b")).append('\n')
                    sb.append("REPLY: ").append(o.optString("r")).append("\n\n")
                }
                if (sb.isEmpty()) "(nothing captured yet)" else sb.toString()
            } catch (e: Exception) {
                "ERR $e"
            }
            done(text)
        }
    }

    fun clearCapture() {
        view?.evaluateJavascript("window.__log=[];", null)
    }

    fun open(path: String) {
        view?.loadUrl(base() + path)
    }

    fun reset() {
        Handler(Looper.getMainLooper()).post {
            view?.destroy()
            view = null
            lastCookie = ""
        }
    }
}

@Composable
fun DevWebScreen() {
    val clip = LocalClipboardManager.current
    var cap by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text(
            "Modem's own pages. Go: Advanced > System > System settings > Developer options > Band selection.",
            color = C.mute, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(8.dp)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Btn("Home page", Modifier.weight(1f)) { DevWeb.open("/html/content.html") }
            Btn("Dev options", Modifier.weight(1f)) { DevWeb.open("/html/developmode.html") }
            Btn("Reload", Modifier.width(90.dp)) { DevWeb.open("/html/content.html") }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("Show captured requests", Modifier.weight(1f)) { DevWeb.capture { cap = it } }
            Btn("Clear", Modifier.width(90.dp)) { DevWeb.clearCapture(); cap = "" }
        }
        if (cap.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().heightIn(max = 220.dp).padding(horizontal = 8.dp).verticalScroll(rememberScrollState())) {
                Mono(cap)
            }
            Btn("Copy text", Modifier.fillMaxWidth().padding(8.dp)) {
                clip.setText(AnnotatedString(cap))
                Store.toast("Copied")
            }
        }
        AndroidView(factory = { ctx -> DevWeb.get(ctx) }, modifier = Modifier.weight(1f).fillMaxWidth())
    }
}
