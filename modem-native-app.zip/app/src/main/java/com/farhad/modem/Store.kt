package com.farhad.modem

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.farhad.modem.core.Auto
import com.farhad.modem.core.AutoState
import com.farhad.modem.core.BandInfo
import com.farhad.modem.core.Event
import com.farhad.modem.core.History
import com.farhad.modem.core.HistoryCodec
import com.farhad.modem.core.ModemClient
import com.farhad.modem.core.OperatorInfo
import com.farhad.modem.core.Profile
import com.farhad.modem.core.ProfileCodec
import com.farhad.modem.core.Sample
import com.farhad.modem.core.Snapshot
import com.farhad.modem.core.Traffic
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** وضعیت مشترک برنامه (بین رابط و سرویس پس‌زمینه). همه‌ی StateFlow ها thread-safe هستن. */
object Store {
    private var inited = false
    lateinit var app: Context
        private set
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())

    val client = ModemClient()

    val loggedIn = MutableStateFlow(false)
    val monitoring = MutableStateFlow(false)
    val online = MutableStateFlow(true)
    val wifiReady = MutableStateFlow(false)
    val snapshot = MutableStateFlow<Snapshot?>(null)
    val traffic = MutableStateFlow<Traffic?>(null)
    val operator = MutableStateFlow<OperatorInfo?>(null)
    val bandInfo = MutableStateFlow<BandInfo?>(null)
    val history = MutableStateFlow<List<Sample>>(emptyList())
    val events = MutableStateFlow<List<Event>>(emptyList())
    val profiles = MutableStateFlow<List<Profile>>(emptyList())
    val auto = MutableStateFlow(AutoState())
    val autoMsg = MutableStateFlow("")
    val logText = MutableStateFlow("")

    // انتخاب‌های صفحه‌ی Home (تا با عوض کردن تب پاک نشن)
    val selL = mutableStateListOf<Int>()
    val selN = mutableStateListOf<Int>()
    val option = mutableStateOf("")
    val en5 = mutableStateOf(true)
    var selFor: BandInfo? = null

    @Volatile var foreground = false
    @Volatile var alignActive = false
    @Volatile var autoBusy = false
    @Volatile var autoLoginTried = false
    private var sampleCount = 0

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("modem", Context.MODE_PRIVATE)
        client.log = { log(it) }
        profiles.value = ProfileCodec.decode(prefs.getString("profiles", "") ?: "")
        history.value = HistoryCodec.decode(prefs.getString("hist", "") ?: "")
        events.value = HistoryCodec.decodeEvents(prefs.getString("ev", "") ?: "")
        auto.value = AutoState(
            on = prefs.getBoolean("a_on", false),
            thr = prefs.getInt("a_thr", 5),
            mins = prefs.getInt("a_mins", 3),
            cur = prefs.getString("a_cur", "") ?: "",
            t0 = prefs.getLong("a_t0", 0L),
            hold = prefs.getLong("a_hold", 0L),
            tried = Auto.decodeTried(prefs.getString("a_tried", "") ?: "")
        )
        initNetwork()
    }

    /** ترافیک اپ باید از شبکه‌ی وای‌فای مودم بره، حتی وقتی دیتای موبایل روشنه. */
    private fun initNetwork() {
        try {
            val cm = app.getSystemService(ConnectivityManager::class.java)
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
            cm.requestNetwork(req, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    cm.bindProcessToNetwork(network)
                    wifiReady.value = true
                }

                override fun onLost(network: Network) {
                    wifiReady.value = false
                }
            })
        } catch (e: Exception) {
            log("network ERR $e")
        }
    }

    fun awaitWifi(ms: Long) {
        var left = ms
        while (!wifiReady.value && left > 0) {
            Thread.sleep(100)
            left -= 100
        }
    }

    // ---------- ورود ----------
    fun savedIp(): String = prefs.getString("ip", "192.168.8.1") ?: "192.168.8.1"
    fun savedUser(): String = prefs.getString("user", "admin") ?: "admin"
    fun savedPass(): String = prefs.getString("pass", "") ?: ""
    fun saveCreds(ip: String, user: String, pass: String) {
        prefs.edit().putString("ip", ip).putString("user", user).putString("pass", pass).apply()
    }
    fun clearPass() {
        prefs.edit().putString("pass", "").apply()
    }

    // ---------- لاگ و پیام ----------
    fun log(s: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        logText.update { (t + " " + s.take(400) + "\n" + it).take(3000) }
    }

    fun toast(s: String) {
        main.post { Toast.makeText(app, s, Toast.LENGTH_SHORT).show() }
    }

    fun pollInterval(): Long = if (alignActive) 800L else if (foreground) 1500L else 10000L

    // ---------- ذخیره‌سازی ----------
    fun persist() {
        prefs.edit()
            .putString("hist", HistoryCodec.encode(history.value))
            .putString("ev", HistoryCodec.encodeEvents(events.value))
            .apply()
    }

    fun addSample(s: Snapshot) {
        history.update { History.append(it, History.fromSnapshot(s)) }
        sampleCount++
        if (sampleCount % 6 == 0) persist()
    }

    fun addEvent(text: String) {
        events.update { (it + Event(System.currentTimeMillis(), text)).takeLast(40) }
        persist()
    }

    fun clearHistory() {
        history.value = emptyList()
        events.value = emptyList()
        persist()
    }

    fun saveProfiles(l: List<Profile>) {
        profiles.value = l
        prefs.edit().putString("profiles", ProfileCodec.encode(l)).apply()
    }

    fun saveAuto(s: AutoState) {
        auto.value = s
        prefs.edit()
            .putBoolean("a_on", s.on).putInt("a_thr", s.thr).putInt("a_mins", s.mins)
            .putString("a_cur", s.cur).putLong("a_t0", s.t0).putLong("a_hold", s.hold)
            .putString("a_tried", Auto.encodeTried(s.tried))
            .apply()
    }

    fun setAutoOn(on: Boolean) {
        if (on) {
            saveAuto(Auto.turnedOn(auto.value, System.currentTimeMillis()))
            autoMsg.value = "در حال بررسی سیگنال..."
            toast("سوییچ خودکار روشن شد")
        } else {
            saveAuto(auto.value.copy(on = false))
            autoMsg.value = ""
        }
    }

    fun resetSession() {
        loggedIn.value = false
        monitoring.value = false
        snapshot.value = null
        traffic.value = null
        operator.value = null
        bandInfo.value = null
        online.value = true
    }
}
