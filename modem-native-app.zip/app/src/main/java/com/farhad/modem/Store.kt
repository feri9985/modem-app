package com.farhad.modem

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.farhad.modem.core.BandInfo
import com.farhad.modem.core.CellCodec
import com.farhad.modem.core.CellEntry
import com.farhad.modem.core.History
import com.farhad.modem.core.HistoryCodec
import com.farhad.modem.core.ModemClient
import com.farhad.modem.core.OperatorInfo
import com.farhad.modem.core.Sample
import com.farhad.modem.core.Snapshot
import com.farhad.modem.core.Traffic
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** وضعیت مشترک برنامه (بین رابط و سرویس پس‌زمینه). همه‌ی StateFlow ها thread-safe هستن. */
object Store {
    private var inited = false
    lateinit var app: Context
        private set
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())

    val client = ModemClient()

    val loggedIn = MutableStateFlow(false)
    val monitoring = MutableStateFlow(false)
    val online = MutableStateFlow(true)
    val wifiReady = MutableStateFlow(false)
    val snapshot = MutableStateFlow<Snapshot?>(null)
    val traffic = MutableStateFlow<Traffic?>(null)
    val operator = MutableStateFlow<OperatorInfo?>(null)
    val bandInfo = MutableStateFlow<BandInfo?>(null)
    val history = MutableStateFlow<List<Sample>>(emptyList())
    val cells4 = MutableStateFlow<List<CellEntry>>(emptyList())   // saved 4G cell lock list
    val cells5 = MutableStateFlow<List<CellEntry>>(emptyList())   // saved 5G cell lock list
    val lockCells4 = MutableStateFlow<List<CellEntry>>(emptyList())  // local physical cell locking 4G
    val lockCells5 = MutableStateFlow<List<CellEntry>>(emptyList())  // local physical cell locking 5G
    val logText = MutableStateFlow("")

    // انتخاب‌های صفحه‌ی Home (تا با عوض کردن تب پاک نشن)
    val selL = mutableStateListOf<Int>()
    val selN = mutableStateListOf<Int>()
    val option = mutableStateOf("")
    val en5 = mutableStateOf(true)
    var selFor: BandInfo? = null

    @Volatile var foreground = false
    @Volatile var alignActive = false
    @Volatile var autoLoginTried = false
    private var sampleCount = 0

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("modem", Context.MODE_PRIVATE)
        client.log = { log(it) }
        history.value = HistoryCodec.decode(prefs.getString("hist", "") ?: "")
        cells4.value = CellCodec.decode(prefs.getString("cells4", "") ?: "")
        cells5.value = CellCodec.decode(prefs.getString("cells5", "") ?: "")
        lockCells4.value = CellCodec.decode(prefs.getString("lock4", "") ?: "")
        lockCells5.value = CellCodec.decode(prefs.getString("lock5", "") ?: "")
        initNetwork()
    }

    /** ترافیک اپ باید از شبکه‌ی وای‌فای مودم بره، حتی وقتی دیتای موبایل روشنه. */
    private fun initNetwork() {
        try {
            val cm = app.getSystemService(ConnectivityManager::class.java)
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
            cm.requestNetwork(req, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    cm.bindProcessToNetwork(network)
                    wifiReady.value = true
                }

                override fun onLost(network: Network) {
                    wifiReady.value = false
                }
            })
        } catch (e: Exception) {
            log("network ERR $e")
        }
    }

    fun awaitWifi(ms: Long) {
        var left = ms
        while (!wifiReady.value && left > 0) {
            Thread.sleep(100)
            left -= 100
        }
    }

    // ---------- ورود ----------
    fun savedIp(): String = prefs.getString("ip", "192.168.8.1") ?: "192.168.8.1"
    fun savedUser(): String = prefs.getString("user", "admin") ?: "admin"
    fun savedPass(): String = prefs.getString("pass", "") ?: ""
    fun saveCreds(ip: String, user: String, pass: String) {
        prefs.edit().putString("ip", ip).putString("user", user).putString("pass", pass).apply()
    }
    fun clearPass() {
        prefs.edit().putString("pass", "").apply()
    }

    // ---------- لاگ و پیام ----------
    fun log(s: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        logText.update { (t + " " + s.take(400) + "\n" + it).take(3000) }
    }

    fun toast(s: String) {
        main.post { Toast.makeText(app, s, Toast.LENGTH_SHORT).show() }
    }

    fun pollInterval(): Long = if (alignActive) 800L else if (foreground) 1500L else 10000L

    // ---------- storage ----------
    fun persist() {
        prefs.edit().putString("hist", HistoryCodec.encode(history.value)).apply()
    }

    fun addSample(s: Snapshot) {
        history.update { History.append(it, History.fromSnapshot(s)) }
        sampleCount++
        if (sampleCount % 6 == 0) persist()
    }

    fun clearHistory() {
        history.value = emptyList()
        persist()
    }

    /** list: "cells4", "cells5", "lock4", "lock5" */
    fun saveCells(which: String, l: List<CellEntry>) {
        when (which) {
            "cells4" -> cells4.value = l
            "cells5" -> cells5.value = l
            "lock4" -> lockCells4.value = l
            else -> lockCells5.value = l
        }
        prefs.edit().putString(which, CellCodec.encode(l)).apply()
    }

    fun resetSession() {
        loggedIn.value = false
        monitoring.value = false
        snapshot.value = null
        traffic.value = null
        operator.value = null
        bandInfo.value = null
        online.value = true
    }
}
